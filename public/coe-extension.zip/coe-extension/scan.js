// Finds the questions on a page, and puts answers into the boxes. It only reads the page; nothing leaves it until you press a button.
(() => {
  if (window.CoeScan) return;
  const clean = (s) => (s || '').replace(/\s+/g, ' ').trim();
  const txt = (e) => clean(e && (e.innerText || e.textContent));
  const seen = (e) => { if (!e || !e.getBoundingClientRect) return false; const r = e.getBoundingClientRect(), s = getComputedStyle(e); return r.width > 2 && r.height > 2 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const mine = (e) => !!(e.closest && e.closest('#coe-island-host'));
  const norm = (s) => clean(s).toLowerCase().replace(/[^a-z0-9.\-−]+/g, ' ').trim();
  const num = (s) => { const v = parseFloat(String(s).replace(/−/g, '-').replace(/[^0-9.\-]/g, '')); return Number.isFinite(v) ? v : null; };

  const label = (el, own) => {
    let n = el;
    for (let i = 0; i < 7 && n && n.parentElement; i++) {
      n = n.parentElement;
      const t = txt(n).replace(own || '', '').trim();
      if (t.length >= 10) return { text: t.slice(0, 600), box: n };
    }
    return null;
  };
  const optLabel = (e) => clean(e.getAttribute('aria-label') || e.getAttribute('data-value') || (e.labels && e.labels[0] && e.labels[0].innerText) || (e.closest('label') && e.closest('label').innerText) || e.parentElement && e.parentElement.innerText || '');

  function forms() {
    const out = [];
    document.querySelectorAll('div[role="listitem"]').forEach((box) => {
      if (mine(box) || !seen(box)) return;
      const head = box.querySelector('[role="heading"]'), text = txt(head) || '';
      if (text.length < 3) return;
      const radios = [...box.querySelectorAll('[role="radio"]')], checks = [...box.querySelectorAll('[role="checkbox"]')];
      const field = box.querySelector('input[type="text"], input[type="number"], input:not([type]), textarea');
      if (radios.length) out.push({ text, kind: 'choice', box, opts: radios, options: radios.map(optLabel) });
      else if (checks.length) out.push({ text, kind: 'multi', box, opts: checks, options: checks.map(optLabel) });
      else if (field && seen(field)) out.push({ text, kind: 'text', box, field });
    });
    return out;
  }

  function generic() {
    const out = [], used = new Set();
    const fields = [...document.querySelectorAll('input, textarea, select')].filter((e) => {
      if (mine(e) || !seen(e)) return false;
      const t = (e.type || '').toLowerCase();
      if (['hidden', 'submit', 'button', 'password', 'email', 'tel', 'file', 'image', 'reset', 'color', 'range', 'search', 'date', 'checkbox'].includes(t)) return false;
      if (e.closest('nav, header, footer, [role="search"], [role="navigation"]')) return false;
      if (/search|email|user|pass|login|phone|name$/i.test((e.name || '') + ' ' + (e.id || '') + ' ' + (e.autocomplete || ''))) return false;
      return true;
    });
    fields.forEach((f) => {
      if (f.type === 'radio') {
        const name = f.name || ''; if (!name || used.has('r:' + name)) return; used.add('r:' + name);
        const group = fields.filter((x) => x.type === 'radio' && x.name === name);
        const l = label(group[0]); if (!l) return;
        const options = group.map(optLabel).filter(Boolean);
        out.push({ text: clean(l.text.replace(options.join(' '), '')) || l.text, kind: 'choice', box: l.box, opts: group, options });
        return;
      }
      if (f.tagName === 'SELECT') { const l = label(f); if (l) out.push({ text: l.text, kind: 'select', box: l.box, field: f, options: [...f.options].map((o) => clean(o.text)).filter(Boolean) }); return; }
      const l = label(f, f.value); if (!l) return;
      if (used.has(l.text)) return; used.add(l.text);
      out.push({ text: l.text, kind: 'text', box: l.box, field: f });
    });
    return out;
  }

  let list = [];
  function scan() {
    let found = forms(); if (!found.length) found = generic();
    list = found.slice(0, 30).map((q, i) => ({ ...q, id: i }));
    return list.map((q) => ({ id: q.id, text: q.text, kind: q.kind, options: q.options || [] }));
  }

  const setNative = (el, v) => {
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const set = Object.getOwnPropertyDescriptor(proto, 'value').set; set.call(el, v);
    el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true }));
  };
  const pickOpt = (q, want) => {
    const w = norm(want); if (!w) return null;
    const idx = q.options.map((o, i) => ({ i, n: norm(o) }));
    return (idx.find((x) => x.n === w) || idx.find((x) => x.n && (x.n.includes(w) || w.includes(x.n))) || {}).i ?? null;
  };
  const isOn = (e) => e.checked === true || e.getAttribute('aria-checked') === 'true';

  /** Puts an answer in. Returns a function that puts things back the way they were, or null if nothing matched. */
  function fill(id, value) {
    const q = list[id]; if (!q) return null;
    q.box && q.box.scrollIntoView && q.box.scrollIntoView({ behavior: 'smooth', block: 'center' });
    if (q.kind === 'text') { const prev = q.field.value; setNative(q.field, String(value)); return () => setNative(q.field, prev); }
    if (q.kind === 'select') { const prev = q.field.value; const i = pickOpt(q, value); if (i == null) return null; setNative(q.field, q.field.options[i].value); return () => setNative(q.field, prev); }
    const picks = (q.kind === 'multi' ? String(value).split(/;|\n| and /i) : [String(value)]).map((v) => pickOpt(q, v)).filter((i) => i != null);
    if (!picks.length) return null;
    const before = q.opts.map(isOn);
    picks.forEach((i) => { if (!isOn(q.opts[i])) q.opts[i].click(); });
    return () => q.opts.forEach((o, i) => { if (before[i] !== isOn(o)) o.click(); });
  }
  const current = (id) => { const q = list[id]; if (!q) return ''; if (q.kind === 'text' || q.kind === 'select') return q.field.value; return q.opts.map((o, i) => (isOn(o) ? q.options[i] : '')).filter(Boolean).join('; '); };

  /** Up to two pictures that belong to a question (a diagram, a graph), as small data addresses. Best effort: a picture the page does not let us read is left out. */
  async function pictures(id) {
    const q = list[id]; if (!q || !q.box) return [];
    const imgs = [...q.box.querySelectorAll('img, canvas')].filter((e) => !mine(e) && seen(e) && (e.naturalWidth || e.width) >= 60 && (e.naturalHeight || e.height) >= 40).slice(0, 2);
    const out = [];
    for (const e of imgs) {
      try {
        const w = e.naturalWidth || e.width, h = e.naturalHeight || e.height, k = Math.min(1, 900 / Math.max(w, h));
        const c = document.createElement('canvas'); c.width = Math.round(w * k); c.height = Math.round(h * k);
        c.getContext('2d').drawImage(e, 0, 0, c.width, c.height);
        out.push(c.toDataURL('image/jpeg', 0.82));
      } catch {
        try {
          if (e.tagName !== 'IMG' || !e.src) continue;
          const b = await (await fetch(e.src)).blob(); if (b.size > 1500000) continue;
          out.push(await new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = no; r.readAsDataURL(b); }));
        } catch { /* not readable from here */ }
      }
    }
    return out;
  }

  const pageText = () => clean((document.querySelector('main') || document.body).innerText).slice(0, 6000);

  let timer = 0;
  function watch(cb) {
    const run = () => { clearTimeout(timer); timer = setTimeout(cb, 900); };
    const mo = new MutationObserver((m) => { if (m.some((x) => !(x.target.closest && x.target.closest('#coe-island-host')))) run(); });
    mo.observe(document.body, { childList: true, subtree: true, characterData: true });
    addEventListener('popstate', run); addEventListener('hashchange', run);
    return () => { mo.disconnect(); clearTimeout(timer); };
  }

  window.CoeScan = { scan, fill, current, pictures, pageText, watch, norm, num };
})();
