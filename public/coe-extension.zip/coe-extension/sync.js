// Runs on coe.pmcstudios.uk only. It does three jobs:
// 1. hands the extension your Coe sign-in and server address, so you never sign in twice;
// 2. lets the Coe site read and change the extension's settings (the Chrome tab in Coe's Settings);
// 3. delivers "Continue in Coe" from the island into a new Coe chat.
(() => {
  const read = (k) => { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch { return null; } };
  const send = () => {
    try {
      const settings = read('pmc:coe:settings') || {};
      const me = { name: String(settings.name || '').slice(0, 30), tone: settings.tone || '', length: settings.length || '', system: String(settings.system || '').slice(0, 300) };
      chrome.runtime.sendMessage({ type: 'sync', session: read('pmc:coe:session'), ext: read('pmc:coe:ext'), code: settings.code || '', serverUrl: settings.serverUrl || '', site: location.origin, me });
    } catch { /* the extension was reloaded; this page will be refreshed next time */ }
  };
  const prefs = async () => { const o = await chrome.storage.local.get(['auto', 'start', 'speed']); return { auto: o.auto !== false, start: o.start === 'small' ? 'small' : 'bar', speed: ['swift', 'core', 'deep'].includes(o.speed) ? o.speed : 'core' }; };
  const post = (m) => postMessage({ coe: 'from-ext', ...m }, location.origin);
  let ready = false;
  const deliver = async () => {
    if (!ready) return;
    try {
      const { handoff } = await chrome.storage.local.get('handoff');
      if (handoff && handoff.text && Date.now() - handoff.ts < 600000) { post({ type: 'handoff', text: String(handoff.text).slice(0, 6000) }); }
      if (handoff) await chrome.storage.local.remove('handoff');
    } catch { /* reloaded */ }
  };
  addEventListener('message', async (e) => {
    const d = e.data;
    if (e.source !== window || !d || d.coe !== 'to-ext') return;
    try {
      if (d.type === 'hello') { ready = true; post({ type: 'hello', version: chrome.runtime.getManifest().version, prefs: await prefs() }); send(); deliver(); }
      if (d.type === 'set' && d.prefs) {
        const p = d.prefs, o = {};
        if (typeof p.auto === 'boolean') o.auto = p.auto;
        if (p.start === 'bar' || p.start === 'small') o.start = p.start;
        if (['swift', 'core', 'deep'].includes(p.speed)) o.speed = p.speed;
        await chrome.storage.local.set(o); post({ type: 'prefs', prefs: await prefs() });
      }
    } catch { /* the extension was reloaded */ }
  });
  try { chrome.storage.onChanged.addListener((c) => { if (c.auto || c.start || c.speed) prefs().then((p) => ready && post({ type: 'prefs', prefs: p })); if (c.handoff) deliver(); }); } catch { /* reloaded */ }
  send(); setTimeout(send, 2500); setTimeout(send, 7000);
  setInterval(send, 60000);
  addEventListener('storage', send);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) send(); });
})();
