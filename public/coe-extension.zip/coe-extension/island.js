(async () => {
  if (window.__coeIsland) { window.__coeIsland.toggle(); return; }
  let startSmall = false;
  try { const o = await chrome.storage.local.get(['auto', 'start']); startSmall = o.start === 'small' && !window.__coeForce; if (!window.__coeForce && o.auto === false) return; } catch { /* run anyway */ }
  if (window.__coeIsland) return;
  const S = window.CoeScan;
  const STAR = 'M786.886 22.9033C790.107 14.1976 802.421 14.1978 805.643 22.9033L825.213 75.79C875.855 212.649 983.761 320.556 1120.62 371.198L1173.51 390.768C1182.21 393.989 1182.21 406.304 1173.51 409.525L1120.62 429.095C983.761 479.737 875.855 587.643 825.213 724.503L805.643 777.39C802.421 786.095 790.107 786.095 786.886 777.39L767.316 724.503C716.674 587.643 608.768 479.737 471.908 429.095L419.021 409.525C410.316 406.304 410.316 393.989 419.021 390.768L471.908 371.198C608.768 320.556 716.674 212.65 767.316 75.79L786.886 22.9033ZM796.265 272.595C726.494 272.595 669.934 329.155 669.934 398.926C669.934 468.696 726.494 525.257 796.265 525.257C866.035 525.257 922.595 468.696 922.596 398.926C922.596 329.155 866.035 272.595 796.265 272.595Z';
  const star = (c) => '<svg class="' + c + '" viewBox="406 8 780 780" aria-hidden="true"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="' + STAR + '"/></svg>';

  // the two Caracteres fonts, loaded into the page itself (a shadow room cannot load its own)
  if (!document.getElementById('coe-island-fonts')) {
    const f = document.createElement('style'); f.id = 'coe-island-fonts';
    f.textContent = '@font-face{font-family:"Coe L2";src:url(' + chrome.runtime.getURL('fonts/CaracteresL2.woff2') + ') format("woff2");font-display:swap}@font-face{font-family:"Coe L4";src:url(' + chrome.runtime.getURL('fonts/CaracteresL4.woff2') + ') format("woff2");font-display:swap}';
    document.documentElement.appendChild(f);
  }

  const CSS = `
:host{all:initial}
*{box-sizing:border-box;margin:0;padding:0}
/* Coe white theme: --ink is the paper surface, --cream is the ink text and borders (names kept so every rule inverts together) */
.w{--ink:#FBF6EC;--cream:#171717;--g1:#337957;--g2:#1A4934;--g3:#337957;--gold:#8A7236;--bad:#A33A2B;--on:#F2E4CE;--x:cubic-bezier(.16,1,.3,1);--e:cubic-bezier(.7,0,.2,1);
  --d:"Coe L2","Big Shoulders Display",Impact,"Arial Narrow",sans-serif;--t:"Coe L4","IBM Plex Mono",ui-monospace,monospace;font-family:var(--t);color:var(--cream);line-height:1.45;-webkit-font-smoothing:antialiased}
button,input{font:inherit;color:inherit;border-radius:0}
button{cursor:pointer;background:none;border:0;text-align:inherit}
.d{font-family:var(--d);text-transform:uppercase;font-weight:400;letter-spacing:.03em}
.stack{position:fixed;top:16px;left:0;right:0;display:flex;justify-content:center;pointer-events:none;z-index:2}
.room{position:relative;pointer-events:auto;width:460px;max-width:calc(100vw - 32px);height:78px;background:var(--ink);border:3px solid var(--cream);box-shadow:8px 8px 0 var(--g2);overflow:hidden;
  transition:width .5s var(--e),height .45s var(--e),transform .5s var(--x);animation:drop .7s var(--x) both}
@keyframes drop{from{transform:translateY(-130%)}to{transform:none}}
.room[data-mode=min]{width:170px;height:52px;cursor:pointer;box-shadow:5px 5px 0 var(--g2)}
.room[data-mode=min]:hover{transform:translate(-2px,-2px)}
.main{position:absolute;left:0;top:0;width:100%;transition:opacity .2s}
.room[data-mode=min] .main{opacity:0;pointer-events:none}
.minic{position:absolute;inset:0;display:flex;align-items:center;gap:12px;padding:0 12px 0 8px;opacity:0;pointer-events:none;transition:opacity .25s .1s}
.room[data-mode=min] .minic{opacity:1}
.mk{flex:none;width:46px;height:46px;background:var(--g1);color:var(--on);display:grid;place-items:center}
.mk svg{width:30px;height:30px}
.minic .mk{width:34px;height:34px}.minic .mk svg{width:22px;height:22px}
.dg{display:flex;gap:5px;align-items:center}
.dg i{display:block;width:10px;height:10px;border:2px solid var(--cream);cursor:pointer;transition:width .3s var(--x),background-color .15s}
.dg i.on{width:24px;background:var(--cream)}.dg i.dn{background:var(--g3);border-color:var(--g3)}.dg i.on.dn{background:var(--g3)}
.dg .more{font-size:.8rem;opacity:.7;margin-left:2px}
.top{position:relative;z-index:2;height:72px;display:flex;align-items:center;gap:12px;padding:0 10px 0 12px}
.tt{flex:1;min-width:0;display:block}
.tt b{display:flex;align-items:center;gap:10px;font-family:var(--d);text-transform:uppercase;font-weight:400;font-size:1.45rem;line-height:1;letter-spacing:.03em;white-space:nowrap}
.tt>span{display:block;font-size:.82rem;opacity:.72;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:3px}
.sw{animation:up .35s var(--x)}
@keyframes up{from{opacity:0;transform:translate3d(0,12px,0)}to{opacity:1;transform:none}}
.go{flex:none;background:var(--cream);color:var(--ink);border:3px solid var(--cream);padding:8px 16px 6px;font-family:var(--d);text-transform:uppercase;font-size:1.3rem;line-height:1;letter-spacing:.03em;box-shadow:4px 4px 0 var(--g2);transition:transform .1s var(--x),box-shadow .1s,background-color .1s,color .1s}
.go:hover{transform:translate(-3px,-3px);box-shadow:7px 7px 0 var(--g2);background:var(--g1);border-color:var(--g1);color:var(--on)}
.go:active{transition-duration:.04s;transform:translate(3px,3px);box-shadow:1px 1px 0 var(--g1)}
.go:disabled{opacity:.45;pointer-events:none}
.room:not([data-s=idle]) .top .go{display:none}
.sq{flex:none;width:44px;height:44px;display:grid;place-items:center;border:3px solid var(--cream);transition:transform .1s var(--x),background-color .1s,color .1s}
.sq:hover{background:var(--cream);color:var(--ink);transform:translate(-2px,-2px)}.sq:active{transition-duration:.04s;transform:translate(2px,2px)}
.sq svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:2.6;stroke-linecap:square}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:42px;padding:7px 14px 5px;border:3px solid var(--cream);font-family:var(--d);text-transform:uppercase;font-size:1.15rem;line-height:1;letter-spacing:.03em;transition:transform .1s var(--x),background-color .1s,color .1s,box-shadow .1s}
.btn:hover{background:var(--cream);color:var(--ink);transform:translate(-2px,-2px);box-shadow:4px 4px 0 var(--g2)}.btn:active{transition-duration:.04s;transform:translate(2px,2px);box-shadow:none}
.btn.sm{min-height:34px;padding:5px 10px 3px;font-size:1rem}
.btn.fill{background:var(--cream);color:var(--ink);box-shadow:4px 4px 0 var(--g2)}.btn.fill:hover{background:var(--g1);border-color:var(--g1);color:var(--on);box-shadow:6px 6px 0 var(--g2)}
.btn[aria-pressed=true]{background:var(--cream);color:var(--ink)}
.scroll{position:relative;overflow-y:auto;overflow-x:hidden;max-height:var(--sch,560px);scrollbar-width:thin;scrollbar-color:var(--g1) transparent;border-top:3px solid var(--cream)}
.sc{display:none}.sc.in{display:block;animation:up .35s var(--x) both}
.opts,.row{display:flex;gap:10px;flex-wrap:wrap;padding:0 14px 14px}
.sa{display:flex;margin:14px 14px 12px}
.fld{flex:1;min-width:0;height:46px;background:transparent;border:3px solid var(--cream);padding:0 12px;outline:0;font-size:1rem}
.fld::placeholder{color:var(--cream);opacity:.55}.fld:focus{background:#fff;box-shadow:4px 4px 0 var(--g2)}
.lab{padding:14px 16px 0;font-size:.85rem;color:var(--gold);text-transform:uppercase;letter-spacing:.06em}
.ht1{padding:6px 16px 14px;font-size:1.1rem;line-height:1.55}
.ld{display:flex;align-items:center;gap:14px;padding:20px 16px}
.blk{display:flex;gap:6px}.blk i{display:block;width:16px;height:16px;background:var(--cream);animation:blk 1.05s steps(2,end) infinite}
.blk i:nth-child(2){animation-delay:.18s}.blk i:nth-child(3){animation-delay:.36s}
@keyframes blk{0%{opacity:1;transform:none}50%{opacity:.25;transform:translateY(-5px)}100%{opacity:1;transform:none}}
.bar{height:8px;margin:0 16px 16px;border:2px solid var(--cream);display:none}.bar.on{display:block}.bar i{display:block;height:100%;width:0;background:var(--g3);transition:width .6s steps(8,end)}
.hero{padding:12px 16px 0}.hero small{font-size:.85rem;color:var(--gold);text-transform:uppercase;letter-spacing:.06em}
.ans{font-family:var(--d);font-size:3.4rem;line-height:1;margin-top:2px;word-break:break-word}
.ans.pop{animation:pop .45s var(--x) both}@keyframes pop{from{opacity:0;transform:translateY(14px) scale(.96)}to{opacity:1;transform:none}}
.cta{display:flex;gap:10px;padding:16px 14px 14px}.cta .go{flex:1;display:block!important}
.disc{display:flex;justify-content:space-between;align-items:center;width:100%;padding:12px 16px;border-top:3px solid var(--cream);font-family:var(--d);text-transform:uppercase;font-size:1.15rem;letter-spacing:.03em}
.disc svg{width:16px;height:16px;stroke:currentColor;fill:none;stroke-width:2.6;stroke-linecap:square;transition:transform .3s var(--x)}.disc[aria-expanded=true] svg{transform:rotate(180deg)}
.sec{display:grid;grid-template-rows:0fr;transition:grid-template-rows .45s var(--e)}.sec>div{min-height:0;overflow:hidden}.sec.o{grid-template-rows:1fr}
.steps{list-style:none;padding:0 16px 4px}
.steps li{display:grid;grid-template-columns:26px 1fr;gap:10px;padding:10px 0;border-top:3px solid #D9CDB6}.steps li:first-child{border-top:0}
.steps .n{font-family:var(--d);font-size:1.2rem;color:var(--g3);padding-top:1px}.steps .m{font-size:1.05rem}.steps .c{font-size:.82rem;opacity:.7;margin-top:2px}
.mini{display:flex;gap:8px;padding:6px 14px 14px;flex-wrap:wrap}
.plain{padding:0 16px 14px;font-size:.95rem;line-height:1.55;opacity:.85}
.pr{padding:0 16px 16px}.pr small{font-size:.85rem;color:var(--gold);text-transform:uppercase;letter-spacing:.06em}.pr p.q{font-size:1.15rem;margin:4px 0 10px}
.prrow{display:flex;gap:8px}.prm{font-size:.9rem;margin-top:8px;min-height:20px}.prm.ok{color:var(--g3)}.prm.no{color:var(--bad)}
.cr{padding:2px 16px 12px;font-size:.8rem;opacity:.6}
.ask{display:flex;gap:10px;padding:12px 14px 14px;border-top:3px solid var(--cream)}
.ah{padding:14px 16px 8px}.ah b{display:block;font-family:var(--d);text-transform:uppercase;font-weight:400;font-size:1.6rem;line-height:1}.ah span{font-size:.85rem;opacity:.7}
.list{padding:0 10px}
.rw{display:flex;align-items:center;gap:12px;padding:10px 6px;border-top:3px solid #D9CDB6;cursor:pointer;transition:background-color .1s}.rw:first-child{border-top:0}.rw:hover{background:#F2E4CE}
.rw .q{flex:none;width:30px;height:30px;border:3px solid var(--cream);display:grid;place-items:center;font-family:var(--d);font-size:1.05rem}
.rw .e{flex:1;min-width:0}.rw .e b{display:block;font-family:var(--d);font-weight:400;font-size:1.5rem;line-height:1.05}.rw .e span{display:block;font-size:.82rem;opacity:.7;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.allcta{display:flex;gap:10px;padding:12px 14px 14px}.allcta .go{flex:1;display:block!important}
.mf{padding:12px 14px 4px;display:grid;gap:10px}
.cnt{display:flex;gap:8px;align-items:center}.cnt span{font-size:.85rem;opacity:.7;margin-right:4px}
.pq{margin:0 14px 12px;padding:12px;border:3px solid var(--cream);box-shadow:4px 4px 0 var(--g2)}
.pq small{font-size:.8rem;color:var(--gold);text-transform:uppercase;letter-spacing:.06em}.pq p{font-size:1.05rem;margin:3px 0 10px}
.pk{display:none;align-items:center;gap:8px;padding:10px 12px;border-top:3px solid var(--cream)}.pk.on{display:flex}
.pk .sq{width:38px;height:38px}.pk .sq[disabled]{opacity:.3;pointer-events:none}
.pkr{flex:1;min-width:0;display:flex;gap:6px;overflow-x:auto;padding:2px 3px 6px;margin-bottom:-4px;scrollbar-width:none}.pkr::-webkit-scrollbar{display:none}
.pkc{flex:none;min-width:38px;height:38px;padding:3px 0 0;display:grid;place-items:center;border:3px solid var(--cream);font-family:var(--d);font-size:1.25rem;line-height:1;position:relative;transition:transform .1s var(--x),background-color .1s,color .1s,box-shadow .1s}
.pkc:hover{transform:translate(-2px,-2px);box-shadow:3px 3px 0 var(--g2)}.pkc:active{transition-duration:.04s;transform:translate(2px,2px);box-shadow:none}
.pkc.dn{border-color:var(--g1);color:var(--g1)}.pkc.dn::after{content:"";position:absolute;right:-3px;top:-3px;width:9px;height:9px;background:var(--g1)}
.pkc.on{background:var(--cream);color:var(--ink);box-shadow:3px 3px 0 var(--g2)}.pkc.on.dn{background:var(--g1);border-color:var(--cream);color:var(--on)}.pkc.on.dn::after{background:var(--on);border:2px solid var(--g1)}
.pkl{flex:none;font-size:.8rem;text-transform:uppercase;letter-spacing:.06em;color:var(--gold);padding-top:2px}
.toast{position:absolute;z-index:6;left:10px;right:10px;top:10px;min-height:52px;display:flex;align-items:center;gap:10px;background:var(--cream);color:var(--ink);padding:8px 14px;font-size:.95rem;transform:translateY(-130%);transition:transform .35s var(--x)}
.toast.on{transform:none}.toast button{margin-left:auto;font-family:var(--d);text-transform:uppercase;border:3px solid var(--ink);padding:4px 10px 2px}
.ht{position:absolute;top:0;right:0;width:240px;height:240px;color:var(--g1);opacity:.5;pointer-events:none;z-index:0}
.ht i{position:absolute;inset:0}
.ht i:nth-child(1){background:radial-gradient(circle at center,currentColor 0 3.4px,transparent 3.6px) 0 0/12px 12px;-webkit-mask-image:radial-gradient(circle farthest-corner at 100% 0,#000 0 8%,transparent 32%);mask-image:radial-gradient(circle farthest-corner at 100% 0,#000 0 8%,transparent 32%)}
.ht i:nth-child(2){background:radial-gradient(circle at center,currentColor 0 2.4px,transparent 2.6px) 0 0/12px 12px;-webkit-mask-image:radial-gradient(circle farthest-corner at 100% 0,transparent 0 8%,#000 24%,transparent 50%);mask-image:radial-gradient(circle farthest-corner at 100% 0,transparent 0 8%,#000 24%,transparent 50%)}
.ht i:nth-child(3){background:radial-gradient(circle at center,currentColor 0 1.4px,transparent 1.6px) 0 0/12px 12px;-webkit-mask-image:radial-gradient(circle farthest-corner at 100% 0,transparent 0 24%,#000 42%,transparent 70%);mask-image:radial-gradient(circle farthest-corner at 100% 0,transparent 0 24%,#000 42%,transparent 70%)}
.pd{position:fixed;left:0;right:0;top:0;height:60vh;color:var(--g1);opacity:0;transition:opacity .6s ease;pointer-events:none;z-index:1}
.w[data-s=loading] .pd{opacity:.5}
.pd i{position:absolute;inset:0}
.pd i:nth-child(1){background:radial-gradient(circle at center,currentColor 0 4px,transparent 4.2px) 0 0/14px 14px;-webkit-mask-image:radial-gradient(ellipse 60% 70% at 50% 0,#000 0 10%,transparent 38%);mask-image:radial-gradient(ellipse 60% 70% at 50% 0,#000 0 10%,transparent 38%)}
.pd i:nth-child(2){background:radial-gradient(circle at center,currentColor 0 2.8px,transparent 3px) 0 0/14px 14px;-webkit-mask-image:radial-gradient(ellipse 60% 70% at 50% 0,transparent 0 10%,#000 28%,transparent 62%);mask-image:radial-gradient(ellipse 60% 70% at 50% 0,transparent 0 10%,#000 28%,transparent 62%)}
.pd i:nth-child(3){background:radial-gradient(circle at center,currentColor 0 1.6px,transparent 1.8px) 0 0/14px 14px;-webkit-mask-image:radial-gradient(ellipse 60% 70% at 50% 0,transparent 0 30%,#000 52%,transparent 100%);mask-image:radial-gradient(ellipse 60% 70% at 50% 0,transparent 0 30%,#000 52%,transparent 100%)}
@media (prefers-reduced-motion:reduce){*{animation-duration:.01ms!important;transition-duration:.01ms!important}}
`;

  const ICON = {
    min: '<svg viewBox="0 0 18 18"><path d="M3 12h12"/></svg>',
    back: '<svg viewBox="0 0 18 18"><path d="M11 3L5 9l6 6"/></svg>',
    copy: '<svg viewBox="0 0 18 18"><path d="M6 6h9v9H6zM3 12V3h9"/></svg>',
    redo: '<svg viewBox="0 0 18 18"><path d="M15 9a6 6 0 1 1-2-4.5M15 3v4h-4"/></svg>',
    send: '<svg viewBox="0 0 18 18"><path d="M3 9h11M10 4l5 5-5 5"/></svg>',
    chev: '<svg viewBox="0 0 16 16"><path d="M3 6l5 5 5-5"/></svg>',
  };

  const host = document.createElement('div'); host.id = 'coe-island-host';
  host.style.cssText = 'all:initial;position:fixed;inset:0 0 auto 0;z-index:2147483647;pointer-events:none';
  document.documentElement.appendChild(host);
  const root = host.attachShadow({ mode: 'open' });
  root.innerHTML = '<style>' + CSS + '</style>' +
    '<div class="w" id="w" data-s="idle"><div class="pd" aria-hidden="true"><i></i><i></i><i></i></div>' +
    '<div class="stack"><div class="room" id="room" data-mode="open" data-s="idle">' +
    '<div class="ht" aria-hidden="true"><i></i><i></i><i></i></div>' +
    '<div class="minic" id="minic"><span class="mk">' + star('') + '</span><span class="dg" id="mdg"></span></div>' +
    '<div class="main" id="main"><div class="toast" id="toast" role="status"></div>' +
    '<div class="top"><span class="mk">' + star('') + '</span><button class="tt" id="ttb" aria-expanded="false"><b><span id="t1"></span><span class="dg" id="dg"></span></b><span id="t2"></span></button>' +
    '<button class="go" id="answer">Answer</button><button class="sq" id="min" aria-label="Make it small">' + ICON.min + '</button></div>' +
    '<div class="scroll" id="scroll">' +
    // ask / options
    '<div class="sc s-opts"><form class="sa" id="sa"><input class="fld" id="saq" placeholder="Search or ask" autocomplete="off" spellcheck="false" aria-label="Search or ask"></form>' +
    '<div class="opts"><button class="btn" id="hint">Hint only</button><button class="btn" id="all">Answer all</button><button class="btn" id="make">Make questions</button><button class="btn" id="rescan">Look again</button></div></div>' +
    // hint
    '<div class="sc s-hint"><p class="lab" id="hl"></p><p class="ht1" id="ht"></p><div class="row"><button class="sq" id="hback" aria-label="Back">' + ICON.back + '</button><button class="go" id="hnext" style="flex:1;display:block">Next hint</button></div></div>' +
    // loading
    '<div class="sc s-load"><div class="ld"><span class="blk"><i></i><i></i><i></i></span><span class="d" id="ldl" style="font-size:1.3rem">Working it out</span></div><div class="bar" id="bar"><i></i></div></div>' +
    // result
    '<div class="sc s-res"><div class="hero"><small>Answer</small><div class="ans" id="fa"></div></div>' +
    '<div class="cta"><button class="go" id="fill">Put in page</button><button class="sq" id="copy" aria-label="Copy the answer" title="Copy">' + ICON.copy + '</button><button class="sq" id="redo" aria-label="Redo it, free" title="Redo, free">' + ICON.redo + '</button></div>' +
    '<button class="disc" id="wk" aria-expanded="false"><span id="wkt">Show working</span>' + ICON.chev + '</button>' +
    '<div class="sec" id="work"><div><ol class="steps" id="steps"></ol><div class="mini"><button class="btn sm" id="simp">Explain simpler</button><button class="btn sm" id="chk">Check my answer</button><button class="btn sm" id="pbtn">Try one like it</button><button class="btn sm" id="coe">Continue in Coe</button></div>' +
    '<div class="sec" id="plainS"><div><p class="plain" id="plain"></p></div></div>' +
    '<div class="sec" id="prac"><div><div class="pr"><small>Your turn</small><p class="q" id="prq"></p><div class="prrow"><input class="fld" id="pri" placeholder="Your answer" autocomplete="off" style="height:42px"><button class="btn sm" id="prc">Check</button></div><p class="prm" id="prm"></p></div></div></div></div></div>' +
    '<p class="cr" id="cr"></p><form class="ask" id="ask"><input class="fld" id="q" placeholder="Ask a follow-up" autocomplete="off" spellcheck="false"><button class="sq" aria-label="Send">' + ICON.send + '</button></form></div>' +
    // all
    '<div class="sc s-all"><div class="ah"><b id="ahb"></b><span>Tap one to see the working</span></div><div class="list" id="list"></div><div class="allcta"><button class="sq" id="aback" aria-label="Back">' + ICON.back + '</button><button class="go" id="putall">Put all in page</button></div></div>' +
    // make questions
    '<div class="sc s-make"><div class="ah"><b>Make questions</b><span>From this page, or from a topic</span></div><form class="mf" id="mform"><input class="fld" id="mtopic" placeholder="Topic (leave empty to use this page)" autocomplete="off"><div class="cnt"><span>How many</span><button type="button" class="btn sm" data-n="3">3</button><button type="button" class="btn sm" data-n="5" aria-pressed="true">5</button><button type="button" class="btn sm" data-n="8">8</button></div></form>' +
    '<div id="mlist"></div><div class="allcta"><button class="sq" id="mback" aria-label="Back">' + ICON.back + '</button><button class="go" id="mgo">Make</button></div></div>' +
    '</div></div></div></div>';

  const $ = (id) => root.getElementById(id), W = $('w'), room = $('room'), main = $('main'), scroll = $('scroll');
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const swap = (el, html) => { if (el.innerHTML === html) return; el.classList.remove('sw'); void el.offsetWidth; el.innerHTML = html; el.classList.add('sw'); };
  const fmt = (n) => (n >= 1e6 ? (n / 1e6).toFixed(1).replace(/\.0$/, '') + 'M' : n >= 1e3 ? Math.round(n / 1e3) + 'k' : String(n));

  let qs = [], sel = 0, scene = 'opts', mode = 'open', busy = false, cur = null, hintN = 0, hints = [], hintOf = -1, prac = null, mcount = 5, undo = null;
  const results = {}, done = new Set();
  const pk = document.createElement('div'); pk.className = 'pk'; pk.id = 'pk'; pk.setAttribute('role', 'group'); pk.setAttribute('aria-label', 'Choose a question'); main.appendChild(pk);
  let credits = null;

  // ---- size: the room follows its content
  function size() {
    if (mode === 'min') { room.style.height = ''; return; }
    const w = Math.min(460, innerWidth - 32); room.style.width = w + 'px';
    scroll.style.setProperty('--sch', Math.max(200, innerHeight - 140 - (pk.classList.contains('on') ? 62 : 0)) + 'px');
    room.style.height = Math.min(main.offsetHeight, innerHeight - 40) + 'px';
  }
  new ResizeObserver(size).observe(main); addEventListener('resize', size);

  const SCENES = ['opts', 'hint', 'load', 'res', 'all', 'make'];
  function go(n) {
    scene = n; const state = { opts: 'idle', hint: 'hint', load: 'loading', res: 'result', all: 'all', make: 'make' }[n];
    W.dataset.s = state; room.dataset.s = state;
    SCENES.forEach((s) => { const el = scroll.querySelector('.s-' + s); if (s === n) { el.classList.remove('in'); void el.offsetWidth; el.classList.add('in'); } else el.classList.remove('in'); });
    $('ttb').setAttribute('aria-expanded', String(n === 'opts'));
    scroll.style.display = n === 'idle' ? 'none' : '';
    setTitles(); size();
  }
  function setTitles() {
    const N = qs.length, q = qs[sel];
    const t1 = { opts: N ? N + (N === 1 ? ' question' : ' questions') : 'Ask Coe', hint: 'Hint for Q' + (sel + 1), load: 'Working it out', res: N && q ? 'Q' + (sel + 1) + ' answered' : 'Answered', all: Object.keys(results).length + ' answers ready', make: 'Make questions' }[scene];
    swap($('t1'), esc(t1));
    swap($('t2'), esc(scene === 'make' ? 'Practice questions' : q ? 'Q' + (sel + 1) + ' · ' + q.text.slice(0, 80) : 'Ask anything, or open a page with questions'));
    dots();
  }
  function dots() {
    const max = 10, n = qs.length;
    const html = qs.slice(0, max).map((_, i) => '<i data-i="' + i + '" class="' + (i === sel ? 'on ' : '') + (done.has(i) ? 'dn' : '') + '" title="Question ' + (i + 1) + '"></i>').join('') + (n > max ? '<span class="more">+' + (n - max) + '</span>' : '');
    $('dg').innerHTML = html; $('mdg').innerHTML = html; $('answer').disabled = !n && false;
    // the picker along the bottom: a square for every question, with back and next
    const show = n > 1 && scene !== 'make';
    pk.classList.toggle('on', show);
    if (show) {
      pk.innerHTML = '<button class="sq" id="pkb" aria-label="Question before"' + (sel <= 0 ? ' disabled' : '') + '>' + ICON.back + '</button><div class="pkr" id="pkr">' +
        qs.map((_, i) => '<button class="pkc ' + (i === sel ? 'on ' : '') + (done.has(i) ? 'dn' : '') + '" data-i="' + i + '" aria-label="Question ' + (i + 1) + (done.has(i) ? ', done' : '') + '"' + (i === sel ? ' aria-current="true"' : '') + '>' + (i + 1) + '</button>').join('') +
        '</div><button class="sq" id="pkn" aria-label="Next question"' + (sel >= n - 1 ? ' disabled' : '') + '>' + ICON.send + '</button>';
      const on = pk.querySelector('.pkc.on'); if (on && on.scrollIntoView) { const r = pk.querySelector('#pkr'); r.scrollLeft = on.offsetLeft - r.clientWidth / 2 + on.offsetWidth / 2; }
    }
  }
  // picking from the bottom: if that question already has an answer, show it, else show its options
  function choose(i) {
    i = Math.max(0, Math.min(qs.length - 1, i)); if (busy) return;
    if (results[i] && qs[i]) { sel = i; present(qs[i], results[i]); go('res'); } else { sel = i; go('opts'); }
  }
  function pick(i) { sel = Math.max(0, Math.min(qs.length - 1, i)); if (scene !== 'opts' && !busy && scene !== 'make' && scene !== 'all') go('opts'); else setTitles(); }

  let tt;
  function toast(msg, action) {
    const t = $('toast'); t.innerHTML = '<span>' + esc(msg) + '</span>' + (action ? '<button>' + esc(action.label) + '</button>' : '');
    if (action) t.querySelector('button').onclick = action.run;
    t.classList.add('on'); clearTimeout(tt); tt = setTimeout(() => t.classList.remove('on'), action ? 6000 : 3200);
  }
  const problem = (r) => {
    if (r.code === 'signin') toast('Sign in on Coe first, then try again.', { label: 'Open Coe', run: () => chrome.runtime.sendMessage({ type: 'open-coe' }) });
    else if (r.code === 'setup') toast(r.error, { label: 'Open Coe', run: () => chrome.runtime.sendMessage({ type: 'open-coe' }) });
    else toast(r.error || 'Something went wrong. Try again.');
  };
  const note = (c) => { if (c) credits = c; $('cr').textContent = (credits ? fmt(credits.used) + ' of ' + fmt(credits.limit) + ' tokens today · ' : '') + 'redos are free'; };
  const ask = (body) => new Promise((res) => { try { chrome.runtime.sendMessage({ type: 'ask', body }, (r) => res(r || { ok: false, error: 'The extension was reloaded. Refresh this page.' })); } catch { res({ ok: false, error: 'The extension was reloaded. Refresh this page.' }); } });
  const optionsOf = (q) => (q && q.options && q.options.length ? q.options : undefined);

  async function load(label, fn) {
    busy = true; $('ldl').textContent = label || 'Working it out'; go('load');
    const t0 = Date.now(); let r;
    try { r = await fn(); } finally { busy = false; }
    const wait = 700 - (Date.now() - t0); if (wait > 0) await sleep(wait);
    return r;
  }

  // ---- one question
  function present(q, d) {
    cur = { q, d, text: q ? q.text : d._text };
    $('fa').textContent = d.answer || d.fill || '';
    $('steps').innerHTML = (d.steps || []).map((s, k) => '<li><span class="n">' + (k + 1) + '</span><div><div class="m">' + esc(s.m || '') + '</div>' + (s.c ? '<div class="c">' + esc(s.c) + '</div>' : '') + '</div></li>').join('');
    $('plain').textContent = d.simple || ''; $('plainS').classList.remove('o'); $('prac').classList.remove('o'); $('work').classList.remove('o');
    $('wk').setAttribute('aria-expanded', 'false'); $('wkt').textContent = 'Show working';
    $('pri').value = ''; $('prm').textContent = ''; $('fill').style.display = q ? '' : 'none'; $('chk').style.display = q ? '' : 'none';
    note();
  }
  async function solve(i, free, redo) {
    const q = qs[i]; if (!q) return;
    const images = await S.pictures(q.id).catch(() => []);
    const r = await load('Working it out', () => ask({ mode: 'solve', text: q.text, options: optionsOf(q), images, redo: !!redo }));
    if (!r.ok) { problem(r); go('opts'); return; }
    results[i] = r.data; done.add(i); credits = r.credits || credits;
    sel = i; present(q, r.data); go('res'); const a = $('fa'); a.classList.remove('pop'); void a.offsetWidth; a.classList.add('pop');
  }
  async function freeAsk(text, redo) {
    const r = await load('Working it out', () => ask({ mode: 'free', text, redo: !!redo }));
    if (!r.ok) { problem(r); go('opts'); return; }
    credits = r.credits || credits; r.data._text = text; present(null, r.data); go('res');
  }
  async function showHint(first) {
    const q = qs[sel]; if (!q) { toast('Open a page with questions, or type one in the box.'); return; }
    if (first || hintOf !== sel) {
      const images = await S.pictures(q.id).catch(() => []);
      const r = await load('Thinking of a nudge', () => ask({ mode: 'hint', text: q.text, options: optionsOf(q), images }));
      if (!r.ok) { problem(r); go('opts'); return; }
      credits = r.credits || credits; hints = (r.data.hints || []).slice(0, 3); hintOf = sel; hintN = 0;
      if (!hints.length) { toast('No hint this time. Try Answer.'); go('opts'); return; }
    }
    $('hl').textContent = 'Hint ' + (hintN + 1) + ' of ' + hints.length; $('ht').textContent = hints[hintN]; $('hnext').textContent = hintN < hints.length - 1 ? 'Next hint' : 'Show the answer';
    go('hint');
  }
  async function solveAll() {
    if (!qs.length) { toast('No questions found on this page. Try Look again.'); return; }
    busy = true; go('load'); $('ldl').textContent = 'Answering ' + qs.length; $('bar').classList.add('on'); $('bar').firstElementChild.style.width = '8%';
    const items = qs.slice(0, 12); let all = [];
    const r = await ask({ mode: 'many', items: items.map((q) => ({ text: q.text, options: optionsOf(q) })) });
    busy = false; $('bar').classList.remove('on');
    if (!r.ok) { problem(r); go('opts'); return; }
    credits = r.credits || credits; all = r.data.items || [];
    all.forEach((d) => { const i = (d.n || 0) - 1; if (i >= 0 && i < items.length) { results[i] = d; done.add(i); } });
    $('bar').firstElementChild.style.width = '100%'; note();
    $('ahb').textContent = Object.keys(results).length + ' answers';
    $('list').innerHTML = items.map((q, i) => results[i] ? '<div class="rw" data-i="' + i + '"><span class="q">' + (i + 1) + '</span><div class="e"><b>' + esc(results[i].answer || results[i].fill || '') + '</b><span>' + esc(q.text) + '</span></div><button class="btn sm" data-f="' + i + '">Fill</button></div>' : '').join('');
    go('all');
  }
  const fillOne = (i) => { const d = results[i]; if (!d) return null; return S.fill(qs[i].id, d.fill || d.answer); };
  async function fillAndConfirm(i) { const u = fillOne(i); if (!u) { toast('That one needs you. Pick it on the page.'); return; } undo = u; toast('Put in. ', { label: 'Undo', run: () => { try { undo && undo(); } catch {} $('toast').classList.remove('on'); } }); }

  // ---- make questions
  const same = (a, b) => { const x = S.num(a), y = S.num(b); if (x != null && y != null && /\d/.test(a) && /\d/.test(b)) return Math.abs(x - y) < 1e-6; const p = S.norm(a).replace(/^[a-z]\s*=\s*/, ''), q = S.norm(b).replace(/^[a-z]\s*=\s*/, ''); return !!p && (p === q || (q.length > 3 && p.includes(q))); };
  const pcard = (x, i) => '<div class="pq" data-i="' + i + '"><small>Question ' + (i + 1) + '</small><p>' + esc(x.q) + '</p><div class="prrow"><input class="fld" placeholder="Your answer" autocomplete="off" style="height:42px"><button class="btn sm" data-c="' + i + '">Check</button><button class="btn sm" data-h="' + i + '">Hint</button></div><p class="prm"></p></div>';
  let made = [];
  async function makeQs(topic) {
    const r = await load('Making questions', () => ask({ mode: 'make', topic: topic || '', page: topic ? '' : S.pageText(), count: mcount }));
    go('make'); if (!r.ok) { problem(r); return; }
    credits = r.credits || credits; made = (r.data.questions || []).filter((x) => x && x.q); note();
    $('mlist').innerHTML = made.map(pcard).join('') || '<p class="plain">Nothing came back. Try a topic.</p>'; size();
  }

  // ---- events
  $('answer').onclick = () => (qs.length ? solve(sel, false) : (go('opts'), $('saq').focus()));
  $('ttb').onclick = (e) => { if (e.target.closest('i')) { pick(+e.target.closest('i').dataset.i); return; } if (busy) return; if (scene === 'opts') { scroll.style.display = scroll.style.display === 'none' ? '' : 'none'; $('ttb').setAttribute('aria-expanded', String(scroll.style.display !== 'none')); size(); } else go('opts'); };
  pk.onclick = (e) => { const c = e.target.closest('.pkc'), b = e.target.closest('#pkb'), n = e.target.closest('#pkn'); if (c) choose(+c.dataset.i); else if (b && !b.disabled) choose(sel - 1); else if (n && !n.disabled) choose(sel + 1); };
  $('mdg').onclick = (e) => { const i = e.target.closest('i'); if (i) { e.stopPropagation(); pick(+i.dataset.i); } };
  $('sa').onsubmit = (e) => { e.preventDefault(); const v = $('saq').value.trim(); if (v) { $('saq').value = ''; freeAsk(v); } };
  $('hint').onclick = () => showHint(true);
  $('hnext').onclick = () => { if (hintN < hints.length - 1) { hintN++; showHint(false); } else solve(sel, false); };
  $('hback').onclick = () => go('opts');
  $('all').onclick = solveAll;
  $('make').onclick = () => { go('make'); };
  $('rescan').onclick = () => { rescan(); toast(qs.length ? 'Found ' + qs.length + (qs.length === 1 ? ' question.' : ' questions.') : 'No questions found here.'); };
  $('list').onclick = (e) => { const b = e.target.closest('[data-f]'), r = e.target.closest('.rw'); if (b) { e.stopPropagation(); fillAndConfirm(+b.dataset.f); return; } if (r) { const i = +r.dataset.i; sel = i; present(qs[i], results[i]); go('res'); } };
  $('putall').onclick = () => { let n = 0; const ups = []; Object.keys(results).forEach((i) => { const u = fillOne(+i); if (u) { ups.push(u); n++; } }); undo = () => ups.forEach((u) => u()); toast(n ? 'Put in ' + n + '. ' : 'Nothing could be filled in.', n ? { label: 'Undo', run: () => { undo(); $('toast').classList.remove('on'); } } : null); };
  $('aback').onclick = () => go('opts');
  $('ask').onsubmit = (e) => { e.preventDefault(); const v = $('q').value.trim(); if (v) { $('q').value = ''; freeAsk(v); } };
  $('wk').onclick = () => { const o = !$('work').classList.contains('o'); $('work').classList.toggle('o', o); $('wk').setAttribute('aria-expanded', String(o)); $('wkt').textContent = o ? 'Hide working' : 'Show working'; };
  $('redo').onclick = () => { if (!cur) return; if (cur.q) solve(cur.q.id, true, true); else freeAsk(cur.text, true); };
  $('simp').onclick = () => $('plainS').classList.toggle('o');
  $('copy').onclick = async () => { try { await navigator.clipboard.writeText(cur.d.fill || cur.d.answer || ''); toast('Copied.'); } catch { toast('Could not copy here.'); } };
  $('fill').onclick = () => cur && cur.q && fillAndConfirm(cur.q.id);
  $('chk').onclick = () => { if (!cur || !cur.q) return; const mine = S.current(cur.q.id); if (!mine) { toast('Put your own answer in the page first.'); return; } toast(same(mine, cur.d.fill || cur.d.answer) ? 'Correct.' : 'Not quite. Look at the working.'); };
  $('pbtn').onclick = async () => {
    if (!cur) return; const r = await ask({ mode: 'like', text: cur.text || (cur.q && cur.q.text) || '' });
    if (!r.ok) { problem(r); return; } credits = r.credits || credits; note();
    const x = (r.data.questions || [])[0]; if (!x) return; prac = x; $('prq').textContent = x.q; $('pri').value = ''; $('prm').textContent = ''; $('prm').className = 'prm'; $('prac').classList.add('o'); setTimeout(() => $('pri').focus(), 450);
  };
  $('coe').onclick = () => {
    if (!cur) return; const d = cur.d || {}, qx = cur.text || (cur.q && cur.q.text) || '';
    const w = (d.steps || []).map((x, i) => (i + 1) + '. ' + x.m + (x.c ? ' (' + x.c + ')' : '')).join('\n');
    chrome.runtime.sendMessage({ type: 'handoff', text: 'I was working on this:\n' + qx + '\n\nThe answer I got: ' + (d.answer || d.fill || '') + (w ? '\n\nWorking:\n' + w : '') + '\n\nHelp me understand it properly.' });
  };
  $('prc').onclick = () => { if (!prac) return; const ok = same($('pri').value, prac.a); $('prm').className = 'prm ' + (ok ? 'ok' : 'no'); $('prm').textContent = ok ? 'Correct. Try another?' : 'Not quite. Have another go.'; };
  $('pri').onkeydown = (e) => { if (e.key === 'Enter') $('prc').click(); };
  $('mform').onsubmit = (e) => { e.preventDefault(); makeQs($('mtopic').value.trim()); };
  $('mform').onclick = (e) => { const b = e.target.closest('[data-n]'); if (!b) return; mcount = +b.dataset.n; $('mform').querySelectorAll('[data-n]').forEach((x) => x.setAttribute('aria-pressed', String(x === b))); };
  $('mgo').onclick = () => makeQs($('mtopic').value.trim());
  $('mback').onclick = () => go('opts');
  $('mlist').onclick = (e) => {
    const c = e.target.closest('[data-c]'), h = e.target.closest('[data-h]'); const card = e.target.closest('.pq'); if (!card) return; const i = +card.dataset.i, m = card.querySelector('.prm');
    if (c) { const ok = same(card.querySelector('input').value, made[i].a); m.className = 'prm ' + (ok ? 'ok' : 'no'); m.textContent = ok ? 'Correct.' : 'Not quite. The answer is ' + made[i].a + '.'; size(); }
    if (h) { m.className = 'prm'; m.textContent = made[i].hint || 'Try it step by step.'; size(); }
  };
  $('min').onclick = (e) => { e.stopPropagation(); setMin(true); };
  room.addEventListener('click', (e) => { if (mode === 'min') { e.stopPropagation(); setMin(false); } });
  function setMin(on) { mode = on ? 'min' : 'open'; room.dataset.mode = mode; if (on) { room.style.height = ''; room.style.width = ''; } else size(); }
  root.addEventListener('keydown', (e) => { if (e.key === 'Escape') setMin(true); });

  function rescan() { const keep = qs[sel] && qs[sel].text; qs = S.scan(); const k = keep ? qs.findIndex((q) => q.text === keep) : -1; sel = k >= 0 ? k : Math.min(sel, Math.max(0, qs.length - 1)); setTitles(); }
  const stop = S.watch(() => { if (!busy && mode !== 'x') rescan(); });

  window.__coeIsland = {
    toggle() { if (host.style.display === 'none') { host.style.display = ''; rescan(); } else host.style.display = 'none'; },
    destroy() { stop(); host.remove(); delete window.__coeIsland; },
  };

  // ---- boot: drops in as a small bar, then shows how many questions it found
  rescan(); go('opts'); scroll.style.display = 'none';
  chrome.runtime.sendMessage({ type: 'status' }, (r) => { if (r && r.ok && r.limit) { credits = { used: r.used, limit: r.limit }; note(); } if (r && r.ok === false && r.code === 'setup') toast(r.error, { label: 'Open Coe', run: () => chrome.runtime.sendMessage({ type: 'open-coe' }) }); });
  size();
  if (startSmall) setMin(true);
})();
