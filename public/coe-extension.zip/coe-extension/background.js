// The extension's brain. It holds your Coe sign-in, talks to your Coe server (the page itself never does), and keeps the answers in a fixed shape.
const store = {
  get: (k) => chrome.storage.local.get(k),
  set: (o) => chrome.storage.local.set(o),
};

const BASE = 'You are Coe, helping a student understand and do their own schoolwork. Be accurate. Use plain, short words. Reply with one JSON object only. No markdown fences and no words outside the JSON.';
const SOLVE = '{"answer":"the short final answer","fill":"exactly what to type, or the exact option to pick","steps":[{"m":"one line of working","c":"why, in a few words"}],"hints":["first nudge, without the answer","second nudge, nearly there"],"simple":"two plain sentences that explain it"}';

function prompt(b) {
  const q = (x, i) => `${i == null ? '' : `Question ${i + 1}:\n`}${x.text}${x.options?.length ? `\nOptions:\n${x.options.map((o) => `- ${o}`).join('\n')}` : ''}`;
  switch (b.mode) {
    case 'solve': case 'free': return { text: `${q(b)}\n\nReply with JSON like this: ${SOLVE}`, max: 1100 };
    case 'hint': return { text: `${q(b)}\n\nDo not give the answer. Reply with JSON like this: {"hints":["first nudge","second nudge, nearly there"]}`, max: 400 };
    case 'many': return { text: `${b.items.map(q).join('\n\n')}\n\nAnswer every question. Reply with JSON like this: {"items":[{"n":1,"answer":"...","fill":"...","steps":[{"m":"...","c":"..."}]}]}. n is the question number.`, max: 3200 };
    case 'make': return { text: `${b.topic ? `Topic: ${b.topic}` : `Here is the text of a page the student is working on:\n${(b.page || '').slice(0, 5000)}`}\n\nMake ${b.count || 5} practice questions that test it. Mix easy and harder. Keep each answer short. Reply with JSON like this: {"questions":[{"q":"the question","a":"the short answer","hint":"a nudge"}]}`, max: 1800 };
    case 'like': return { text: `${q(b)}\n\nMake ONE new question of the same kind with different numbers or details. Reply with JSON like this: {"questions":[{"q":"the question","a":"the short answer","hint":"a nudge"}]}`, max: 500 };
    default: return { text: String(b.text || ''), max: 800 };
  }
}

const cfg = async () => {
  const s = await store.get(['session', 'ext', 'code', 'serverUrl', 'me', 'speed']);
  const server = String((s.ext && s.ext.server) || s.serverUrl || '').trim().replace(/\/+$/, '');
  return { ...s, server };
};

let waiting = null;
// Coe's own tab refreshes the sign-in when it opens. So when it has run out, open Coe quietly, wait for it, and close it again.
function refreshViaSite() {
  if (waiting) return waiting;
  waiting = new Promise((resolve) => {
    let tabId = null, done = false;
    const finish = (ok) => { if (done) return; done = true; waiting = null; chrome.runtime.onMessage.removeListener(on); if (tabId != null) chrome.tabs.remove(tabId).catch(() => {}); resolve(ok); };
    const on = (m, sender) => { if (m && m.type === 'sync' && sender.tab && sender.tab.id === tabId && m.session && m.session.exp - Date.now() > 60000) setTimeout(() => finish(true), 300); };
    chrome.runtime.onMessage.addListener(on);
    chrome.tabs.create({ url: 'https://coe.pmcstudios.uk/', active: false }).then((t) => { tabId = t.id; }).catch(() => finish(false));
    setTimeout(() => finish(false), 14000);
  });
  return waiting;
}
async function token() {
  let { session } = await store.get('session');
  if (!session || !session.access) return null;
  if (session.exp - Date.now() > 60000) return session.access;
  await refreshViaSite();
  ({ session } = await store.get('session'));
  return session && session.exp > Date.now() ? session.access : null;
}

async function call(path, init, c) {
  const h = { 'content-type': 'application/json', ...(init.headers || {}) };
  const t = await token(); if (t) h.authorization = 'Bearer ' + t;
  if (c.code) h['x-coe-code'] = c.code;
  return fetch(c.server + path, { ...init, headers: h });
}
const why = async (res) => { let m = '', code = ''; try { const j = await res.json(); m = j.error?.message || ''; code = j.error?.code || ''; } catch { /* no body */ } return { ok: false, error: m || `The server said ${res.status}.`, code: code || (res.status === 401 ? 'signin' : res.status === 402 ? 'limit' : '') }; };

async function status() {
  const c = await cfg();
  const { session } = await store.get('session');
  if (!c.server) return { ok: false, code: 'setup', error: 'Open Coe once and sign in, so this extension can find your Coe server.' };
  try {
    const res = await call('/me', { method: 'GET' }, c);
    if (!res.ok) return { ...(await why(res)), signedIn: !!session };
    const j = await res.json();
    return { ok: true, signedIn: !!j.signedIn, email: j.email || (session && session.email) || '', plan: j.plan, used: j.used, limit: j.limit };
  } catch { return { ok: false, code: 'network', error: 'Could not reach the Coe server.' }; }
}

async function ask(b) {
  const c = await cfg();
  if (!c.server) return { ok: false, code: 'setup', error: 'Open Coe once and sign in, so this extension can find your Coe server.' };
  const p = prompt(b);
  const images = (b.images || []).slice(0, 2);
  const user = images.length ? [...images.map((u) => ({ type: 'image_url', image_url: { url: u } })), { type: 'text', text: p.text }] : p.text;
  const mine = c.me ? [c.me.name && `The student is called ${c.me.name}.`, c.me.tone && `Tone: ${c.me.tone}.`, c.me.length && `Answer length: ${c.me.length}.`, c.me.system && `Their standing instructions: ${c.me.system}`].filter(Boolean).join(' ') : '';
  const body = { model: b.model || (['swift', 'core', 'deep'].includes(c.speed) ? c.speed : 'core'), stream: true, stream_options: { include_usage: true }, max_completion_tokens: p.max, messages: [{ role: 'system', content: mine ? BASE + ' ' + mine : BASE }, { role: 'user', content: user }] };
  let res;
  try { res = await call('/', { method: 'POST', body: JSON.stringify(body), headers: b.redo ? { 'x-coe-redo': '1' } : {} }, c); }
  catch { return { ok: false, code: 'network', error: 'Could not reach the Coe server.' }; }
  if (!res.ok) return await why(res);
  let used = res.headers.get('x-coe-used'), limit = res.headers.get('x-coe-limit'), plan = res.headers.get('x-coe-plan');
  let text = '';
  try {
    const rd = res.body.getReader(), dec = new TextDecoder(); let buf = '';
    for (;;) {
      const { done, value } = await rd.read(); if (done) break;
      buf += dec.decode(value, { stream: true });
      let i; while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
        if (!line.startsWith('data:')) continue;
        const d = line.slice(5).trim(); if (d === '[DONE]') continue;
        try { const j = JSON.parse(d); if (j.coe_usage) { used = j.coe_usage.used; limit = j.coe_usage.limit; plan = j.coe_usage.plan; } text += j.choices?.[0]?.delta?.content || ''; } catch { /* partial line */ }
      }
    }
  } catch { return { ok: false, code: 'network', error: 'The reply was cut off. Try again.' }; }
  const a = text.indexOf('{'), z = text.lastIndexOf('}');
  let data = null; if (a >= 0 && z > a) { try { data = JSON.parse(text.slice(a, z + 1)); } catch { /* not JSON */ } }
  if (!data) return { ok: false, code: 'shape', error: 'That did not come back in a form I could read. Try again.' };
  return { ok: true, data, credits: used != null && limit != null ? { used: Number(used), limit: Number(limit), plan } : null };
}

chrome.runtime.onMessage.addListener((m, sender, reply) => {
  if (!m || !m.type) return;
  if (m.type === 'sync') { store.set({ session: m.session && m.session.access ? m.session : null, ext: m.ext || null, code: m.code || '', serverUrl: m.serverUrl || '', me: m.me || null, site: m.site || '', coeTab: sender.tab ? sender.tab.id : null }); return; }
  if (m.type === 'status') { status().then(reply); return true; }
  if (m.type === 'ask') { ask(m.body || {}).then(reply); return true; }
  if (m.type === 'open-coe') { openCoe(m.page ? '#' + m.page : '', false); return; }
  if (m.type === 'handoff') { store.set({ handoff: { text: String(m.text || ''), ts: Date.now() } }).then(() => openCoe('', true)); return; }
  if (m.type === 'show') { show(m.tabId); return; }
});

// Brings the open Coe tab to the front, or opens one.
async function openCoe(hash, reuse) {
  const { site, coeTab } = await store.get(['site', 'coeTab']);
  const base = (site || 'https://coe.pmcstudios.uk').replace(/\/+$/, '') + '/';
  if (reuse && coeTab != null) {
    try { const t = await chrome.tabs.get(coeTab); await chrome.tabs.update(t.id, { active: true }); await chrome.windows.update(t.windowId, { focused: true }); return; } catch { /* that tab is gone */ }
  }
  chrome.tabs.create({ url: base + hash });
}

async function show(tabId) {
  if (tabId == null) { const [t] = await chrome.tabs.query({ active: true, currentWindow: true }); tabId = t && t.id; }
  if (tabId == null) return;
  try { await chrome.scripting.executeScript({ target: { tabId }, func: () => { window.__coeForce = true; } }); await chrome.scripting.executeScript({ target: { tabId }, files: ['scan.js', 'island.js'] }); } catch { /* a page Chrome does not allow */ }
}
chrome.commands.onCommand.addListener((c) => { if (c === 'toggle-coe') show(); });
