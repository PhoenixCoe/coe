const $ = (id) => document.getElementById(id);
chrome.storage.local.get('auto').then((s) => { $('auto').checked = s.auto !== false; });
$('auto').onchange = () => chrome.storage.local.set({ auto: $('auto').checked });
$('show').onclick = async () => { const [t] = await chrome.tabs.query({ active: true, currentWindow: true }); chrome.runtime.sendMessage({ type: 'show', tabId: t && t.id }); window.close(); };
$('open').onclick = () => { chrome.runtime.sendMessage({ type: 'open-coe' }); window.close(); };
$('set').onclick = () => { chrome.runtime.sendMessage({ type: 'open-coe', page: 'chrome' }); window.close(); };
$('keys').onclick = () => chrome.tabs.create({ url: 'chrome://extensions/shortcuts' });
chrome.runtime.sendMessage({ type: 'status' }, (r) => {
  if (!r) { $('who').textContent = 'Not ready'; return; }
  if (r.ok && r.signedIn) { $('who').textContent = 'Signed in'; $('use').textContent = (r.email || '') + (r.limit ? '  ·  ' + Math.round(r.used / 1000) + 'k of ' + Math.round(r.limit / 1000) + 'k tokens today' : ''); }
  else if (r.ok) { $('who').textContent = 'Not signed in'; $('use').textContent = 'Open Coe and sign in to use your account.'; }
  else { $('who').textContent = r.code === 'setup' ? 'Open Coe once' : 'Cannot reach Coe'; $('use').textContent = r.error || ''; }
});
