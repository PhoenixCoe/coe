// Coe Mini: the things Coe draws in an answer (graphs, data tables, slides, every kind of chart, "what next" buttons),
// the Study screen, the select-words bar, and the home screen, so the sidebar matches the website.
(() => {
  'use strict';
  const CX = window.CX; if (!CX) return;
  const SH = window.COE_SHARED || {};

  function start() {
    const { S, $, el, esc, bkBtn, renderMsgs, mdInline, store, first, openDlg, closeDlg, bg } = CX;
    const IC = CX.IC || (() => '');
    const say = (t) => CX.say && CX.say(t);
    const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
    const COLS = ['#337957', '#B49A57', '#171717', '#A33A2B', '#2F5D8A', '#6B4A8B', '#C77B2A', '#3C8F8F'];
    const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : NaN; };
    for (const b of ['graph', 'data', 'slides', 'followups', 'html', 'htm', 'mermaid', 'coe-remember']) if (!CX.BLK.includes(b)) CX.BLK.push(b);
    Object.assign(CX.titles, { graph: 'Graph', data: 'Data', slides: 'Slides', html: 'Page', htm: 'Page', mermaid: 'Diagram', followups: '' });
    const nice = (range, target) => { const raw = range / (target || 8), p = Math.pow(10, Math.floor(Math.log10(raw))), m = raw / p; return (m < 1.5 ? 1 : m < 3.5 ? 2 : m < 7.5 ? 5 : 10) * p; };
    const fmt = (v) => { if (Math.abs(v) < 1e-12) return '0'; const a = Math.abs(v); return a >= 1e6 || a < 1e-3 ? v.toExponential(2).replace('e+', 'e') : String(+v.toPrecision(4)); };
    const FONT = "font-family:'Coe L4 Upright','Courier New',monospace";

    // ============================================================ a safe maths expression reader (nothing the model wrote is ever run)
    const FN = { sin: Math.sin, cos: Math.cos, tan: Math.tan, asin: Math.asin, acos: Math.acos, atan: Math.atan, sinh: Math.sinh, cosh: Math.cosh, tanh: Math.tanh, sqrt: Math.sqrt, cbrt: Math.cbrt, abs: Math.abs, log: Math.log, ln: Math.log, log10: Math.log10, log2: Math.log2, exp: Math.exp, floor: Math.floor, ceil: Math.ceil, round: Math.round, sign: Math.sign, min: Math.min, max: Math.max, pow: Math.pow, atan2: Math.atan2 };
    const CONST = { pi: Math.PI, e: Math.E, tau: 2 * Math.PI };
    function compile(src, vars) {
      const s = String(src).replace(/π/g, 'pi').replace(/θ/g, 'theta').replace(/\*\*/g, '^').replace(/×/g, '*').replace(/÷/g, '/').replace(/[−–]/g, '-').replace(/\s+/g, ' ').trim();
      if (!s || s.length > 200 || /[;{}\\[\]]/.test(s)) throw new Error('bad');
      const toks = []; const re = /\s*(?:(\d+\.?\d*(?:e[+-]?\d+)?|\.\d+)|([a-z_][a-z0-9_]*)|(.))/gi; let m;
      while ((m = re.exec(s)) && m[0].length) { if (m[1] !== undefined) toks.push({ n: Number(m[1]) }); else if (m[2] !== undefined) toks.push({ id: m[2].toLowerCase() }); else if (m[3] && m[3].trim()) toks.push({ op: m[3] }); }
      let i = 0; const pk = () => toks[i], nx = () => toks[i++], isOp = (o) => pk() && pk().op === o;
      const sc = {};
      const expr = () => { let a = term(); while (pk() && (isOp('+') || isOp('-'))) { const o = nx().op, b = term(), x = a; a = o === '+' ? () => x() + b() : () => x() - b(); } return a; };
      const startsFactor = () => { const t = pk(); return t && (t.n !== undefined || t.id !== undefined || t.op === '('); };
      const term = () => { let a = unary(); for (;;) { if (isOp('*') || isOp('/')) { const o = nx().op, b = unary(), x = a; a = o === '*' ? () => x() * b() : () => x() / b(); } else if (startsFactor()) { const b = power(), x = a; a = () => x() * b(); } else break; } return a; };
      const unary = () => { if (isOp('-')) { nx(); const a = unary(); return () => -a(); } if (isOp('+')) { nx(); return unary(); } return power(); };
      const power = () => { const a = primary(); if (isOp('^')) { nx(); const b = unary(); return () => Math.pow(a(), b()); } return a; };
      const primary = () => {
        const t = nx(); if (!t) throw new Error('end');
        if (t.n !== undefined) return () => t.n;
        if (t.op === '(') { const a = expr(); if (!isOp(')')) throw new Error('paren'); nx(); return a; }
        if (t.id !== undefined) {
          if (FN[t.id]) {
            const f = FN[t.id], args = [];
            if (isOp('(')) { nx(); if (!isOp(')')) { args.push(expr()); while (isOp(',')) { nx(); args.push(expr()); } } if (!isOp(')')) throw new Error('paren'); nx(); } else args.push(power());
            return () => f(...args.map((a) => a()));
          }
          if (CONST[t.id] !== undefined && !vars.includes(t.id)) return () => CONST[t.id];
          if (vars.includes(t.id)) return () => sc[t.id];
          throw new Error('name ' + t.id);
        }
        throw new Error('token');
      };
      const root = expr(); if (i < toks.length) throw new Error('extra');
      return (...vals) => { vars.forEach((v, k) => { sc[v] = vals[k]; }); return root(); };
    }
    const rangeOf = (s) => {
      const m = /^\s*(.+?)\s*(?:\.\.|\bto\b|,)\s*(.+?)\s*$/i.exec(String(s)); if (!m) return null;
      try { const a = compile(m[1], [])(), b = compile(m[2], [])(); return Number.isFinite(a) && Number.isFinite(b) && a < b ? [a, b] : null; } catch { return null; }
    };

    // ============================================================ graph: drag it, zoom it
    function parseGraph(code) {
      const g = { fns: [], pts: [], title: '', xr: null, yr: null }, errs = [];
      for (const raw of String(code).split(/\n|;/)) {
        const line = raw.trim().replace(/^[-*]\s+/, ''); if (!line) continue; let m;
        if ((m = /^title\s*:\s*(.+)$/i.exec(line))) { g.title = m[1].trim().slice(0, 80); continue; }
        if ((m = /^x\s*:\s*(.+)$/i.exec(line))) { g.xr = rangeOf(m[1]); continue; }
        if ((m = /^y\s*:\s*(.+)$/i.exec(line))) { g.yr = rangeOf(m[1]); continue; }
        if ((m = /^points?\s*:\s*(.+)$/i.exec(line))) { const re = /\(\s*(-?[\d.]+(?:e-?\d+)?)\s*,\s*(-?[\d.]+(?:e-?\d+)?)\s*\)\s*([^,(]*)/g; let p; while ((p = re.exec(m[1]))) g.pts.push({ x: Number(p[1]), y: Number(p[2]), label: p[3].trim().slice(0, 20) }); continue; }
        try {
          if ((m = /^(?:r|ρ)\s*(?:\(\s*(?:theta|θ|t)\s*\))?\s*=\s*(.+)$/i.exec(line))) g.fns.push({ kind: 'polar', label: 'r = ' + m[1].trim(), f: compile(m[1], ['theta']) });
          else if ((m = /^x\s*=\s*(.+)$/i.exec(line))) { const c = compile(m[1], [])(); if (Number.isFinite(c)) g.fns.push({ kind: 'vline', label: 'x = ' + m[1].trim(), c }); }
          else { const body = (m = /^(?:y|f|g|h)\s*(?:\(\s*x\s*\))?\s*=\s*(.+)$/i.exec(line)) ? m[1] : line; g.fns.push({ kind: 'y', label: 'y = ' + body.trim(), f: compile(body, ['x']) }); }
        } catch { errs.push(line); }
        if (g.fns.length >= 8) break;
      }
      g.errs = errs; return g;
    }
    function drawGraph(host, g, st) {
      const W = 640, H = 420, L = 8, T = 8, R = 8, B = 8, pw = W - L - R, ph = H - T - B;
      if (!st.v) {
        let xr = g.xr, yr = g.yr;
        const polar = g.fns.some((f) => f.kind === 'polar');
        if (!xr) xr = polar ? [-6, 6] : [-10, 10];
        if (!yr) {
          const ys = []; for (const f of g.fns) if (f.kind === 'y') for (let k = 0; k <= 200; k++) { const y = f.f(xr[0] + ((xr[1] - xr[0]) * k) / 200); if (Number.isFinite(y) && Math.abs(y) < 1e4) ys.push(y); }
          for (const p of g.pts) ys.push(p.y);
          if (polar && !ys.length) { let mx = 0; for (const f of g.fns) if (f.kind === 'polar') for (let k = 0; k <= 400; k++) { const r = f.f((k / 400) * Math.PI * 2); if (Number.isFinite(r)) mx = Math.max(mx, Math.abs(r)); } mx = mx || 4; xr = [-mx * 1.15, mx * 1.15]; yr = [-mx * 1.15 * (ph / pw), mx * 1.15 * (ph / pw)]; }
          else if (ys.length) { ys.sort((a, b) => a - b); const lo = ys[Math.floor(ys.length * 0.03)], hi = ys[Math.ceil(ys.length * 0.97) - 1], pad = (hi - lo || 2) * 0.12; yr = [lo - pad, hi + pad]; if (yr[0] > 0) yr[0] = -pad; if (yr[1] < 0) yr[1] = pad; }
          else yr = [-6, 6];
        }
        st.v = { x0: xr[0], x1: xr[1], y0: yr[0], y1: yr[1] }; st.home = { ...st.v };
      }
      const v = st.v, X = (x) => L + ((x - v.x0) / (v.x1 - v.x0)) * pw, Y = (y) => T + ph - ((y - v.y0) / (v.y1 - v.y0)) * ph;
      let s = '<rect x="0" y="0" width="' + W + '" height="' + H + '" fill="var(--paper)"/>';
      const sx = nice(v.x1 - v.x0, 8), sy = nice(v.y1 - v.y0, 6), ax = Y(Math.max(v.y0, Math.min(v.y1, 0))), ay = X(Math.max(v.x0, Math.min(v.x1, 0)));
      for (let x = Math.ceil(v.x0 / sx) * sx; x <= v.x1 + 1e-9; x += sx) { const px = X(x); s += '<line x1="' + px.toFixed(1) + '" x2="' + px.toFixed(1) + '" y1="' + T + '" y2="' + (H - B) + '" stroke="currentColor" stroke-opacity=".13"/>'; if (Math.abs(x) > sx / 2) s += '<text x="' + px.toFixed(1) + '" y="' + clamp(ax + 18, 18, H - 6).toFixed(1) + '" text-anchor="middle" font-size="16" fill="currentColor" opacity=".75">' + fmt(x) + '</text>'; }
      for (let y = Math.ceil(v.y0 / sy) * sy; y <= v.y1 + 1e-9; y += sy) { const py = Y(y); s += '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + py.toFixed(1) + '" y2="' + py.toFixed(1) + '" stroke="currentColor" stroke-opacity=".13"/>'; if (Math.abs(y) > sy / 2) s += '<text x="' + clamp(ay - 6, 40, W - 4).toFixed(1) + '" y="' + (py + 5).toFixed(1) + '" text-anchor="end" font-size="16" fill="currentColor" opacity=".75">' + fmt(y) + '</text>'; }
      s += '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + ax.toFixed(1) + '" y2="' + ax.toFixed(1) + '" stroke="currentColor" stroke-width="2.5"/><line x1="' + ay.toFixed(1) + '" x2="' + ay.toFixed(1) + '" y1="' + T + '" y2="' + (H - B) + '" stroke="currentColor" stroke-width="2.5"/>';
      g.fns.forEach((f, k) => {
        const c = COLS[k % COLS.length]; let d = '';
        if (f.kind === 'vline') { const px = X(f.c); d = 'M' + px.toFixed(1) + ' ' + T + 'V' + (H - B); }
        else if (f.kind === 'polar') { let pen = false; for (let q = 0; q <= 720; q++) { const th = (q / 720) * Math.PI * 4, r = f.f(th); if (!Number.isFinite(r)) { pen = false; continue; } d += (pen ? 'L' : 'M') + X(r * Math.cos(th)).toFixed(1) + ' ' + Y(r * Math.sin(th)).toFixed(1); pen = true; } }
        else { let pen = false, last = NaN; const span = v.y1 - v.y0; for (let q = 0; q <= 600; q++) { const x = v.x0 + ((v.x1 - v.x0) * q) / 600, y = f.f(x); if (!Number.isFinite(y) || Math.abs(y) > 1e7 || (pen && Math.abs(y - last) > span * 3)) { pen = false; last = NaN; continue; } d += (pen ? 'L' : 'M') + X(x).toFixed(1) + ' ' + Y(y).toFixed(1); pen = true; last = y; } }
        if (d) s += '<path d="' + d + '" fill="none" stroke="' + c + '" stroke-width="3.2" stroke-linejoin="round"/>';
      });
      for (const p of g.pts) { const px = X(p.x), py = Y(p.y); s += '<circle cx="' + px.toFixed(1) + '" cy="' + py.toFixed(1) + '" r="6" fill="var(--paper)" stroke="currentColor" stroke-width="3"/>' + (p.label ? '<text x="' + (px + 9).toFixed(1) + '" y="' + (py - 8).toFixed(1) + '" font-size="17" fill="currentColor">' + esc(p.label) + '</text>' : ''); }
      const svg = '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" role="img" aria-label="Graph: ' + esc(g.title || g.fns.map((f) => f.label).join(', ')) + '" style="color:var(--ink);touch-action:none;cursor:grab;display:block;' + FONT + '">' + s + '</svg>';
      host.innerHTML = svg;
      const sv = host.firstChild;
      const toU = (e) => { const r = sv.getBoundingClientRect(); return { fx: (e.clientX - r.left) / r.width, fy: (e.clientY - r.top) / r.height, r }; };
      let drag = null;
      sv.onpointerdown = (e) => { drag = { x: e.clientX, y: e.clientY, v: { ...st.v } }; try { sv.setPointerCapture(e.pointerId); } catch { /* ok */ } sv.style.cursor = 'grabbing'; };
      sv.onpointermove = (e) => { if (!drag) return; const r = sv.getBoundingClientRect(), dx = ((e.clientX - drag.x) / r.width) * (drag.v.x1 - drag.v.x0), dy = ((e.clientY - drag.y) / r.height) * (drag.v.y1 - drag.v.y0); st.v = { x0: drag.v.x0 - dx, x1: drag.v.x1 - dx, y0: drag.v.y0 + dy, y1: drag.v.y1 + dy }; drawGraph(host, g, st); };
      sv.onpointerup = sv.onpointercancel = () => { drag = null; if (sv.style) sv.style.cursor = 'grab'; };
      sv.onwheel = (e) => { e.preventDefault(); zoom(e.deltaY < 0 ? 0.8 : 1.25, toU(e)); };
      sv.ondblclick = () => { st.v = { ...st.home }; drawGraph(host, g, st); };
      function zoom(k, at) { const c = at || { fx: 0.5, fy: 0.5 }, v2 = st.v, cx = v2.x0 + (v2.x1 - v2.x0) * c.fx, cy = v2.y1 - (v2.y1 - v2.y0) * c.fy; st.v = { x0: cx - (cx - v2.x0) * k, x1: cx + (v2.x1 - cx) * k, y0: cy - (cy - v2.y0) * k, y1: cy + (v2.y1 - cy) * k }; drawGraph(host, g, st); }
      host.zoom = zoom;
    }
    CX.blocks.graph = (m, n, p, bk, st) => {
      const g = parseGraph(p.s);
      if (!g.fns.length && !g.pts.length) { bk.appendChild(el('div', 'bt', 'Graph')); bk.appendChild(el('p', 'tx', 'That graph could not be read.')); return bk; }
      bk.appendChild(el('div', 'bt', esc('Graph' + (g.title ? ': ' + g.title : ''))));
      const box = el('div', 'gr'); bk.appendChild(box); drawGraph(box, g, st);
      const lg = el('div', 'gr-l'); g.fns.forEach((f, k) => lg.appendChild(el('span', 'tx', '<i style="background:' + COLS[k % COLS.length] + '"></i>' + esc(f.label)))); bk.appendChild(lg);
      if (g.errs.length) bk.appendChild(el('p', 'tx small', 'Could not read: ' + esc(g.errs.join(', '))));
      const a = el('div', 'act');
      a.append(bkBtn('+', () => box.zoom(0.7)), bkBtn('−', () => box.zoom(1.4)), bkBtn('Reset', () => { st.v = { ...st.home }; drawGraph(box, g, st); }),
        bkBtn('Save picture', () => { const sv = box.firstChild.cloneNode(true); sv.setAttribute('xmlns', 'http://www.w3.org/2000/svg'); sv.setAttribute('style', 'color:#171717;' + FONT); CX.saveFile('graph.svg', new XMLSerializer().serializeToString(sv).replace(/var\(--paper\)/g, '#FBF6EC').replace(/currentColor/g, '#171717'), 'image/svg+xml'); }));
      a.appendChild(el('span', 'tx small', 'Drag to move, scroll to zoom'));
      bk.appendChild(a); return bk;
    };

    // ============================================================ data tables: sort, filter, total, copy, save
    function parseCsv(text) { const rows = []; let row = [], cur = '', q = false; for (let i = 0; i < text.length; i++) { const c = text[i]; if (q) { if (c === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += c; } else if (c === '"') q = true; else if (c === ',') { row.push(cur); cur = ''; } else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cur); cur = ''; if (row.some((x) => x !== '')) rows.push(row); row = []; } else cur += c; } row.push(cur); if (row.some((x) => x !== '')) rows.push(row); return rows; }
    const toCsv = (cols, rows) => [cols, ...rows].map((r) => r.map((c) => { const s = String(c ?? ''); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }).join(',')).join('\n');
    CX.blocks.data = (m, n, p, bk, st) => {
      let title = '', cols = [], rows = []; const j = CX.jsonOf(p.s);
      if (j && Array.isArray(j.columns) && Array.isArray(j.rows)) { title = String(j.title || ''); cols = j.columns.map(String); rows = j.rows.filter(Array.isArray); }
      else { const c = parseCsv(p.s); if (c.length >= 2) { cols = c[0].map(String); rows = c.slice(1); } }
      if (!cols.length || !rows.length) { bk.appendChild(el('div', 'bt', 'Data')); bk.appendChild(el('p', 'tx', 'That table could not be read.')); return bk; }
      bk.appendChild(el('div', 'bt', esc('Data' + (title ? ': ' + title : ''))));
      const isNum = cols.map((_, k) => { const vs = rows.map((r) => r[k]).filter((x) => x !== '' && x != null); return vs.length > 0 && vs.every((x) => Number.isFinite(Number(String(x).replace(/,/g, '')))); });
      const n2 = (x) => Number(String(x).replace(/,/g, ''));
      const f = el('input', 'dt-f'); f.type = 'search'; f.placeholder = 'Filter ' + rows.length + ' rows'; f.setAttribute('aria-label', 'Filter the table'); f.value = st.f || ''; bk.appendChild(f);
      const wrap = el('div', 'dt'); bk.appendChild(wrap);
      const draw = () => {
        let rs = rows.slice(); const q = (st.f || '').toLowerCase(); if (q) rs = rs.filter((r) => r.some((c) => String(c).toLowerCase().includes(q)));
        if (st.s != null) { const k = st.s, d = st.d || 1; rs.sort((a, b) => (isNum[k] ? n2(a[k]) - n2(b[k]) : String(a[k]).localeCompare(String(b[k]))) * d); }
        let h = '<table><thead><tr>' + cols.map((c, k) => '<th scope="col"><button type="button" data-k="' + k + '" class="' + (isNum[k] ? 'num' : '') + '">' + esc(c) + (st.s === k ? (st.d === -1 ? ' ▼' : ' ▲') : '') + '</button></th>').join('') + '</tr></thead><tbody>';
        for (const r of rs.slice(0, 200)) h += '<tr>' + cols.map((_, k) => '<td class="' + (isNum[k] ? 'num' : '') + '">' + esc(r[k] ?? '') + '</td>').join('') + '</tr>';
        if (st.t) h += '<tr class="tot">' + cols.map((_, k) => '<td class="' + (isNum[k] ? 'num' : '') + '">' + (k === 0 && !isNum[0] ? 'Total' : isNum[k] ? fmt(rs.reduce((s2, r) => s2 + (n2(r[k]) || 0), 0)) : '') + '</td>').join('') + '</tr>';
        wrap.innerHTML = h + '</tbody></table>' + (rs.length > 200 ? '<p class="tx small">Showing 200 of ' + rs.length + '. Filter, or save the file for all of them.</p>' : '');
        wrap.querySelectorAll('th button').forEach((b) => { b.onclick = () => { const k = Number(b.dataset.k); if (st.s === k) st.d = -(st.d || 1); else { st.s = k; st.d = 1; } draw(); }; });
        draw.rs = rs;
      };
      f.oninput = () => { st.f = f.value; draw(); };
      draw();
      const a = el('div', 'act');
      a.append(bkBtn(st.t ? 'Hide total' : 'Total', () => { st.t = !st.t; draw(); }), bkBtn('Copy CSV', async (e) => { try { await navigator.clipboard.writeText(toCsv(cols, draw.rs)); e.target.textContent = 'Copied'; } catch { e.target.textContent = 'Could not copy'; } }), bkBtn('Save CSV', () => CX.saveFile((title || 'table').replace(/[^\w-]+/g, '-') + '.csv', toCsv(cols, draw.rs), 'text/csv')));
      bk.appendChild(a); return bk;
    };

    // ============================================================ slides: flip through, present, save as PowerPoint
    const PAIRS = { cream: { bg: 'F2E4CE', fg: '171717', ac: '337957' }, ink: { bg: '171717', fg: 'F2E4CE', ac: 'B49A57' }, green: { bg: '1A4934', fg: 'F2E4CE', ac: 'E8C98A' }, gold: { bg: 'B49A57', fg: '171717', ac: 'F2E4CE' } };
    const ROT = ['cream', 'ink', 'green', 'gold'];
    const pairFor = (deck, i) => { const t = deck.theme && deck.theme !== 'blocks' && PAIRS[deck.theme] ? deck.theme : null; return PAIRS[t || (i === 0 ? 'ink' : ROT[i % 4])]; };
    const MAPL = [[/\\frac\{([^}]*)\}\{([^}]*)\}/g, '($1)/($2)'], [/\\sqrt\{([^}]*)\}/g, '√($1)'], [/\\cdot/g, '·'], [/\\times/g, '×'], [/\\pi/g, 'π'], [/\\theta/g, 'θ'], [/\\alpha/g, 'α'], [/\\beta/g, 'β'], [/\\pm/g, '±'], [/\\leq?/g, '≤'], [/\\geq?/g, '≥'], [/\\neq/g, '≠'], [/\\approx/g, '≈'], [/\\infty/g, '∞'], [/\\[a-zA-Z]+/g, ''], [/[{}]/g, ''], [/\^2/g, '²'], [/\^3/g, '³']];
    const plain = (t) => { let s = String(t == null ? '' : t); s = s.replace(/\$\$?([^$]+)\$\$?/g, (_, m2) => MAPL.reduce((a, [r, v]) => a.replace(r, v), m2)); return s.replace(/\*\*|__|`/g, '').replace(/\[([^\]]+)\]\([^)]+\)/g, '$1').trim(); };
    const layoutOf = (s, i) => s.layout || (i === 0 && !(s.bullets || []).length ? 'title' : (s.bullets || []).length ? 'bullets' : s.left || s.right ? 'two' : s.text ? 'quote' : 'bullets');
    const slideHtml = (deck, i) => {
      const s = deck.slides[i], lay = layoutOf(s, i), bl = (s.bullets || []).slice(0, 9), chars = bl.join('').length, fs = bl.length <= 3 && chars < 140 ? 46 : bl.length <= 5 && chars < 260 ? 40 : bl.length <= 7 ? 34 : 28;
      const li = (a, z) => (a || []).slice(0, z).map((b) => '<li>' + mdInline(String(b)) + '</li>').join('');
      let h = '<i class="sl-bar"></i>';
      if (lay === 'title') h += '<h2 class="sl-h d">' + esc(s.title || '') + '</h2><i class="sl-rule"></i>' + (s.subtitle ? '<p class="sl-sub">' + mdInline(String(s.subtitle)) + '</p>' : '');
      else if (lay === 'big') h += '<h2 class="sl-big d">' + esc(s.title || '') + '</h2>' + (s.subtitle ? '<p class="sl-sub">' + mdInline(String(s.subtitle)) + '</p>' : '');
      else if (lay === 'quote') h += '<i class="sl-q d">“</i><p class="sl-quote">' + mdInline(String(s.text || s.title || '')) + '</p>' + (s.by || (s.text && s.title) ? '<p class="sl-by d">' + esc(s.by || s.title) + '</p>' : '');
      else if (lay === 'two') h += '<h2 class="sl-t d">' + esc(s.title || '') + '</h2><div class="sl-cols">' + [s.left, s.right].map((side) => side ? '<div class="sl-col">' + (side.heading ? '<h3 class="sl-ch d">' + esc(side.heading) + '</h3>' : '') + '<ul style="font-size:34px">' + li(side.bullets, 6) + '</ul></div>' : '').join('') + '</div>';
      else h += '<h2 class="sl-t d">' + esc(s.title || '') + '</h2>' + (bl.length ? '<ul class="sl-ul" style="font-size:' + fs + 'px">' + li(bl, 9) + '</ul>' : s.text ? '<p class="sl-quote plain">' + mdInline(String(s.text)) + '</p>' : '');
      return h + '<p class="sl-foot">' + esc(plain(deck.title || '')) + '<span>' + (i + 1) + ' / ' + deck.slides.length + '</span></p>';
    };
    const paintSlide = (stage, deck, i) => { const c = pairFor(deck, i), sl = stage.querySelector('.sl'); sl.className = 'sl sl-lay-' + layoutOf(deck.slides[i], i); sl.style.cssText = '--sb:#' + c.bg + ';--sf:#' + c.fg + ';--sa:#' + c.ac; sl.innerHTML = slideHtml(deck, i); fit(stage); };
    const fit = (stage) => { const w = stage.clientWidth || 300, k = w / 1280; stage.style.height = Math.round(720 * k) + 'px'; stage.firstChild.style.transform = 'scale(' + k + ')'; };
    async function deckToPptx(deck) {
      if (!window.PptxGenJS) await new Promise((ok, no) => { const sc = document.createElement('script'); sc.src = 'pptxgen.bundle.js'; sc.onload = ok; sc.onerror = no; document.head.appendChild(sc); });
      const pres = new window.PptxGenJS(); pres.layout = 'LAYOUT_16x9'; pres.title = plain(deck.title) || 'Slides'; pres.author = 'Coe';
      const W = 10, H = 5.625, HF = 'Arial Narrow', BF = 'Calibri';
      deck.slides.forEach((s, i) => {
        const c = pairFor(deck, i), sl = pres.addSlide(); sl.background = { color: c.bg }; const lay = layoutOf(s, i), acc = c.ac === 'F2E4CE' ? c.fg : c.ac;
        sl.addShape('rect', { x: 0, y: 0, w: 0.22, h: H, fill: { color: c.ac }, line: { color: c.ac, width: 0 } });
        if (lay === 'title') { sl.addText(plain(s.title).toUpperCase(), { x: 0.7, y: 1.5, w: W - 1.4, h: 1.9, fontFace: HF, bold: true, fontSize: 54, color: c.fg, valign: 'bottom', fit: 'shrink' }); sl.addShape('rect', { x: 0.7, y: 3.55, w: 2.2, h: 0.12, fill: { color: c.ac }, line: { color: c.ac, width: 0 } }); if (s.subtitle) sl.addText(plain(s.subtitle), { x: 0.7, y: 3.8, w: W - 1.4, h: 1, fontFace: BF, fontSize: 24, color: c.fg, valign: 'top', fit: 'shrink' }); }
        else if (lay === 'big') { sl.addText(plain(s.title), { x: 0.6, y: 0.9, w: W - 1.2, h: 2.6, fontFace: HF, bold: true, fontSize: 96, color: acc, align: 'center', valign: 'middle', fit: 'shrink' }); if (s.subtitle) sl.addText(plain(s.subtitle), { x: 0.9, y: 3.6, w: W - 1.8, h: 1.2, fontFace: BF, fontSize: 26, color: c.fg, align: 'center', valign: 'top', fit: 'shrink' }); }
        else if (lay === 'quote') { sl.addText('“' + plain(s.text || s.title) + '”', { x: 0.9, y: 0.9, w: W - 1.8, h: 3.2, fontFace: BF, italic: true, fontSize: 32, color: c.fg, valign: 'middle', fit: 'shrink' }); if (s.by || s.title) sl.addText(plain(s.by || s.title), { x: 0.9, y: 4.2, w: W - 1.8, h: 0.6, fontFace: HF, bold: true, fontSize: 20, color: acc }); }
        else if (lay === 'two') { sl.addText(plain(s.title).toUpperCase(), { x: 0.6, y: 0.4, w: W - 1.2, h: 0.9, fontFace: HF, bold: true, fontSize: 32, color: c.fg, valign: 'middle', fit: 'shrink' }); [s.left, s.right].forEach((side, k) => { if (!side) return; const x = 0.6 + k * ((W - 1.2) / 2 + 0.15), w = (W - 1.2) / 2 - 0.15; if (side.heading) sl.addText(plain(side.heading).toUpperCase(), { x, y: 1.5, w, h: 0.5, fontFace: HF, bold: true, fontSize: 20, color: acc }); sl.addText((side.bullets || []).map((b) => ({ text: plain(b), options: { bullet: { code: '25A0' }, breakLine: true } })), { x, y: 2.05, w, h: 3.0, fontFace: BF, fontSize: 18, color: c.fg, valign: 'top', paraSpaceAfter: 8, fit: 'shrink' }); }); }
        else { sl.addText(plain(s.title).toUpperCase(), { x: 0.6, y: 0.4, w: W - 1.2, h: 0.9, fontFace: HF, bold: true, fontSize: 32, color: c.fg, valign: 'middle', fit: 'shrink' }); const items = (s.bullets || []).map((b) => ({ text: plain(b), options: { bullet: { code: '25A0' }, breakLine: true } })); if (items.length) sl.addText(items, { x: 0.6, y: 1.5, w: W - 1.2, h: 3.5, fontFace: BF, fontSize: items.length > 5 ? 20 : 24, color: c.fg, valign: 'top', paraSpaceAfter: 10, fit: 'shrink' }); else if (s.text) sl.addText(plain(s.text), { x: 0.6, y: 1.5, w: W - 1.2, h: 3.5, fontFace: BF, fontSize: 24, color: c.fg, valign: 'top', fit: 'shrink' }); }
        sl.addText(plain(deck.title) + '   ' + (i + 1) + ' / ' + deck.slides.length, { x: 0.6, y: H - 0.45, w: W - 1.2, h: 0.3, fontFace: BF, fontSize: 10, color: c.fg, transparency: 45 });
        if (s.notes) sl.addNotes(plain(s.notes));
      });
      return pres.write({ outputType: 'blob' });
    }
    CX.blocks.slides = (m, n, p, bk, st) => {
      const j = CX.jsonOf(p.s), deck = j && Array.isArray(j.slides) ? { title: j.title || 'Slides', theme: j.theme, slides: j.slides.filter((x) => x && typeof x === 'object').slice(0, 30) } : null;
      if (!deck || !deck.slides.length) { bk.appendChild(el('div', 'bt', 'Slides')); bk.appendChild(el('p', 'tx', 'Those slides could not be read.')); return bk; }
      bk.appendChild(el('div', 'bt', esc('Slides: ' + plain(deck.title))));
      st.i = clamp(st.i || 0, 0, deck.slides.length - 1);
      const stage = el('div', 'sl-stage', '<div class="sl"></div>'); bk.appendChild(stage); paintSlide(stage, deck, st.i);
      setTimeout(() => fit(stage), 0);
      if ('ResizeObserver' in window) new ResizeObserver(() => fit(stage)).observe(stage);
      const note = el('p', 'tx sl-notes', ''); note.hidden = true; bk.appendChild(note);
      const go = (d) => { st.i = clamp(st.i + d, 0, deck.slides.length - 1); paintSlide(stage, deck, st.i); note.textContent = st.notes && deck.slides[st.i].notes ? 'Notes: ' + plain(deck.slides[st.i].notes) : ''; note.hidden = !note.textContent; };
      const a = el('div', 'act');
      a.append(bkBtn('Back', () => go(-1)), bkBtn('Next', () => go(1)), bkBtn('Present', () => { const t = stage.requestFullscreen ? stage.requestFullscreen() : null; if (t && t.then) t.then(() => { const key = (e) => { if (e.key === 'ArrowRight' || e.key === ' ') go(1); else if (e.key === 'ArrowLeft') go(-1); }; const off = () => { if (!document.fullscreenElement) { document.removeEventListener('keydown', key); document.removeEventListener('fullscreenchange', off); fit(stage); } }; document.addEventListener('keydown', key); document.addEventListener('fullscreenchange', off); setTimeout(() => fit(stage), 100); }).catch(() => say('This browser would not go full screen here.')); }),
        bkBtn('Notes', () => { st.notes = !st.notes; go(0); }),
        bkBtn('Save as PowerPoint', async (e) => { const b = e.target; b.textContent = 'Making the file…'; try { const blob = await deckToPptx(deck); CX.saveFile((plain(deck.title) || 'slides').replace(/[^\w-]+/g, '-') + '.pptx', blob, 'application/vnd.openxmlformats-officedocument.presentationml.presentation'); b.textContent = 'Saved'; } catch { b.textContent = 'Could not make the file'; } }));
      bk.appendChild(a); return bk;
    };

    // ============================================================ every kind of chart
    CX.chart = (spec) => {
      const type = String(spec.type || 'bar').toLowerCase(), cs = (Array.isArray(spec.colors) ? spec.colors.map(String).filter((x) => /^#[0-9a-f]{3,8}$/i.test(x.trim())).slice(0, 12) : []), C = cs.length ? cs : COLS;
      let series = (spec.series || (spec.data ? [{ name: '', data: spec.data }] : [])).filter((x) => x && Array.isArray(x.data) && x.data.length).slice(0, 8);
      if (!series.length) return '';
      const W = 640, ctext = 'fill="currentColor"';
      const wrap = (inner, H) => '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" role="img" aria-label="Chart: ' + esc(spec.title || '') + '" style="color:var(--ink);' + FONT + ';max-width:100%;display:block">' + inner + '</svg>';
      const labels = (spec.labels || series[0].data.map((_, i) => String(i + 1))).map(String);
      if (type === 'pie' || type === 'donut' || type === 'doughnut') {
        const data = series[0].data.map((v) => Math.max(0, num(Array.isArray(v) ? v[1] : v)) || 0), tot = data.reduce((a, b) => a + b, 0) || 1, cx = 170, cy = 170, r = 150, ri = type === 'pie' ? 0 : 84; let a0 = -Math.PI / 2, s = '';
        data.forEach((v, k) => { const a1 = a0 + (v / tot) * Math.PI * 2, big = a1 - a0 > Math.PI ? 1 : 0; const P = (rr, a) => (cx + rr * Math.cos(a)).toFixed(1) + ' ' + (cy + rr * Math.sin(a)).toFixed(1); if (v / tot > 0.9999) s += '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="' + C[k % C.length] + '" stroke="var(--ink)" stroke-width="3"/>'; else if (v > 0) s += '<path d="M' + P(ri || 0, a0) + (ri ? 'L' : 'L') + P(r, a0) + 'A' + r + ' ' + r + ' 0 ' + big + ' 1 ' + P(r, a1) + (ri ? 'L' + P(ri, a1) + 'A' + ri + ' ' + ri + ' 0 ' + big + ' 0 ' + P(ri, a0) : 'L' + cx + ' ' + cy) + 'Z" fill="' + C[k % C.length] + '" stroke="var(--ink)" stroke-width="3"/>'; a0 = a1; });
        data.forEach((v, k) => { s += '<rect x="360" y="' + (30 + k * 30) + '" width="18" height="18" fill="' + C[k % C.length] + '" stroke="var(--ink)" stroke-width="2"/><text x="388" y="' + (45 + k * 30) + '" font-size="19" ' + ctext + '>' + esc(String(labels[k] || '').slice(0, 18)) + ' · ' + Math.round((v / tot) * 100) + '%</text>'; });
        return wrap(s, Math.max(340, 40 + data.length * 30));
      }
      const H = 380, L = 62, R = 14, T = 16, B = 78, pw = W - L - R, ph = H - T - B;
      const scatter = type === 'scatter'; let xs = [], ys = [];
      if (scatter) series.forEach((sr) => sr.data.forEach((p) => { if (Array.isArray(p)) { xs.push(num(p[0])); ys.push(num(p[1])); } })); else series.forEach((sr) => sr.data.forEach((v) => ys.push(num(Array.isArray(v) ? v[1] : v) || 0)));
      xs = xs.filter(Number.isFinite); ys = ys.filter(Number.isFinite); if (!ys.length) return '';
      let ymax = Math.max(scatter ? ys[0] : 0, ...ys), ymin = Math.min(scatter ? ys[0] : 0, ...ys); const step = nice((ymax - ymin) || 1, 5); ymax = Math.ceil(ymax / step) * step; ymin = Math.floor(ymin / step) * step; const yr = (ymax - ymin) || 1;
      const Y = (v) => T + ph - ((v - ymin) / yr) * ph; let s = '';
      for (let v = ymin; v <= ymax + step / 2; v += step) s += '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + Y(v).toFixed(1) + '" y2="' + Y(v).toFixed(1) + '" stroke="currentColor" stroke-opacity=".15"/><text x="' + (L - 8) + '" y="' + (Y(v) + 6).toFixed(1) + '" text-anchor="end" font-size="17" ' + ctext + '>' + fmt(v) + '</text>';
      let X;
      if (scatter) { const x0 = Math.min(...xs), x1 = Math.max(...xs), sx = nice((x1 - x0) || 1, 6), a = Math.floor(x0 / sx) * sx, b = Math.ceil(x1 / sx) * sx; X = (v) => L + ((v - a) / ((b - a) || 1)) * pw; for (let v = a; v <= b + sx / 2; v += sx) s += '<text x="' + X(v).toFixed(1) + '" y="' + (H - B + 24) + '" text-anchor="middle" font-size="17" ' + ctext + '>' + fmt(v) + '</text>'; series.forEach((sr, k) => sr.data.forEach((p) => { if (Array.isArray(p)) s += '<circle cx="' + X(num(p[0])).toFixed(1) + '" cy="' + Y(num(p[1])).toFixed(1) + '" r="6" fill="' + C[k % C.length] + '" stroke="var(--ink)" stroke-width="2"/>'; })); }
      else {
        const nn = labels.length, st2 = pw / nn; labels.forEach((l, i) => { s += '<text x="' + (L + st2 * (i + 0.5)).toFixed(1) + '" y="' + (H - B + 24) + '" text-anchor="middle" font-size="17" ' + ctext + '>' + esc(l.slice(0, 10)) + '</text>'; });
        series.forEach((sr, k) => {
          const c = C[k % C.length], pts = sr.data.map((v, i) => [L + st2 * (i + 0.5), Y(num(Array.isArray(v) ? v[1] : v) || 0)]);
          if (type === 'line' || type === 'area') { if (type === 'area') s += '<polygon fill="' + c + '" fill-opacity=".28" points="' + pts.map((p) => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ') + ' ' + pts[pts.length - 1][0].toFixed(1) + ',' + Y(Math.max(ymin, Math.min(ymax, 0))).toFixed(1) + ' ' + pts[0][0].toFixed(1) + ',' + Y(Math.max(ymin, Math.min(ymax, 0))).toFixed(1) + '"/>'; s += '<polyline fill="none" stroke="' + c + '" stroke-width="3.2" points="' + pts.map((p) => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ') + '"/>' + pts.map((p) => '<circle cx="' + p[0].toFixed(1) + '" cy="' + p[1].toFixed(1) + '" r="4.5" fill="' + c + '"/>').join(''); }
          else { const bw = Math.min(46, (st2 * 0.8) / series.length); sr.data.forEach((v, i) => { const x = L + st2 * (i + 0.5) - (bw * series.length) / 2 + bw * k, y0 = Y(Math.max(ymin, Math.min(ymax, 0))), y1 = Y(num(Array.isArray(v) ? v[1] : v) || 0); s += '<rect x="' + x.toFixed(1) + '" y="' + Math.min(y0, y1).toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + Math.max(1, Math.abs(y0 - y1)).toFixed(1) + '" fill="' + c + '" stroke="var(--ink)" stroke-width="2"/>'; }); }
        });
      }
      s += '<line x1="' + L + '" x2="' + L + '" y1="' + T + '" y2="' + (T + ph) + '" stroke="currentColor" stroke-width="2.5"/><line x1="' + L + '" x2="' + (W - R) + '" y1="' + Y(Math.max(ymin, Math.min(ymax, 0))).toFixed(1) + '" y2="' + Y(Math.max(ymin, Math.min(ymax, 0))).toFixed(1) + '" stroke="currentColor" stroke-width="2.5"/>';
      if (spec.xLabel) s += '<text x="' + (L + pw / 2) + '" y="' + (H - B + 46) + '" text-anchor="middle" font-size="17" ' + ctext + ' opacity=".8">' + esc(String(spec.xLabel).slice(0, 40)) + '</text>';
      if (spec.yLabel) s += '<text transform="translate(16 ' + (T + ph / 2) + ') rotate(-90)" text-anchor="middle" font-size="17" ' + ctext + ' opacity=".8">' + esc(String(spec.yLabel).slice(0, 40)) + '</text>';
      if (series.length > 1 || series[0].name) series.forEach((sr, k) => { s += '<rect x="' + (L + k * 150) + '" y="' + (H - 22) + '" width="16" height="16" fill="' + C[k % C.length] + '" stroke="var(--ink)" stroke-width="2"/><text x="' + (L + k * 150 + 22) + '" y="' + (H - 9) + '" font-size="16" ' + ctext + '>' + esc(String(sr.name || 'Series ' + (k + 1)).slice(0, 14)) + '</text>'; });
      return wrap(s, H);
    };

    // ============================================================ "What next" buttons, a page that runs (Chrome family), diagrams
    CX.blocks.followups = (m, n, p, bk) => {
      let list = []; try { list = JSON.parse(String(p.s).trim()); } catch { /* not JSON */ }
      list = (Array.isArray(list) ? list : []).map((x) => String(x).trim().slice(0, 70)).filter(Boolean).slice(0, 3);
      const last = [...S.msgs].reverse().find((x) => x.role === 'assistant' && x.text);
      if (!list.length || m !== last || S.busy) { bk.className = 'bk gone'; return bk; }
      bk.className = 'fups'; for (const t of list) { const b = el('button', 'fup tx', esc(t)); b.type = 'button'; b.onclick = () => CX.send(t); bk.appendChild(b); } return bk;
    };
    const canRun = !!(chrome.runtime.getManifest && chrome.runtime.getManifest().sandbox);
    const openInCoe = (text) => chrome.runtime.sendMessage({ type: 'handoff', text });
    const page = (m, n, p, bk, st) => {
      const html = String(p.s); bk.appendChild(el('div', 'bt', 'Page'));
      const remote = /<(script|link|img|iframe|video|audio|source)\b[^>]*\b(?:src|href)\s*=\s*["']?(?:https?:)?\/\//i.test(html);
      const a = el('div', 'act');
      if (canRun && !remote) {
        if (!st.code) { const f = el('iframe', 'pv'); f.setAttribute('title', 'Live preview'); f.src = 'sandbox.html'; f.onload = () => f.contentWindow.postMessage({ html }, '*'); bk.appendChild(f); }
        a.appendChild(bkBtn(st.code ? 'Show the page' : 'Show the code', () => { st.code = !st.code; renderMsgs(); }));
      } else bk.appendChild(el('p', 'tx small', remote ? 'This page loads something from the web, so it runs in Coe instead of here.' : 'Pages run in Coe, not in this browser’s sidebar.'));
      if (st.code || !canRun || remote) bk.appendChild(el('pre', 'pcode', '<code>' + esc(html.slice(0, 20000)) + '</code>'));
      a.append(bkBtn('Save as .html', () => CX.saveFile('page.html', html, 'text/html')), bkBtn('Copy code', async (e) => { try { await navigator.clipboard.writeText(html); e.target.textContent = 'Copied'; } catch { e.target.textContent = 'Could not copy'; } }), bkBtn('Open in Coe', () => openInCoe('Build this page, and keep it as it is:\n\n```html\n' + html.slice(0, 18000) + '\n```')));
      bk.appendChild(a); return bk;
    };
    CX.blocks.html = CX.blocks.htm = page;
    CX.blocks.mermaid = (m, n, p, bk) => {
      bk.appendChild(el('div', 'bt', 'Diagram')); bk.appendChild(el('p', 'tx small', 'Diagrams are drawn in Coe. Open it there to see the picture.')); bk.appendChild(el('pre', 'pcode', '<code>' + esc(String(p.s).slice(0, 6000)) + '</code>'));
      const a = el('div', 'act'); a.append(bkBtn('Open in Coe', () => openInCoe('Draw this diagram:\n\n```mermaid\n' + String(p.s).slice(0, 6000) + '\n```')), bkBtn('Copy code', async (e) => { try { await navigator.clipboard.writeText(p.s); e.target.textContent = 'Copied'; } catch { /* no */ } })); bk.appendChild(a); return bk;
    };

    // ============================================================ the select-words bar (Explain / Simpler / Example / Quiz me / Ask)
    const bar = el('div', 'selbar'); bar.hidden = true; bar.setAttribute('role', 'toolbar'); bar.setAttribute('aria-label', 'Ask about the selected words'); document.body.appendChild(bar);
    let selT = 0, pick = '';
    const within = (nd) => (nd instanceof Element ? nd : nd && nd.parentElement) && (nd instanceof Element ? nd : nd.parentElement).closest('#msgs .m.bot');
    const hideBar = () => { bar.hidden = true; pick = ''; };
    document.addEventListener('selectionchange', () => {
      clearTimeout(selT);
      selT = setTimeout(() => {
        const sel = window.getSelection(); if (!sel || sel.isCollapsed || !sel.rangeCount) return hideBar();
        const a = within(sel.anchorNode); if (!a || a !== within(sel.focusNode)) return hideBar();
        const text = sel.toString().replace(/\s+/g, ' ').trim(); if (text.length < 3 || text.length > 1200) return hideBar();
        const r = sel.getRangeAt(0).getBoundingClientRect(); if (!r.width && !r.height) return hideBar();
        pick = text; bar.hidden = false; const w = bar.offsetWidth || 300; bar.style.left = clamp(r.left + r.width / 2 - w / 2, 4, document.documentElement.clientWidth - w - 4) + 'px'; bar.style.top = Math.max(4, r.top - bar.offsetHeight - 8) + 'px';
      }, 140);
    });
    addEventListener('scroll', hideBar, true);
    for (const [ic, label, prefix] of [['graduate', 'Explain', 'Explain this part of your answer more clearly:'], ['wand', 'Simpler', 'Say this part again in simpler words:'], ['sigma', 'Example', 'Give me a worked example of this:'], ['cards', 'Quiz me', 'Quiz me with one question about this part, then mark my answer:'], ['chat', 'Ask…', '']]) {
      const b = el('button', 'selbar-b', IC(ic, 15) + '<span>' + esc(label) + '</span>'); b.type = 'button'; b.onpointerdown = (e) => e.preventDefault();
      b.onclick = () => { const t = pick; try { window.getSelection().removeAllRanges(); } catch { /* none */ } hideBar(); if (!t) return; if (prefix) CX.send(prefix + ' "' + t + '"'); else { const ta = $('ta'); ta.value = '> ' + t + '\n\n'; ta.dispatchEvent(new Event('input', { bubbles: true })); ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length); } };
      bar.appendChild(b);
    }

    // ============================================================ Study: cards that come back just before you forget them
    const A = () => CX.acct, st0 = () => A().study;
    const dueCards = (deckId) => { const t = A().today(); return st0().cards.filter((c) => c.due <= t && (!deckId || c.deck === deckId)); };
    const deckStats = (id) => { const cs = st0().cards.filter((c) => c.deck === id), t = A().today(); return { total: cs.length, due: cs.filter((c) => c.due <= t).length, fresh: cs.filter((c) => c.reps === 0).length, known: cs.filter((c) => c.interval >= 21).length }; };
    const streak = () => { const s = st0(), t = A().today(); let k = 0, d = t; const did = (s.log[A().dayKey(t)] || 0) > 0; if (!did) d = t - 1; while ((s.log[A().dayKey(d)] || 0) > 0) { k++; d--; } return { days: k, today: did }; };
    const level = (xp) => { const lv = Math.floor(Math.sqrt(xp / 40)) + 1, base = 40 * (lv - 1) ** 2, nextXp = 40 * lv ** 2; return { lv, into: xp - base, span: nextXp - base }; };
    const reviewedToday = () => st0().log[A().dayKey(A().today())] || 0;
    function grade(id, g) {
      const s = st0(), c = s.cards.find((x) => x.id === id); if (!c) return; const t = A().today();
      if (g === 0) { c.lapses++; c.reps = 0; c.interval = 0; c.ease = Math.max(1.3, c.ease - 0.2); c.due = t; }
      else { c.ease = Math.min(3, Math.max(1.3, c.ease + (g === 1 ? -0.15 : g === 3 ? 0.15 : 0))); c.interval = g === 1 ? Math.max(1, Math.round(c.interval * 1.2)) : c.reps === 0 ? (g === 3 ? 3 : 1) : c.reps === 1 ? (g === 3 ? 6 : 3) : Math.round(c.interval * c.ease * (g === 3 ? 1.3 : 1)); c.reps++; c.due = t + Math.max(1, c.interval); }
      c.upd = Date.now(); const k = A().dayKey(t); s.log[k] = (s.log[k] || 0) + 1; s.xp += g === 0 ? 2 : g === 1 ? 5 : g === 2 ? 10 : 12; A().save();
    }
    const nextLabel = (c, g) => { if (g === 0) return 'soon'; const days = g === 1 ? Math.max(1, Math.round(c.interval * 1.2)) : c.reps === 0 ? (g === 3 ? 3 : 1) : c.reps === 1 ? (g === 3 ? 6 : 3) : Math.round(c.interval * Math.min(3, c.ease) * (g === 3 ? 1.3 : 1)); return days <= 1 ? 'tomorrow' : days < 30 ? days + ' days' : Math.round(days / 30) + ' months'; };
    function addCards(deckName, cards) {
      const s = st0(), name = String(deckName || '').trim().slice(0, 60) || 'My cards'; let deck = s.decks.find((d) => A().norm(d.name) === A().norm(name));
      if (!deck) { deck = { id: A().suid(), name, created: Date.now() }; s.decks.push(deck); }
      const have = new Set(s.cards.filter((c) => c.deck === deck.id).map((c) => A().norm(c.front))); let added = 0; const t = A().today();
      for (const c of cards) { const front = String((c && c.front) || '').trim(), back = String((c && c.back) || '').trim(); if (!front || !back || have.has(A().norm(front))) continue; s.cards.push({ id: A().suid(), deck: deck.id, front: front.slice(0, 1200), back: back.slice(0, 2400), ease: 2.5, interval: 0, due: t, reps: 0, lapses: 0, upd: Date.now() }); have.add(A().norm(front)); added++; }
      A().save(); return { deck, added };
    }
    CX.saveBtn = (title, cards) => bkBtn('Save to Study', (e) => { const r = addCards(title || 'My cards', cards); CX.sfx && CX.sfx.on(); e.target.textContent = r.added ? 'Saved ' + r.added + ' to Study' : 'Already in Study'; });
    CX.onStudyChange = () => { if (!$('dlg').hidden && $('dt').textContent === 'Study') openStudy(); };
    function openStudy(reviewDeck) {
      const s = st0(), goal = Number((S.me || {}).goal) || 10, root = el('div', 'stu');
      if (reviewDeck !== undefined) return review(reviewDeck);
      const sk = streak(), lv = level(s.xp || 0), done = reviewedToday(), allDue = dueCards().length;
      root.appendChild(el('div', 'stu-top', '<div><b class="d">' + sk.days + '</b><span class="tx">day streak</span></div><div><b class="d">' + lv.lv + '</b><span class="tx">level</span></div><div><b class="d">' + done + '/' + goal + '</b><span class="tx">cards today</span></div>'));
      root.appendChild(el('div', 'ubar', '<i style="width:' + clamp(Math.round((lv.into / lv.span) * 100), 0, 100) + '%"></i>'));
      const a = el('div', 'acts'), go = el('button', 'btn gold', allDue ? 'Review ' + allDue + ' due' : 'Nothing due'); go.type = 'button'; go.disabled = !allDue; go.onclick = () => review(null); a.appendChild(go);
      const mk = el('button', 'btn sm', 'Make flash cards'); mk.type = 'button'; mk.onclick = () => { closeDlg(); const ta = $('ta'); CX.showChat && CX.showChat(); ta.value = 'Make flash cards (a flashcards block, about 12 cards) on: '; ta.dispatchEvent(new Event('input', { bubbles: true })); ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length); }; a.appendChild(mk); root.appendChild(a);
      if (!s.decks.length) root.appendChild(el('p', 'tx', 'No decks yet. Ask Coe for flash cards, then press Save to Study under them.'));
      for (const d of s.decks) {
        const st = deckStats(d.id), row = el('div', 'stu-d', '<div><b class="d">' + esc(d.name) + '</b><span class="tx">' + st.total + ' cards · ' + st.due + ' due · ' + st.fresh + ' new · ' + st.known + ' known</span></div>');
        const r = el('button', 'btn sm', 'Review'); r.type = 'button'; r.disabled = !st.due; r.onclick = () => review(d.id);
        const rn = el('button', 'ib sm', IC('edit', 16)); rn.type = 'button'; rn.title = 'Rename ' + d.name; rn.onclick = () => { const nm = prompt ? null : null; void nm; row.replaceChildren(); const f = el('form', 'inl'), i = el('input'); i.value = d.name; i.maxLength = 60; const sv = el('button', 'btn sm', 'Save'); sv.type = 'submit'; f.append(i, sv); row.appendChild(f); i.focus(); f.onsubmit = (e) => { e.preventDefault(); if (i.value.trim()) { d.name = i.value.trim().slice(0, 60); A().save(); } openStudy(); }; };
        const dl = el('button', 'ib sm', IC('trash', 16)); dl.type = 'button'; dl.title = 'Delete ' + d.name; dl.onclick = () => { row.replaceChildren(el('span', 'sure', '<b class="d">Delete ' + esc(d.name) + '?</b>')); const y = el('button', 'btn sm danger', 'Yes'), n2 = el('button', 'btn sm', 'No'); y.type = n2.type = 'button'; y.onclick = () => { s.decks = s.decks.filter((x) => x.id !== d.id); s.cards = s.cards.filter((c) => c.deck !== d.id); A().save(); openStudy(); }; n2.onclick = () => openStudy(); row.append(y, n2); };
        row.append(r, rn, dl); root.appendChild(row);
      }
      const days = []; const t = A().today(); for (let k = 13; k >= 0; k--) days.push(s.log[A().dayKey(t - k)] || 0); const mx = Math.max(1, ...days);
      root.appendChild(el('div', 'stu-week', days.map((v) => '<i style="height:' + Math.max(3, Math.round((v / mx) * 100)) + '%" title="' + v + ' cards"></i>').join('')));
      root.appendChild(el('p', 'tx small', 'Cards come back just before you would forget them. Press Space to show the answer, then 1 Again, 2 Hard, 3 Good, 4 Easy.'));
      openDlg('Study', [root]);
    }
    function review(deckId) {
      const queue = dueCards(deckId || undefined).slice(0, 40); let i = 0, shown = false, right = 0; const root = el('div', 'stu');
      const draw = () => {
        root.replaceChildren();
        if (i >= queue.length) { root.appendChild(el('div', 'stu-end', '<b class="d">Done</b><p class="tx">' + queue.length + ' cards reviewed, ' + right + ' you knew. See you tomorrow.</p>')); const b = el('button', 'btn gold', 'Back to Study'); b.type = 'button'; b.onclick = () => openStudy(); root.appendChild(b); return; }
        const c = queue[i]; root.appendChild(el('small', 'tx', (i + 1) + ' of ' + queue.length));
        const card = el('button', 'fl', '<span><small>' + (shown ? 'Answer' : 'Question') + '</small>' + mdInline(String(shown ? c.back : c.front)) + '</span>'); card.type = 'button'; card.onclick = () => { shown = true; draw(); }; root.appendChild(card);
        if (!shown) { const b = el('button', 'btn gold', 'Show answer (Space)'); b.type = 'button'; b.onclick = () => { shown = true; draw(); }; root.appendChild(b); }
        else { const row = el('div', 'stu-g'); [['Again', 0], ['Hard', 1], ['Good', 2], ['Easy', 3]].forEach(([t, g]) => { const b = el('button', 'btn sm' + (g === 2 ? ' gold' : ''), esc(t) + '<small>' + nextLabel(c, g) + '</small>'); b.type = 'button'; b.onclick = () => rate(g); row.appendChild(b); }); root.appendChild(row); }
      };
      const rate = (g) => { grade(queue[i].id, g); if (g >= 2) right++; CX.sfx && (g >= 2 ? CX.sfx.right() : CX.sfx.wrong()); i++; shown = false; draw(); };
      root.tabIndex = -1; root.onkeydown = (e) => { if (e.key === ' ' && !shown && i < queue.length) { e.preventDefault(); shown = true; draw(); } else if (shown && /^[1-4]$/.test(e.key)) rate(Number(e.key) - 1); };
      draw(); openDlg('Study', [root]); root.focus();
    }
    CX.openStudy = openStudy;
    CX.addCmds(() => [
      { id: 'study', group: 'Study', title: 'Study: your flash cards', run: () => openStudy() },
      { id: 'study-r', group: 'Study', title: 'Study: review what is due', run: () => review(null) },
      ...['usage', 'you', 'chat', 'learn', 'look', 'data', 'about'].map((t) => ({ id: 'tab-' + t, group: 'Account', title: ({ usage: 'Usage', you: 'Memory', chat: 'Settings: Chat', learn: 'Settings: Learn', look: 'Settings: Look', data: 'Settings: Data', about: 'About: what Coe can do' })[t], run: () => CX.showSettingsTab(t) })),
      ...(CX.acct ? (SH.PERSONAS || []).concat(CX.acct.styles).map((p) => ({ id: 'ps-' + p.id, group: 'Coe works as', title: 'Coe works as: ' + p.name, hint: p.blurb, run: () => { CX.setPersona(p.id); } })) : []),
      ...(SH.THEMES || []).map((t) => ({ id: 'th-' + t.id, group: 'Look', title: 'Theme: ' + t.name, run: () => CX.setTheme(t) })),
    ]);
    CX.setPersona = async (id) => { await store.set({ persona: id }); say('Coe now works as ' + ((CX.personaOf(id) || {}).name || id)); };
    CX.setTheme = async (t) => { const o = await store.get('look'); await store.set({ look: { ...(o.look || {}), lead: t.lead, accent: t.accent } }); location.reload(); };
    // Study in the More menu, next to the others
    { const menu = $('menu'), li = el('li'), b = el('button', '', 'Study'); b.type = 'button'; b.id = 'm-study'; b.setAttribute('role', 'menuitem'); b.onclick = () => { CX.closeMenu(); openStudy(); }; li.appendChild(b); menu.insertBefore(li, $('m-find').parentElement); }

    // ============================================================ the home screen: the same greeting and the same blocks to start from
    const hello = Math.random();
    CX.greeting = (name) => {
      const c = name ? ', ' + name : '', h = new Date().getHours();
      const set = h < 5 ? ['Late night study session' + c + '?', 'Still up' + c + '? Let’s make it count.', 'Burning the midnight oil' + c + '?']
        : h < 9 ? ['Early start' + c + '. What are we on?', 'Morning' + c + '. What is first?', 'Up early' + c + '? Good.']
        : h < 12 ? ['Morning' + c + '. What are you working on?', 'Good morning' + c + '. Pick a question.', 'Ready when you are' + c + '.']
        : h < 17 ? ['Afternoon' + c + '. What is the question?', 'Back at it' + c + '? What is next?', 'Hello' + c + '. What are we stuck on?']
        : h < 21 ? ['Evening' + c + '. What is left to do?', 'Study time' + c + '? Let’s go.', 'Good evening' + c + '. What is the question?']
        : ['Late one' + c + '? Let’s get it done.', 'Nearly bedtime' + c + '. One last question?', 'Evening study' + c + '. What is up?'];
      return set[Math.min(set.length - 1, Math.floor(hello * set.length))];
    };
    let allBlocks = false;
    CX.homeMore = (h, off) => {
      const sec = el('div', 'blocks'); sec.appendChild(el('h3', 'd hbs-h', 'Start from a block'));
      const grid = el('div', 'blk-g'), all = SH.STARTERS || [];
      for (const s of all.slice(0, allBlocks ? all.length : 4)) {
        const b = el('button', 'blk', '<i class="hi" aria-hidden="true">' + IC(s.icon, 22) + '</i><b>' + esc(s.title) + '</b><span>' + esc(s.hint || '') + '</span>'); b.type = 'button'; b.disabled = !!off;
        b.onclick = () => { if (s.tool === 'code') return CX.openCode && CX.openCode(); if (/PMC Apps|Pixel Art Maker/.test(s.text || '')) { chrome.runtime.sendMessage({ type: 'handoff', text: s.text }); say('Opening this in Coe: it uses PMC Apps.'); return; } if (s.pic) return $('attach').click(); const ta = $('ta'); ta.value = s.text || ''; ta.dispatchEvent(new Event('input', { bubbles: true })); ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length); };
        grid.appendChild(b);
      }
      sec.appendChild(grid);
      const more = el('button', 'hb-more d', allBlocks ? 'Fewer blocks' : 'All ' + all.length + ' blocks'); more.type = 'button'; more.setAttribute('aria-expanded', String(allBlocks)); more.onclick = () => { allBlocks = !allBlocks; renderMsgs(); }; sec.appendChild(more);
      h.appendChild(sec);
    };
    renderMsgs();
  }

  if (CX.S) start(); else CX.ready.push(start);
})();
