// Small functions that run inside the page you are on. Chrome copies each one into the page when it is used,
// so every one is self-contained. They only run when you press something in the Coe sidebar.

/** Reads the page: its words (all of it, or only what is on screen), what you selected, and the boxes you can type in. Never passwords. */
function coeReadPage(scope) {
  const out = { url: location.href, host: location.hostname, title: document.title || location.hostname, selection: '', text: '', fields: [], cut: false };
  try { out.selection = String(getSelection() || '').slice(0, 4000); } catch (e) { /* none */ }
  const MAX = 14000, skip = { SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, TEMPLATE: 1, SVG: 1, CANVAS: 1, IFRAME: 1 };
  let text = '';
  try {
    if (scope === 'screen') {
      const w = innerWidth, h = innerHeight, parts = []; let last = null;
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, { acceptNode(n) { const p = n.parentElement; return !p || skip[p.tagName.toUpperCase()] || !n.nodeValue.trim() ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT; } });
      for (let n = walker.nextNode(); n; n = walker.nextNode()) {
        const p = n.parentElement, cs = getComputedStyle(p);
        if (cs.visibility === 'hidden' || cs.display === 'none') continue;
        const r = document.createRange(); r.selectNodeContents(n); const b = r.getBoundingClientRect();
        if (!b.width || !b.height || b.bottom < 0 || b.top > h || b.right < 0 || b.left > w) continue;
        const blk = p.closest('p,li,h1,h2,h3,h4,h5,h6,tr,div,section,article,pre,td,th,label,button') || p;
        parts.push((blk !== last && parts.length ? '\n' : ' ') + n.nodeValue.replace(/\s+/g, ' ').trim()); last = blk;
      }
      text = parts.join('').replace(/ \n/g, '\n').trim();
    } else text = (document.body.innerText || '').replace(/\n{3,}/g, '\n\n').trim();
  } catch (e) { text = ''; }
  if (text.length > MAX) { text = text.slice(0, MAX); out.cut = true; }
  out.text = text;
  try {
    const seen = [];
    for (const el of document.querySelectorAll('input, textarea, select')) {
      const t = (el.type || '').toLowerCase();
      if (['hidden', 'password', 'file', 'checkbox', 'radio', 'button', 'submit', 'image'].includes(t) || /^(cc-|one-time|new-password|current-password)/.test(el.autocomplete || '')) continue;
      const r = el.getBoundingClientRect(); if (!r.width || !r.height) continue;
      const lab = (el.labels && el.labels[0] && el.labels[0].innerText) || el.getAttribute('aria-label') || el.placeholder || el.name || '';
      seen.push({ label: String(lab).replace(/\s+/g, ' ').trim().slice(0, 80), value: String(el.value || '').slice(0, 300) });
      if (seen.length >= 20) break;
    }
    out.fields = seen;
  } catch (e) { /* none */ }
  return out;
}

/** Google Docs, Slides and Sheets draw on a canvas, so their words come from the file's own text export. */
async function coeReadDoc() {
  const m = location.pathname.match(/^\/(document|presentation|spreadsheets)\/d\/([^/]+)/);
  if (location.hostname !== 'docs.google.com' || !m) return null;
  const kind = m[1], id = m[2];
  const url = kind === 'document' ? '/document/d/' + id + '/export?format=txt' : kind === 'presentation' ? '/presentation/d/' + id + '/export/txt' : '/spreadsheets/d/' + id + '/export?format=csv';
  try {
    const r = await fetch(url, { credentials: 'include' });
    if (!r.ok) return { kind, error: r.status };
    return { kind, text: (await r.text()).replace(/^﻿/, '').slice(0, 14000) };
  } catch (e) { return { kind, error: 'fetch' }; }
}

/** Runs in the page's own world, to reach code editors (Monaco, CodeMirror, Ace). Returns the code and what is selected. */
function coeReadEditor() {
  try {
    const mo = window.monaco && window.monaco.editor;
    if (mo && mo.getEditors) {
      const eds = mo.getEditors(), ed = eds.find((e) => e.hasTextFocus && e.hasTextFocus()) || eds[0];
      if (ed && ed.getModel()) { const sel = ed.getSelection(), model = ed.getModel(); return { editor: 'Monaco', lang: model.getLanguageId ? model.getLanguageId() : '', code: model.getValue().slice(0, 12000), selection: sel && !sel.isEmpty() ? model.getValueInRange(sel) : '' }; }
    }
    const cm5 = document.querySelector('.CodeMirror');
    if (cm5 && cm5.CodeMirror) { const cm = cm5.CodeMirror; return { editor: 'CodeMirror', lang: '', code: cm.getValue().slice(0, 12000), selection: cm.getSelection() || '' }; }
    const aceEl = document.querySelector('.ace_editor');
    if (aceEl && window.ace) { const ed = window.ace.edit(aceEl); return { editor: 'Ace', lang: '', code: ed.getValue().slice(0, 12000), selection: ed.getSelectedText() || '' }; }
    const cm6 = document.querySelector('.cm-content');
    if (cm6) return { editor: 'CodeMirror', lang: '', code: (cm6.innerText || '').slice(0, 12000), selection: String(getSelection() || '') };
  } catch (e) { /* not there */ }
  return null;
}

/**
 * Changes text on the page, in the page's own world. `find` is the exact words to replace; empty means what is selected.
 * Works in boxes you type in, rich-text boxes, Monaco, CodeMirror, Ace, and Google Docs and Slides (the last two are best effort).
 */
function coeApply(p) {
  const find = String(p.find || ''), text = String(p.text == null ? '' : p.text);
  const fire = (el) => { el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); };
  try {
    // Monaco
    const mo = window.monaco && window.monaco.editor;
    if (mo && mo.getEditors) {
      const eds = mo.getEditors(), ed = eds.find((e) => e.hasTextFocus && e.hasTextFocus()) || eds[0];
      if (ed && ed.getModel()) {
        const model = ed.getModel(); let range = null, before = '';
        if (find) { const hit = model.findMatches(find, false, false, true, null, false)[0]; if (hit) range = hit.range; }
        else { const s = ed.getSelection(); if (s && !s.isEmpty()) range = s; }
        if (!range) return { ok: false, why: 'Could not find those words in the code. Select them and try again.' };
        before = model.getValueInRange(range);
        ed.pushUndoStop(); ed.executeEdits('coe', [{ range, text, forceMoveMarkers: true }]); ed.pushUndoStop();
        return { ok: true, where: 'the code editor', before };
      }
    }
    // CodeMirror 5
    const cm5 = document.querySelector('.CodeMirror');
    if (cm5 && cm5.CodeMirror) {
      const cm = cm5.CodeMirror; let a, b;
      if (find) { const i = cm.getValue().indexOf(find); if (i < 0) return { ok: false, why: 'Could not find those words in the code. Select them and try again.' }; a = cm.posFromIndex(i); b = cm.posFromIndex(i + find.length); }
      else if (cm.somethingSelected()) { a = cm.getCursor('from'); b = cm.getCursor('to'); }
      else return { ok: false, why: 'Select the words you want changed first.' };
      const before = cm.getRange(a, b); cm.replaceRange(text, a, b); return { ok: true, where: 'the code editor', before };
    }
    // Ace
    const aceEl = document.querySelector('.ace_editor');
    if (aceEl && window.ace) {
      const ed = window.ace.edit(aceEl); let range = null;
      if (find) { const f = ed.find(find, { caseSensitive: true, wrap: true }); range = f || null; }
      else if (!ed.selection.isEmpty()) range = ed.selection.getRange();
      if (!range) return { ok: false, why: 'Select the words you want changed first.' };
      const before = ed.session.getTextRange(range); ed.session.replace(range, text); return { ok: true, where: 'the code editor', before };
    }
    // Google Docs and Slides: the words go in through the page's hidden typing box
    if (location.hostname === 'docs.google.com') {
      const fr = document.querySelector('.docs-texteventtarget-iframe');
      const d = fr && fr.contentDocument;
      if (d && d.body) { fr.contentWindow.focus(); d.body.focus(); const ok = d.execCommand('insertText', false, text); return ok ? { ok: true, where: 'your document', before: '' } : { ok: false, why: 'Google would not take the change. Copy it and paste it in.' }; }
    }
    // a box you type in
    const el = document.activeElement;
    if (el && (el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && /^(text|search|email|url|tel)?$/.test(el.type)))) {
      let a = el.selectionStart, b = el.selectionEnd;
      if (find) { const i = el.value.indexOf(find); if (i < 0) return { ok: false, why: 'Could not find those words in the box.' }; a = i; b = i + find.length; }
      else if (a === b) return { ok: false, why: 'Select the words you want changed first.' };
      const before = el.value.slice(a, b), proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, el.value.slice(0, a) + text + el.value.slice(b));
      el.setSelectionRange(a, a + text.length); fire(el); return { ok: true, where: 'the box', before };
    }
    // a rich-text box (this also covers CodeMirror 6 and most online editors)
    const ce = el && (el.isContentEditable ? el : el.closest && el.closest('[contenteditable=""],[contenteditable="true"]'));
    const root = ce || document.querySelector('[contenteditable=""],[contenteditable="true"]');
    if (root) {
      root.focus();
      if (find) {
        const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT); let found = false;
        for (let n = w.nextNode(); n; n = w.nextNode()) { const i = n.nodeValue.indexOf(find); if (i >= 0) { const r = document.createRange(); r.setStart(n, i); r.setEnd(n, i + find.length); const s = getSelection(); s.removeAllRanges(); s.addRange(r); found = true; break; } }
        if (!found) return { ok: false, why: 'Could not find those words in the page.' };
      } else if (!String(getSelection() || '')) return { ok: false, why: 'Select the words you want changed first.' };
      const before = String(getSelection() || '');
      return document.execCommand('insertText', false, text) ? { ok: true, where: 'the page', before } : { ok: false, why: 'This page would not take the change. Copy it and paste it in.' };
    }
  } catch (e) { return { ok: false, why: 'The page stopped that change.' }; }
  return { ok: false, why: 'Click into the box you want changed first, then try again.' };
}

/** Marks words on the page without changing the page. Uses the browser's own highlighter. */
function coeHighlight(phrases) {
  if (!window.CSS || !CSS.highlights || typeof Highlight === 'undefined') return { ok: false, n: 0, unsupported: true };
  let st = document.getElementById('coe-hl-style');
  if (!st) { st = document.createElement('style'); st.id = 'coe-hl-style'; st.textContent = '::highlight(coe) { background-color: #F2D36B; color: #171717; }'; document.documentElement.appendChild(st); }
  const ranges = [], list = (phrases || []).map((s) => String(s).trim()).filter(Boolean).slice(0, 14);
  const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, { acceptNode(n) { const p = n.parentElement; return p && !/^(SCRIPT|STYLE|NOSCRIPT)$/i.test(p.tagName) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT; } });
  const nodes = []; for (let n = w.nextNode(); n; n = w.nextNode()) nodes.push(n);
  for (const ph of list) {
    const low = ph.toLowerCase();
    for (const n of nodes) { const i = n.nodeValue.toLowerCase().indexOf(low); if (i >= 0) { const r = new Range(); r.setStart(n, i); r.setEnd(n, i + ph.length); ranges.push(r); break; } }
  }
  CSS.highlights.set('coe', new Highlight(...ranges));
  if (ranges[0]) { const el = ranges[0].startContainer.parentElement; if (el && el.scrollIntoView) el.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
  return { ok: ranges.length > 0, n: ranges.length };
}
function coeClearHighlight() { try { CSS.highlights.delete('coe'); } catch (e) { /* none */ } return true; }


/**
 * Finds the questions on the page. It only reads: nothing on the page changes. Forms (Google Forms, Microsoft Forms and any other),
 * and pages with numbered questions. The boxes and buttons it found are kept in this tab's own memory, so a later press can reach them.
 */
function coeFindQuestions() {
  const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim();
  const vis = (el) => { try { const r = el.getBoundingClientRect(), cs = getComputedStyle(el); return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none'; } catch (e) { return false; } };
  const items = [], refs = [];
  const CTL = 'input:not([type=hidden]):not([type=password]):not([type=submit]):not([type=button]):not([type=reset]):not([type=file]):not([type=image]):not([type=search]), textarea, select, [role=radio], [role=checkbox], [role=textbox][contenteditable]';
  const labelOf = (el) => {
    let t = '';
    if (el.labels && el.labels[0]) t = el.labels[0].innerText;
    if (!t) t = el.getAttribute('aria-label') || el.getAttribute('data-value') || '';
    if (!t && el.closest('label')) t = el.closest('label').innerText;
    if (!t && el.nextSibling) t = el.nextSibling.textContent || (el.nextElementSibling && el.nextElementSibling.innerText) || '';
    if (!t && el.getAttribute('role')) t = el.innerText || '';
    if (!t && el.parentElement) t = el.parentElement.innerText;
    return norm(t).slice(0, 160);
  };
  const kindOf = (el) => {
    const r = (el.getAttribute('role') || '').toLowerCase(), t = (el.type || '').toLowerCase(), tag = el.tagName;
    if (r === 'radio' || t === 'radio') return 'one';
    if (r === 'checkbox' || t === 'checkbox') return 'many';
    if (tag === 'SELECT') return 'select';
    if (tag === 'TEXTAREA' || r === 'textbox') return 'long';
    return 'text';
  };
  const groups = new Map();
  for (const el of document.querySelectorAll(CTL)) {
    if (!vis(el)) continue;
    const k = kindOf(el);
    let key;
    if (k === 'one' || k === 'many') {
      const g = el.closest('[role=radiogroup],[role=group],fieldset,[role=listitem],[data-automation-id=questionItem]');
      key = k + ':' + (el.name || '') + ':' + (g ? (g.__coeK = g.__coeK || Math.random().toString(36).slice(2)) : (el.parentElement && (el.parentElement.__coeK = el.parentElement.__coeK || Math.random().toString(36).slice(2))));
    } else key = 'one-' + groups.size;
    if (!groups.has(key)) groups.set(key, { kind: k, els: [] });
    groups.get(key).els.push(el);
  }
  const all = [...document.querySelectorAll(CTL)].filter(vis);
  const own = (g) => {
    // the smallest box that holds this question's boxes and no other question's
    let c = g.els[0].parentElement, best = c;
    while (c && c !== document.body) {
      const inside = all.filter((x) => c.contains(x));
      if (inside.some((x) => !g.els.includes(x))) break;
      best = c; c = c.parentElement;
    }
    return best || g.els[0].parentElement;
  };
  for (const g of groups.values()) {
    const box = own(g); if (!box) continue;
    let q = '';
    const head = box.querySelector('legend,[role=heading],[data-automation-id=questionTitle],h1,h2,h3,h4,h5,h6,[class*=title i],[class*=question i]');
    if (head && !g.els.some((e) => head.contains(e))) q = norm(head.innerText);
    const opts = g.kind === 'select' ? [...g.els[0].options].map((o) => norm(o.text)).filter((t) => t && !/^(choose|select|--)/i.test(t)).slice(0, 40) : g.kind === 'one' || g.kind === 'many' ? g.els.map(labelOf).filter(Boolean).slice(0, 12) : [];
    if (!q) {
      let t = norm(box.innerText);
      for (const o of opts) t = t.split(o).join(' ');
      q = norm(t);
    }
    if (!q && g.els[0]) q = norm(g.els[0].getAttribute('aria-label') || g.els[0].placeholder || (g.els[0].labels && g.els[0].labels[0] && g.els[0].labels[0].innerText) || '');
    q = q.replace(/\s*\*\s*$/, '').slice(0, 500);
    if (q.length < 2 && !opts.length) continue;
    const cur = g.kind === 'text' || g.kind === 'long' ? String(g.els[0].value != null ? g.els[0].value : g.els[0].innerText || '').slice(0, 300) : '';
    items.push({ id: String(items.length), text: q || 'Question ' + (items.length + 1), kind: g.kind, options: opts, fillable: true, value: cur });
    refs.push({ kind: g.kind, els: g.els, box });
    if (items.length >= 40) break;
  }
  // pages with no boxes to fill (practice sites, text books): numbered or question-mark lines, with lettered options under them
  if (items.length < 2) {
    const lines = String(document.body.innerText || '').split('\n').map(norm).filter(Boolean);
    const seen = new Set();
    for (let i = 0; i < lines.length && items.length < 30; i++) {
      const L = lines[i];
      const numbered = /^(Q(uestion)?\s*\d+|\d{1,2}[.)])\s+\S/.test(L), asks = /\?$/.test(L) && L.length > 12;
      if (!(numbered || asks) || L.length > 400 || seen.has(L)) continue;
      seen.add(L);
      const opts = [];
      for (let j = i + 1; j < Math.min(lines.length, i + 8); j++) { if (/^\(?[A-Da-d][.)]\s+\S/.test(lines[j]) && lines[j].length < 140) opts.push(lines[j]); else if (opts.length) break; }
      items.push({ id: String(items.length), text: L, kind: opts.length ? 'one' : 'open', options: opts, fillable: false, value: '' });
      refs.push({ kind: 'open', els: [], box: null });
    }
  }
  window.__coeQ = refs;
  const onScreen = (() => { try { const w = innerWidth, h = innerHeight, parts = []; const wk = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, { acceptNode(n) { const p = n.parentElement; return !p || /^(SCRIPT|STYLE|NOSCRIPT|SVG)$/i.test(p.tagName) || !n.nodeValue.trim() ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT; } }); for (let n = wk.nextNode(); n; n = wk.nextNode()) { const p = n.parentElement; if (!vis(p)) continue; const r = document.createRange(); r.selectNodeContents(n); const b = r.getBoundingClientRect(); if (!b.width || b.bottom < 0 || b.top > h || b.right < 0 || b.left > w) continue; parts.push(norm(n.nodeValue)); } return parts.join(' ').slice(0, 1500); } catch (e) { return ''; } })();
  return { ok: true, title: document.title || location.hostname, url: location.href, items, onScreen, forms: refs.some((r) => r.els.length > 0) };
}

/** Puts an answer into the box or option that coeFindQuestions found. Never on school-work sites. Returns what was there before, so it can be undone. */
function coeFillAnswer(id, answer, undo) {
  if (/sparx|seneca|smart-?revise|go-?code|blooket|kahoot|gimkit|quizizz|wayground|edpuzzle|educake|hegarty|tassomai|century\.tech|mathswatch|drfrost|kerboodle|socrative|nearpod|classroom\.google|forms\.(gle|office|microsoft)|instructure/i.test(location.hostname) || /^\/forms\/|\/mod\/quiz/i.test(location.pathname) && /google|moodle/i.test(location.hostname + location.pathname)) return { ok: false, why: 'Coe does not type into homework or quiz pages.' };
  const q = (window.__coeQ || [])[Number(id)];
  if (!q || !q.els.length) return { ok: false, why: 'That box is gone. Find the questions again.' };
  const norm = (s) => String(s || '').toLowerCase().replace(/\s+/g, ' ').trim();
  const fire = (el) => { el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); };
  const labelOf = (el) => { let t = ''; if (el.labels && el.labels[0]) t = el.labels[0].innerText; if (!t) t = el.getAttribute('aria-label') || el.getAttribute('data-value') || ''; if (!t && el.closest('label')) t = el.closest('label').innerText; if (!t && el.nextSibling) t = el.nextSibling.textContent || ''; if (!t && el.getAttribute('role')) t = el.innerText || ''; return norm(t); };
  const checked = (el) => el.getAttribute('aria-checked') === 'true' || el.checked === true;
  try {
    const first = q.els[0];
    if (q.kind === 'text' || q.kind === 'long') {
      const v = Array.isArray(answer) ? answer.join(' ') : String(answer == null ? '' : answer), before = undo ? '' : String(first.value != null ? first.value : first.innerText || '');
      if (first.isContentEditable || first.getAttribute('role') === 'textbox') { first.focus(); document.execCommand('selectAll', false); document.execCommand('insertText', false, v); }
      else { const proto = first.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype; Object.getOwnPropertyDescriptor(proto, 'value').set.call(first, v); fire(first); }
      return { ok: true, before };
    }
    if (q.kind === 'select') {
      const want = norm(Array.isArray(answer) ? answer[0] : answer), sel = first, before = sel.selectedOptions[0] ? sel.selectedOptions[0].text : '';
      const o = [...sel.options].find((x) => norm(x.text) === want) || [...sel.options].find((x) => norm(x.text).includes(want) || (want && want.includes(norm(x.text)) && norm(x.text).length > 1));
      if (!o) return { ok: false, why: 'That option is not in the list.' };
      sel.value = o.value; fire(sel); return { ok: true, before };
    }
    // one choice or many: match the wanted option names to the options on the page
    const wants = (Array.isArray(answer) ? answer : String(answer == null ? '' : answer).split(/\s*(?:;|\n| \| )\s*/)).map(norm).filter(Boolean);
    const labels = q.els.map(labelOf), hit = [];
    for (const w of wants) {
      let i = labels.findIndex((l) => l === w);
      if (i < 0) i = labels.findIndex((l) => l.replace(/^\(?[a-d][.)]\s+/, '') === w.replace(/^\(?[a-d][.)]\s+/, ''));
      if (i < 0) i = labels.findIndex((l) => l && (l.includes(w) || w.includes(l)) && Math.min(l.length, w.length) > 1);
      if (i >= 0 && !hit.includes(i)) hit.push(i);
    }
    const before = q.els.map((e, i) => (checked(e) ? labels[i] : '')).filter(Boolean).join('; ');
    if (undo) {   // put the ticks back as they were (an empty list means nothing was ticked)
      for (let i = 0; i < q.els.length; i++) if (q.kind === 'many' && checked(q.els[i]) !== hit.includes(i)) q.els[i].click();
      if (q.kind === 'one' && hit.length && !checked(q.els[hit[0]])) q.els[hit[0]].click();
      return { ok: true, before };
    }
    if (!hit.length) return { ok: false, why: 'Could not match that answer to an option on the page.' };
    for (const i of q.kind === 'one' ? hit.slice(0, 1) : hit) if (!checked(q.els[i])) q.els[i].click();
    return { ok: true, before };
  } catch (e) { return { ok: false, why: 'The page stopped that.' }; }
}
