// Small functions that run inside the page you are on. Chrome copies each one into the page when it is used,
// so every one is self-contained. They only run when you press something in the Coe sidebar.

/** Reads the page: its words (all of it, or only what is on screen), what you selected, and the boxes you can type in. Never passwords. */
function coeReadPage(scope) {
  const out = { url: location.href, host: location.hostname, title: document.title || location.hostname, selection: '', text: '', fields: [], cut: false };
  try { out.selection = String(getSelection() || '').slice(0, 4000); } catch (e) { /* none */ }
  const MAX = 14000, skip = { SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, TEMPLATE: 1, SVG: 1, CANVAS: 1, IFRAME: 1 };
  let text = '';
  try {
    if (scope === 'screen') {
      const w = innerWidth, h = innerHeight, parts = []; let last = null;
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, { acceptNode(n) { const p = n.parentElement; return !p || skip[p.tagName.toUpperCase()] || !n.nodeValue.trim() ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT; } });
      for (let n = walker.nextNode(); n; n = walker.nextNode()) {
        const p = n.parentElement, cs = getComputedStyle(p);
        if (cs.visibility === 'hidden' || cs.display === 'none') continue;
        const r = document.createRange(); r.selectNodeContents(n); const b = r.getBoundingClientRect();
        if (!b.width || !b.height || b.bottom < 0 || b.top > h || b.right < 0 || b.left > w) continue;
        const blk = p.closest('p,li,h1,h2,h3,h4,h5,h6,tr,div,section,article,pre,td,th,label,button') || p;
        parts.push((blk !== last && parts.length ? '\n' : ' ') + n.nodeValue.replace(/\s+/g, ' ').trim()); last = blk;
      }
      text = parts.join('').replace(/ \n/g, '\n').trim();
    } else text = (document.body.innerText || '').replace(/\n{3,}/g, '\n\n').trim();
  } catch (e) { text = ''; }
  if (text.length > MAX) { text = text.slice(0, MAX); out.cut = true; }
  out.text = text;
  try {
    const seen = [];
    for (const el of document.querySelectorAll('input, textarea, select')) {
      const t = (el.type || '').toLowerCase();
      if (['hidden', 'password', 'file', 'checkbox', 'radio', 'button', 'submit', 'image'].includes(t) || /^(cc-|one-time|new-password|current-password)/.test(el.autocomplete || '')) continue;
      const r = el.getBoundingClientRect(); if (!r.width || !r.height) continue;
      const lab = (el.labels && el.labels[0] && el.labels[0].innerText) || el.getAttribute('aria-label') || el.placeholder || el.name || '';
      seen.push({ label: String(lab).replace(/\s+/g, ' ').trim().slice(0, 80), value: String(el.value || '').slice(0, 300) });
      if (seen.length >= 20) break;
    }
    out.fields = seen;
  } catch (e) { /* none */ }
  return out;
}

/** Google Docs, Slides and Sheets draw on a canvas, so their words come from the file's own text export. */
async function coeReadDoc() {
  const m = location.pathname.match(/^\/(document|presentation|spreadsheets)\/d\/([^/]+)/);
  if (location.hostname !== 'docs.google.com' || !m) return null;
  const kind = m[1], id = m[2];
  const url = kind === 'document' ? '/document/d/' + id + '/export?format=txt' : kind === 'presentation' ? '/presentation/d/' + id + '/export/txt' : '/spreadsheets/d/' + id + '/export?format=csv';
  try {
    const r = await fetch(url, { credentials: 'include' });
    if (!r.ok) return { kind, error: r.status };
    return { kind, text: (await r.text()).replace(/^﻿/, '').slice(0, 14000) };
  } catch (e) { return { kind, error: 'fetch' }; }
}

/** Runs in the page's own world, to reach code editors (Monaco, CodeMirror, Ace). Returns the code and what is selected. */
function coeReadEditor() {
  try {
    const mo = window.monaco && window.monaco.editor;
    if (mo && mo.getEditors) {
      const eds = mo.getEditors(), ed = eds.find((e) => e.hasTextFocus && e.hasTextFocus()) || eds[0];
      if (ed && ed.getModel()) { const sel = ed.getSelection(), model = ed.getModel(); return { editor: 'Monaco', lang: model.getLanguageId ? model.getLanguageId() : '', code: model.getValue().slice(0, 12000), selection: sel && !sel.isEmpty() ? model.getValueInRange(sel) : '' }; }
    }
    const cm5 = document.querySelector('.CodeMirror');
    if (cm5 && cm5.CodeMirror) { const cm = cm5.CodeMirror; return { editor: 'CodeMirror', lang: '', code: cm.getValue().slice(0, 12000), selection: cm.getSelection() || '' }; }
    const aceEl = document.querySelector('.ace_editor');
    if (aceEl && window.ace) { const ed = window.ace.edit(aceEl); return { editor: 'Ace', lang: '', code: ed.getValue().slice(0, 12000), selection: ed.getSelectedText() || '' }; }
    const cm6 = document.querySelector('.cm-content');
    if (cm6) return { editor: 'CodeMirror', lang: '', code: (cm6.innerText || '').slice(0, 12000), selection: String(getSelection() || '') };
  } catch (e) { /* not there */ }
  return null;
}

/**
 * Changes text on the page, in the page's own world. `find` is the exact words to replace; empty means what is selected.
 * Works in boxes you type in, rich-text boxes, Monaco, CodeMirror, Ace, and Google Docs and Slides (the last two are best effort).
 */
function coeApply(p) {
  const find = String(p.find || ''), text = String(p.text == null ? '' : p.text);
  const fire = (el) => { el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); };
  try {
    // Monaco
    const mo = window.monaco && window.monaco.editor;
    if (mo && mo.getEditors) {
      const eds = mo.getEditors(), ed = eds.find((e) => e.hasTextFocus && e.hasTextFocus()) || eds[0];
      if (ed && ed.getModel()) {
        const model = ed.getModel(); let range = null, before = '';
        if (find) { const hit = model.findMatches(find, false, false, true, null, false)[0]; if (hit) range = hit.range; }
        else { const s = ed.getSelection(); if (s && !s.isEmpty()) range = s; }
        if (!range) return { ok: false, why: 'Could not find those words in the code. Select them and try again.' };
        before = model.getValueInRange(range);
        ed.pushUndoStop(); ed.executeEdits('coe', [{ range, text, forceMoveMarkers: true }]); ed.pushUndoStop();
        return { ok: true, where: 'the code editor', before };
      }
    }
    // CodeMirror 5
    const cm5 = document.querySelector('.CodeMirror');
    if (cm5 && cm5.CodeMirror) {
      const cm = cm5.CodeMirror; let a, b;
      if (find) { const i = cm.getValue().indexOf(find); if (i < 0) return { ok: false, why: 'Could not find those words in the code. Select them and try again.' }; a = cm.posFromIndex(i); b = cm.posFromIndex(i + find.length); }
      else if (cm.somethingSelected()) { a = cm.getCursor('from'); b = cm.getCursor('to'); }
      else return { ok: false, why: 'Select the words you want changed first.' };
      const before = cm.getRange(a, b); cm.replaceRange(text, a, b); return { ok: true, where: 'the code editor', before };
    }
    // Ace
    const aceEl = document.querySelector('.ace_editor');
    if (aceEl && window.ace) {
      const ed = window.ace.edit(aceEl); let range = null;
      if (find) { const f = ed.find(find, { caseSensitive: true, wrap: true }); range = f || null; }
      else if (!ed.selection.isEmpty()) range = ed.selection.getRange();
      if (!range) return { ok: false, why: 'Select the words you want changed first.' };
      const before = ed.session.getTextRange(range); ed.session.replace(range, text); return { ok: true, where: 'the code editor', before };
    }
    // Google Docs and Slides: the words go in through the page's hidden typing box
    if (location.hostname === 'docs.google.com') {
      const fr = document.querySelector('.docs-texteventtarget-iframe');
      const d = fr && fr.contentDocument;
      if (d && d.body) { fr.contentWindow.focus(); d.body.focus(); const ok = d.execCommand('insertText', false, text); return ok ? { ok: true, where: 'your document', before: '' } : { ok: false, why: 'Google would not take the change. Copy it and paste it in.' }; }
    }
    // a box you type in
    const el = document.activeElement;
    if (el && (el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && /^(text|search|email|url|tel)?$/.test(el.type)))) {
      let a = el.selectionStart, b = el.selectionEnd;
      if (find) { const i = el.value.indexOf(find); if (i < 0) return { ok: false, why: 'Could not find those words in the box.' }; a = i; b = i + find.length; }
      else if (a === b) return { ok: false, why: 'Select the words you want changed first.' };
      const before = el.value.slice(a, b), proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, el.value.slice(0, a) + text + el.value.slice(b));
      el.setSelectionRange(a, a + text.length); fire(el); return { ok: true, where: 'the box', before };
    }
    // a rich-text box (this also covers CodeMirror 6 and most online editors)
    const ce = el && (el.isContentEditable ? el : el.closest && el.closest('[contenteditable=""],[contenteditable="true"]'));
    const root = ce || document.querySelector('[contenteditable=""],[contenteditable="true"]');
    if (root) {
      root.focus();
      if (find) {
        const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT); let found = false;
        for (let n = w.nextNode(); n; n = w.nextNode()) { const i = n.nodeValue.indexOf(find); if (i >= 0) { const r = document.createRange(); r.setStart(n, i); r.setEnd(n, i + find.length); const s = getSelection(); s.removeAllRanges(); s.addRange(r); found = true; break; } }
        if (!found) return { ok: false, why: 'Could not find those words in the page.' };
      } else if (!String(getSelection() || '')) return { ok: false, why: 'Select the words you want changed first.' };
      const before = String(getSelection() || '');
      return document.execCommand('insertText', false, text) ? { ok: true, where: 'the page', before } : { ok: false, why: 'This page would not take the change. Copy it and paste it in.' };
    }
  } catch (e) { return { ok: false, why: 'The page stopped that change.' }; }
  return { ok: false, why: 'Click into the box you want changed first, then try again.' };
}

/** Marks words on the page without changing the page: highlighted, underlined or bold, like the editor on the Coe website. Uses the browser's own highlighter. */
function coeHighlight(phrases, styles) {
  if (!window.CSS || !CSS.highlights || typeof Highlight === 'undefined') return { ok: false, n: 0, unsupported: true };
  const NAME = { highlight: 'coe', underline: 'coe-u', bold: 'coe-b' };
  const want = (Array.isArray(styles) ? styles : [styles || 'highlight']).filter((x) => NAME[x]); if (!want.length) want.push('highlight');
  const css = '::highlight(coe) { background-color: #F2D36B; color: #171717; } ::highlight(coe-u) { text-decoration: underline 3px #1A4934; } ::highlight(coe-b) { text-shadow: 0.55px 0 0 currentColor, -0.55px 0 0 currentColor; -webkit-text-stroke: 0.5px currentColor; }';
  let st = document.getElementById('coe-hl-style');
  if (!st) { st = document.createElement('style'); st.id = 'coe-hl-style'; document.documentElement.appendChild(st); }
  st.textContent = css;
  const ranges = [], list = (phrases || []).map((s) => String(s).trim()).filter(Boolean).slice(0, 14);
  const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, { acceptNode(n) { const p = n.parentElement; return p && !/^(SCRIPT|STYLE|NOSCRIPT)$/i.test(p.tagName) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT; } });
  const nodes = []; for (let n = w.nextNode(); n; n = w.nextNode()) nodes.push(n);
  for (const ph of list) {
    const low = ph.toLowerCase();
    for (const n of nodes) { const i = n.nodeValue.toLowerCase().indexOf(low); if (i >= 0) { const r = new Range(); r.setStart(n, i); r.setEnd(n, i + ph.length); ranges.push(r); break; } }
  }
  for (const k of want) CSS.highlights.set(NAME[k], new Highlight(...ranges));
  if (ranges[0]) { const el = ranges[0].startContainer.parentElement; if (el && el.scrollIntoView) el.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
  return { ok: ranges.length > 0, n: ranges.length };
}
function coeClearHighlight() { try { CSS.highlights.delete('coe'); CSS.highlights.delete('coe-u'); CSS.highlights.delete('coe-b'); } catch (e) { /* none */ } return true; }


/**
 * Finds the questions on the page. It only reads: nothing on the page changes. Forms (Google Forms, Microsoft Forms and any other),
 * and pages with numbered questions. It reads the words (maths included) and takes the pictures that belong to each question.
 * The boxes and buttons it found are kept in this tab's own memory, so a later press can reach them.
 */
async function coeFindQuestions(withPictures) {
  const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim();
  const vis = (el) => { try { const r = el.getBoundingClientRect(), cs = getComputedStyle(el); return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none'; } catch (e) { return false; } };
  const BLOCK = /^(P|DIV|LI|UL|OL|TR|TABLE|H[1-6]|SECTION|ARTICLE|FIGURE|FIGCAPTION|BLOCKQUOTE|PRE|FIELDSET|LEGEND|HEADER|FOOTER|MAIN|DT|DD|FORM)$/;
  const inMath = (el) => !!(el.closest && el.closest('.katex,.katex-display,mjx-container,.MathJax,math,[data-mathml]'));
  /** The words of a part of the page, with maths as $LaTeX$ (not doubled) and pictures as [picture: what it says]. */
  const txt = (root, cap, noBtn) => {
    const out = []; let len = 0; const MAXC = cap || 1600;
    const push = (t) => { if (len < MAXC) { out.push(t); len += t.length; } };
    const walk = (n) => {
      if (len >= MAXC) return;
      if (n.nodeType === 3) { push(n.nodeValue); return; }
      if (n.nodeType !== 1) return;
      const t = n.tagName;
      if (/^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE|SELECT|OPTION|INPUT|TEXTAREA)$/.test(t)) return;
      if (n !== root && !vis(n)) return;
      if (noBtn && n !== root && (t === 'BUTTON' || n.getAttribute('role') === 'button')) return;
      if (n.matches && n.matches('.katex,.katex-display,mjx-container,.MathJax,math')) {
        const a = n.querySelector('annotation[encoding="application/x-tex"]'), ms = n.querySelector('mjx-assistive-mml');
        const sib = n.nextElementSibling && n.nextElementSibling.matches && n.nextElementSibling.matches('script[type^="math/tex"]') ? n.nextElementSibling.textContent : '';
        const v = a ? a.textContent : sib || n.getAttribute('data-latex') || (ms ? ms.textContent : '') || n.getAttribute('aria-label') || n.textContent;
        push(' $' + norm(v) + '$ '); return;
      }
      if (t === 'IMG') { const r = n.getBoundingClientRect(); if (r.width >= 20 && r.height >= 20 && !inMath(n)) push(' [picture' + (norm(n.alt) ? ': ' + norm(n.alt).slice(0, 120) : '') + '] '); return; }
      if (t === 'SVG' || t === 'svg' || t === 'CANVAS') { const r = n.getBoundingClientRect(); if (r.width >= 40 && r.height >= 40 && !inMath(n)) push(' [diagram] '); return; }
      if (t === 'BR') { push('\n'); return; }
      let blk = BLOCK.test(t); if (!blk) { try { blk = !/^(inline|inline-block|inline-flex|inline-grid|contents|ruby|ruby-text)/.test(getComputedStyle(n).display); } catch (e) { /* inline */ } } if (blk) push('\n');
      for (const c of n.childNodes) walk(c);
      if (blk) push('\n');
    };
    walk(root);
    return out.join('').replace(/[ \t\r\f\v]+/g, ' ').replace(/ ?\n ?/g, '\n').replace(/\n{2,}/g, '\n').trim();
  };
  // what sits next to a question but is not part of it: the counter, timer, score and the buttons
  const FURN = [/^(?:question|q|step|page)\s*\d{1,3}\s*(?:\/|of|out of)\s*\d{1,3}$/i, /^\d{1,3}\s*\/\s*\d{1,3}$/, /^(?:timer|time(?: left)?|score|points|xp|streak|coins|lives|level)\b[^\n]{0,24}$/i, /^\d{1,2}:\d{2}(?::\d{2})?$/, /^(?:skip|submit|next|previous|back|check|check answer|continue|hint|done|finish|clear|reset|save|cancel|ok|i don'?t know)$/i, /^[\d,]+\s*(?:xp|points|pts)$/i, /^of\s*\d{1,3}$/i];
  const clean = (t) => String(t).split('\n').map(norm).filter((l) => l && !FURN.some((re) => re.test(l))).join('\n');
  const items = [], refs = [];
  const CTL = 'input:not([type=hidden]):not([type=password]):not([type=submit]):not([type=button]):not([type=reset]):not([type=file]):not([type=image]):not([type=search]), textarea, select, [role=radio], [role=checkbox], [role=textbox][contenteditable]';
  const labelOf = (el) => {
    let t = '';
    if (el.labels && el.labels[0]) t = txt(el.labels[0], 300);
    if (!t) t = el.getAttribute('aria-label') || el.getAttribute('data-value') || '';
    if (!t && el.closest('label')) t = txt(el.closest('label'), 300);
    if (!t && el.nextSibling) t = el.nextSibling.textContent || (el.nextElementSibling && txt(el.nextElementSibling, 300)) || '';
    if (!t && el.getAttribute('role')) t = txt(el, 300);
    if (!t && el.parentElement) t = txt(el.parentElement, 300);
    return norm(t).slice(0, 200);
  };
  const kindOf = (el) => {
    const r = (el.getAttribute('role') || '').toLowerCase(), t = (el.type || '').toLowerCase(), tag = el.tagName;
    if (r === 'radio' || t === 'radio') return 'one';
    if (r === 'checkbox' || t === 'checkbox') return 'many';
    if (tag === 'SELECT') return 'select';
    if (tag === 'TEXTAREA' || r === 'textbox') return 'long';
    return 'text';
  };
  const groups = new Map();
  const tag = (el) => (el.__coeK = el.__coeK || Math.random().toString(36).slice(2));
  for (const el of document.querySelectorAll(CTL)) {
    if (!vis(el)) continue;
    const k = kindOf(el);
    let key;
    if (k === 'one' || k === 'many') {
      const g = el.closest('[role=radiogroup],[role=group],fieldset,[role=listitem],[data-automation-id=questionItem]');
      key = k + ':' + (el.name || '') + ':' + (g ? tag(g) : el.parentElement && tag(el.parentElement));
    } else key = 'one-' + groups.size;
    if (!groups.has(key)) groups.set(key, { kind: k, els: [] });
    groups.get(key).els.push(el);
  }
  // answers made of buttons or tiles (practice sites often do not use real radio buttons)
  try {
    const used = new Set(); for (const g of groups.values()) g.els.forEach((e) => used.add(e));
    for (const c of document.querySelectorAll('[class*=option i],[class*=answer i],[class*=choice i],[class*=mcq i],[role=listbox],[role=group],ul,ol')) {
      if (!vis(c) || c.closest('nav,header,footer,[role=tablist],[role=menu],[role=navigation]')) continue;
      const kids = [...c.children].filter((x) => vis(x) && !used.has(x) && /^(BUTTON|LI|LABEL|DIV|A)$/.test(x.tagName) && (x.tagName === 'BUTTON' || x.getAttribute('role') === 'button' || x.getAttribute('role') === 'option' || x.tagName === 'LI' || /option|answer|choice/i.test(x.className || '')));
      if (kids.length < 2 || kids.length > 8) continue;
      const labs = kids.map((x) => norm(txt(x, 200)) || norm(x.querySelector('img') && x.querySelector('img').alt));
      if (labs.some((l) => !l || l.length > 160)) continue;
      if (kids.some((x) => x.querySelector(CTL) || x.querySelector('a[href]:not([role=button])'))) continue;
      if (new Set(labs).size !== labs.length) continue;
      if (!/option|answer|choice|mcq/i.test(String(c.className) + ' ' + (c.getAttribute('role') || '') + ' ' + (c.getAttribute('aria-label') || ''))) continue;
      groups.set('tiles-' + groups.size, { kind: 'one', els: kids, tiles: true, labs }); kids.forEach((e) => used.add(e));
    }
  } catch (e) { /* none */ }
  const all = [...groups.values()].flatMap((g) => g.els);
  const own = (g) => {
    // the smallest box that holds this question's boxes and no other question's
    let c = g.els[0].parentElement, best = c;
    while (c && c !== document.body) {
      const inside = all.filter((x) => c.contains(x));
      if (inside.some((x) => !g.els.includes(x))) break;
      best = c; c = c.parentElement;
    }
    return best || g.els[0].parentElement;
  };
  // pictures that belong to a question: not the page's own logo or buttons, not maths drawn as pictures of symbols
  const pics = (box, near, skipIn) => {
    if (!box) return [];
    const out = [], seen = new Set(), ny = near ? near.top + near.height / 2 : null;
    for (const e of box.querySelectorAll('img,svg,canvas,picture,[role=img]')) {
      if (out.length >= 4) break;
      const t = e.tagName.toLowerCase();
      if (t === 'picture' || (e.closest('picture') && t !== 'img')) continue;
      const chromeBit = e.closest('button,[role=button],nav,header,footer,aside,[role=navigation],[role=tablist]');
      if (!vis(e) || inMath(e)) continue;
      if (e.closest('svg') !== e && t !== 'svg' && e.closest('svg')) continue;
      if (t === 'svg' && e.parentElement && e.parentElement.closest('svg')) continue;
      const r = e.getBoundingClientRect();
      if (r.width < 32 || r.height < 28) continue;
      if (chromeBit && (r.width < 64 || e.closest('nav,header,footer,[role=navigation],[role=tablist]'))) continue;
      if (/logo|avatar|sprite|favicon|emoji/i.test((e.className && e.className.baseVal !== undefined ? e.className.baseVal : e.className) + ' ' + (e.getAttribute('src') || '')) && r.width < 80) continue;
      if (ny !== null && Math.abs(r.top + r.height / 2 - ny) > 900) continue;
      if (skipIn && skipIn.contains(e)) continue;
      if (seen.has(e)) continue; seen.add(e); out.push(e);
    }
    return out;
  };
  /** The picture itself, as a small JPEG, when the page lets us have it. Otherwise null (the sidebar takes a picture of that spot instead). */
  const grab = async (el) => {
    const MAXD = 1000, fit = (w, h) => { const k = Math.min(1, MAXD / Math.max(w, h)); return [Math.max(1, Math.round(w * k)), Math.max(1, Math.round(h * k))]; };
    const out = (cv) => { let d = cv.toDataURL('image/jpeg', 0.84); if (d.length > 450000) d = cv.toDataURL('image/jpeg', 0.6); return d.length < 700000 ? d : null; };
    const paint = (src, w, h) => { const [cw, ch] = fit(w, h), cv = document.createElement('canvas'); cv.width = cw; cv.height = ch; const x = cv.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, cw, ch); x.drawImage(src, 0, 0, cw, ch); return out(cv); };
    try {
      const t = el.tagName.toLowerCase();
      if (t === 'img') {
        if (!el.complete || !el.naturalWidth) { try { await el.decode(); } catch (e) { /* not ready */ } }
        if (!el.naturalWidth) return null;
        try { return paint(el, el.naturalWidth, el.naturalHeight); } catch (e) { /* tainted: try fetching it */ }
        const src = el.currentSrc || el.src; if (!src || /^data:/.test(src) && false) return null;
        const r = await fetch(src, { credentials: 'include' }); if (!r.ok) return null;
        const bm = await createImageBitmap(await r.blob()); return paint(bm, bm.width, bm.height);
      }
      if (t === 'canvas') return paint(el, el.width, el.height);
      if (t === 'svg') {
        const rect = el.getBoundingClientRect(), clone = el.cloneNode(true), a = [el, ...el.querySelectorAll('*')], b = [clone, ...clone.querySelectorAll('*')];
        for (let i = 0; i < Math.min(a.length, 500); i++) { const cs = getComputedStyle(a[i]); let st = ''; for (const p of ['fill', 'stroke', 'stroke-width', 'stroke-dasharray', 'font-size', 'font-family', 'font-weight', 'opacity', 'text-anchor']) st += p + ':' + cs.getPropertyValue(p) + ';'; b[i].setAttribute('style', st); }
        clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg'); clone.setAttribute('width', rect.width); clone.setAttribute('height', rect.height);
        if (!clone.getAttribute('viewBox') && el.getBBox) { try { const bb = el.getBBox(); clone.setAttribute('viewBox', bb.x + ' ' + bb.y + ' ' + bb.width + ' ' + bb.height); } catch (e) { /* none */ } }
        const url = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(new XMLSerializer().serializeToString(clone));
        const im = new Image(); await new Promise((ok, no) => { im.onload = ok; im.onerror = no; im.src = url; setTimeout(no, 2500); });
        return paint(im, Math.max(rect.width * 2, 64), Math.max(rect.height * 2, 64));
      }
    } catch (e) { /* the page would not give it */ }
    return null;
  };
  const picturesFor = async (box, near, skipIn) => {
    const els = pics(box, near, skipIn), list = [];
    for (const e of els) {
      const r = e.getBoundingClientRect(), alt = norm(e.getAttribute('alt') || e.getAttribute('aria-label') || (e.querySelector && e.querySelector('title') && e.querySelector('title').textContent) || '');
      list.push({ kind: e.tagName.toLowerCase(), alt: alt.slice(0, 200), w: Math.round(r.width), h: Math.round(r.height), data: withPictures ? await grab(e) : null });
    }
    return { els, list };
  };
  for (const g of groups.values()) {
    const box = own(g); if (!box) continue;
    let q = '';
    const head = box.querySelector('legend,[role=heading],[data-automation-id=questionTitle],h1,h2,h3,h4,h5,h6,[class*=title i],[class*=question i],[class*=prompt i]');
    if (head && !g.els.some((e) => head.contains(e)) && norm(txt(head, 600)).length > 1) q = norm(txt(head, 900));
    const opts = g.tiles ? g.labs : g.kind === 'select' ? [...g.els[0].options].map((o) => norm(o.text)).filter((t) => t && !/^(choose|select|--)/i.test(t)).slice(0, 40) : g.kind === 'one' || g.kind === 'many' ? g.els.map((e, i) => labelOf(e) || '(option ' + (i + 1) + ')').filter(Boolean).slice(0, 12) : [];
    if (!q) {
      let t = txt(box, 1400, true);
      for (const o of opts) t = t.split(o).join(' ');
      q = clean(t.replace(/[ \t]+/g, ' ').replace(/\n+/g, '\n').trim());
    }
    if (!q && g.els[0]) q = norm(g.els[0].getAttribute('aria-label') || g.els[0].placeholder || (g.els[0].labels && g.els[0].labels[0] && g.els[0].labels[0].innerText) || '');
    q = q.replace(/\s*\*\s*$/, '').slice(0, 900);
    const near = g.els[0].getBoundingClientRect();
    const optBox = g.tiles || g.kind === 'one' || g.kind === 'many' ? null : null; void optBox;
    const pic = await picturesFor(box, near, null);
    if (q.length < 2 && !opts.length && !pic.list.length) continue;
    const cur = g.kind === 'text' || g.kind === 'long' ? String(g.els[0].value != null ? g.els[0].value : g.els[0].innerText || '').slice(0, 300) : '';
    items.push({ id: String(items.length), text: q || 'Question ' + (items.length + 1), kind: g.kind, options: opts, fillable: true, value: cur, imgs: pic.list, boxes: g.kind === 'text' || g.kind === 'long' ? g.els.length : 0 });
    refs.push({ kind: g.kind, els: g.els, box, imgEls: pic.els });
    if (items.length >= 40) break;
  }
  // pages with no boxes to fill (practice sites, text books): numbered or question-mark lines, with lettered options under them
  if (items.length === 0) {
    const lines = clean(txt(document.body, 40000, true)).split('\n').map(norm).filter(Boolean);
    const seen = new Set();
    for (let i = 0; i < lines.length && items.length < 30; i++) {
      const L = lines[i];
      const numbered = /^(Q(uestion)?\s*\d+|\d{1,2}[.)])\s+\S/.test(L), asks = /\?$/.test(L) && L.length > 12;
      if (!(numbered || asks) || L.length > 600 || seen.has(L)) continue;
      seen.add(L);
      const opts = [], more = [];
      for (let j = i + 1; j < Math.min(lines.length, i + 8); j++) { if (/^\(?[A-Da-d][.)]\s+\S/.test(lines[j]) && lines[j].length < 160) opts.push(lines[j]); else if (opts.length) break; else if (j === i + 1 && lines[j].length < 200 && !/^(Q(uestion)?\s*\d+|\d{1,2}[.)])\s+\S/.test(lines[j]) && !/\?$/.test(lines[j]) && /^\[(picture|diagram)|^\$/.test(lines[j])) more.push(lines[j]); }
      // the box on the page that holds this line, for its pictures
      let anchor = null;
      try {
        const key = L.replace(/\[picture[^\]]*\]|\[diagram\]|\$/g, '').trim().slice(0, 24);
        const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, { acceptNode(n) { const p = n.parentElement; return p && !/^(SCRIPT|STYLE|NOSCRIPT)$/i.test(p.tagName) && n.nodeValue.includes(key) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT; } });
        const n = key.length > 5 ? w.nextNode() : null;
        if (n) { let c = n.parentElement; while (c && c.parentElement && c.parentElement !== document.body && txt(c.parentElement, 3000).length < 1400 && c.parentElement.querySelectorAll('[class*=question i]').length < 2) c = c.parentElement; anchor = c; }
      } catch (e) { /* none */ }
      const pic = anchor ? await picturesFor(anchor, null, null) : { els: [], list: [] };
      items.push({ id: String(items.length), text: L, kind: opts.length ? 'one' : 'open', options: opts, fillable: false, value: '', imgs: pic.list, boxes: 0 });
      refs.push({ kind: 'open', els: [], box: anchor, imgEls: pic.els });
    }
  }
  window.__coeQ = refs;
  const onScreen = (() => { try { return clean(txt(document.body, 40000, true)).split('\n').slice(0, 60).join('\n').slice(0, 1800); } catch (e) { return ''; } })();
  const viewOnly = items.length === 0 ? (document.body.innerText || '').trim().length < 80 : false;
  return { ok: true, title: document.title || location.hostname, url: location.href, items, onScreen, forms: refs.some((r) => r.els.length > 0), mostlyPicture: viewOnly, scrollY: window.scrollY, dpr: window.devicePixelRatio || 1 };
}

/** Looks for a row of numbered buttons (Q1 Q2 Q3, or 1 2 3) that switch between questions, so every question can be read. Only looks. */
function coeNavScan() {
  const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim();
  const vis = (el) => { try { const r = el.getBoundingClientRect(), cs = getComputedStyle(el); return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none'; } catch (e) { return false; } };
  const numOf = (el) => { const t = norm(el.innerText || el.getAttribute('aria-label') || el.title || ''); const m = /^(?:q|question|qn)?\s*\.?\s*(\d{1,2})\s*$/i.exec(t) || /^(?:question)\s+(\d{1,2})\b/i.exec(t); return m ? Number(m[1]) : 0; };
  const sel = (el) => el.getAttribute('aria-selected') === 'true' || el.getAttribute('aria-current') === 'true' || el.getAttribute('aria-current') === 'step' || el.getAttribute('aria-pressed') === 'true' || /\b(active|selected|current)\b/i.test(el.className && el.className.baseVal === undefined ? el.className : '');
  const cands = [...document.querySelectorAll('button,[role=tab],[role=button],a,li')].filter((e) => vis(e) && numOf(e) > 0 && !e.closest('nav[aria-label*=breadcrumb i]'));
  const byParent = new Map();
  for (const e of cands) { let p = e.parentElement; for (let d = 0; d < 3 && p; d++, p = p.parentElement) { const k = p; if (!byParent.has(k)) byParent.set(k, new Set()); byParent.get(k).add(e); } }
  let best = null;
  for (const [p, set] of byParent) {
    const els = [...set], nums = els.map(numOf);
    if (els.length < 3 || new Set(nums).size < 3) continue;
    const sorted = [...nums].sort((a, b) => a - b); let run = 1, mx = 1; for (let i = 1; i < sorted.length; i++) { run = sorted[i] === sorted[i - 1] + 1 ? run + 1 : sorted[i] === sorted[i - 1] ? run : 1; mx = Math.max(mx, run); }
    if (mx < 3 || (els.length - mx) > 2) continue;
    const score = els.length * 10 - (p.querySelectorAll('*').length / 50);
    if (!best || score > best.score) best = { p, els, score };
  }
  if (!best) return null;
  const list = best.els.filter((e, i, a) => a.findIndex((x) => numOf(x) === numOf(e)) === i).sort((a, b) => numOf(a) - numOf(b));
  window.__coeNav = list;
  return { n: list.length, labels: list.map((e) => norm(e.innerText || e.getAttribute('aria-label') || '')), at: list.findIndex(sel) };
}
/** Is this bit of the question on the screen yet? Used to wait for a slow page to show the next question. Only looks. */
function coeHasText(snip) { const norm = (s) => String(s || '').toLowerCase().replace(/\s+/g, ' ').trim(); try { return norm(document.body.innerText).includes(norm(snip)); } catch (e) { return true; } }
/** Presses numbered button i (a plain move to that question, nothing is answered) and waits until the page stops changing. */
async function coeNavGo(i) {
  const el = (window.__coeNav || [])[i]; if (!el || !el.isConnected) return { ok: false };
  let busy = 0, last = Date.now(); const mo = new MutationObserver(() => { busy++; last = Date.now(); });
  mo.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true });
  el.click();
  const t0 = Date.now();
  while (Date.now() - t0 < 2200) { await new Promise((r) => setTimeout(r, 90)); if (busy && Date.now() - last > 320) break; if (!busy && Date.now() - t0 > 700) break; }
  mo.disconnect();
  return { ok: true, changed: busy > 0 };
}
/** Where a picture or a question sits in the window (it scrolls there first), so the sidebar can take a picture of just that spot. */
async function coeImgRect(qi, ii) {
  const q = (window.__coeQ || [])[qi]; if (!q) return null;
  const el = ii < 0 ? q.box : (q.imgEls || [])[ii]; if (!el || !el.isConnected) return null;
  const sx = scrollX, sy = scrollY; let r = el.getBoundingClientRect();
  if (r.top < 0 || r.bottom > innerHeight || r.left < 0 || r.right > innerWidth) { el.scrollIntoView({ block: 'center', inline: 'center' }); await new Promise((ok) => setTimeout(ok, 220)); r = el.getBoundingClientRect(); }
  const x = Math.max(0, r.left), y = Math.max(0, r.top), w = Math.min(innerWidth, r.right) - x, h = Math.min(innerHeight, r.bottom) - y;
  return { x, y, w, h, vw: innerWidth, vh: innerHeight, sx, sy };
}
function coeScrollBack(sx, sy) { try { scrollTo(sx, sy); } catch (e) { /* none */ } return true; }

/**
 * Google Forms and Microsoft Forms are used for tests and homework, and also for ordinary things like sign-ups, RSVPs and surveys. This tells them apart.
 * A form is school work if it shows points, is named like a test or homework, or asks subject questions. If the form has not loaded yet, or Coe cannot tell, it says school.
 * It also leaves the check on the page (window.__coeFormKind), so coeFillAnswer and coePressSubmit ask the page itself, fresh, every time they run.
 */
function coeFormKind() {
  const check = () => {
    const host = location.hostname, path = location.pathname;
    if (!(/forms\.(gle|office|microsoft)/i.test(host) || (/(^|\.)google\.com$/i.test(host) && /^\/forms\//.test(path)))) return { form: false, school: false, why: '', wait: false };
    const body = String((document.body && document.body.innerText) || ''), head = document.title + ' ' + body.slice(0, 400);
    const subj = body.split('\n').map((s) => s.trim()).filter((s) => /^(\d+[.)]\s*)?(calculate|solve|explain|describe|define|state|which of the following|work out|simplify|factorise|expand|evaluate|name the|identify|what is the (value|formula|name|function|equation|symbol)|how many marks|give (one|two|three|a) (reason|example))\b/i.test(s)).length;
    const loading = body.length < 60;
    const why = loading ? 'the form has not loaded yet' : /\b\d+(\.\d+)?\s*points?\b/i.test(body) ? 'it shows points' : /\b(quiz|test|exam|assessment|homework|revision|worksheet|assignment|mock|retrieval|knowledge check|exit ticket|cover work)\b/i.test(head) ? 'it is named like school work' : subj >= 2 ? 'its questions are subject questions' : '';
    return { form: true, school: !!why, why, wait: loading };
  };
  window.__coeFormKind = check;
  return check();
}

/**
 * Presses Submit on an ordinary Google or Microsoft form. It runs only when the person said yes in the panel, and the page itself checks again that the form is not school work.
 * Two steps: press=false finds the button and scrolls to it (the cursor then goes there); press=true presses it, unless Stop or Esc came first.
 */
async function coePressSubmit(press) {
  const fk = typeof window.__coeFormKind === 'function' ? window.__coeFormKind() : null;
  if (!fk || !fk.form) return { ok: false, why: 'Coe only presses Submit on ordinary forms.' };
  if (fk.school) return { ok: false, why: 'This form looks like school work (' + fk.why + '), so Coe will not submit it. You press Submit yourself.' };
  const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim();
  const vis = (el) => { try { const r = el.getBoundingClientRect(), cs = getComputedStyle(el); return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none'; } catch (e) { return false; } };
  const label = (b) => norm(b.innerText || b.value || b.getAttribute('aria-label') || b.textContent);
  const all = [...document.querySelectorAll('button,[role=button],input[type=submit]')].filter(vis);
  const sub = all.find((b) => /^(submit|send)$/i.test(label(b)));
  if (!sub) { const nx = all.find((b) => /^next$/i.test(label(b))); return { ok: false, why: nx ? 'There is another page first. Fill it in, then press Submit for me again.' : 'Coe could not find the Submit button.' }; }
  if (!press) { window.__coeAim = sub; sub.scrollIntoView({ block: 'center' }); await new Promise((ok) => setTimeout(ok, 300)); return { ok: true }; }
  const c = window.__coeCur; if (c && c.stop) return { ok: false, why: 'Stopped. Nothing was sent.' };
  sub.click();
  await new Promise((ok) => setTimeout(ok, 1800));
  const t = String((document.body && document.body.innerText) || '');
  return { ok: true, sent: /response (has been|was) recorded|thanks for (submitting|your response)|form (has been )?submitted/i.test(t) };
}

/** Puts an answer into the box or option that coeFindQuestions found. Never on school-work sites. Returns what was there before, so it can be undone. */
async function coeFillAnswer(id, answer, undo, human) {
  if (/sparx|baamboozle|educaplay|bedrock|carousel|doddle|languagenut|memrise|pixl\.org|seneca|smart-?revise|go-?code|blooket|kahoot|gimkit|quizizz|wayground|edpuzzle|educake|hegarty|tassomai|century\.tech|mathswatch|drfrost|kerboodle|socrative|nearpod|classroom\.google|instructure|ixl\.com|khanacademy|mathletics|gcsepod|educationperfect|activelearn|showmyhomework|satchelone|kognity|mymaths|sumdog|ttrockstars|numbots|oxfordowl|cambridgeone|collinsconnect|renlearn|schoology|blackboard|brightspace|d2l\.com|turnitin|edmodo|mentimeter|menti\.com|pollev|wordwall|quizalize|gamestolearn|peardeck|joinpd|slido/i.test(location.hostname) || /\/mod\/quiz/i.test(location.pathname)) return { ok: false, why: 'Coe does not type into homework or quiz pages.' };
  // Google Forms and Microsoft Forms are used for tests and also for ordinary things (sign-ups, RSVPs, surveys). Only a form that looks like school work is blocked.
  // The check (coeFormKind) keeps itself on the page as window.__coeFormKind. If it has not run here, or cannot tell, the form counts as school work.
  if (/forms\.(gle|office|microsoft)/i.test(location.hostname) || (/(^|\.)google\.com$/i.test(location.hostname) && /^\/forms\//.test(location.pathname))) {
    const fk = typeof window.__coeFormKind === 'function' ? window.__coeFormKind() : { school: true, why: 'Coe has not checked this form yet' };
    if (fk.school) return { ok: false, why: 'Coe does not type into school work, and this form looks like it (' + fk.why + '). It shows the answer and you type it in.' };
  }
  const q = (window.__coeQ || [])[Number(id)];
  if (!q || !q.els.length) return { ok: false, why: 'That box is gone. Find the questions again.' };
  const halted = () => { const c = window.__coeCur; return !undo && !!(c && c.stop); };   // Stop or Esc was pressed: do nothing more
  if (halted()) return { ok: false, why: 'Stopped.' };
  const norm = (s) => String(s || '').toLowerCase().replace(/\s+/g, ' ').trim();
  const fire = (el) => { el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); };
  const labelOf = (el) => { let t = ''; if (el.labels && el.labels[0]) t = el.labels[0].innerText; if (!t) t = el.getAttribute('aria-label') || el.getAttribute('data-value') || ''; if (!t && el.closest('label')) t = el.closest('label').innerText; if (!t && el.nextSibling) t = el.nextSibling.textContent || ''; if (!t && el.getAttribute('role')) t = el.innerText || ''; return norm(t); };
  const checked = (el) => el.getAttribute('aria-checked') === 'true' || el.checked === true;
  try {
    const first = q.els[0];
    if (q.kind === 'text' || q.kind === 'long') {
      const v = Array.isArray(answer) ? answer.join(' ') : String(answer == null ? '' : answer), before = undo ? '' : String(first.value != null ? first.value : first.innerText || '');
      const rich = first.isContentEditable || first.getAttribute('role') === 'textbox';
      const setVal = (t) => { const proto = first.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype; Object.getOwnPropertyDescriptor(proto, 'value').set.call(first, t); };
      let calm = false; try { calm = matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { /* none */ }
      if (human && !undo && !calm && v.length) {
        // Typed like a person: quick bursts of letters, small gaps between words, a longer stop after a comma or full stop, and now and then a slip on a neighbouring key that it notices and fixes.
        // The Coe cursor stays on the page the whole time. Escape (or Stop in the panel) puts the box back as it was.
        const C = window.__coeCur, wait = (ms) => new Promise((r) => setTimeout(r, ms));
        const rnd = (a, b) => a + Math.random() * (b - a);
        const scale = Math.min(1, 2600 / Math.max(1, v.length * 40));   // a long answer speeds up, so it never takes much more than two and a half seconds
        const step = v.length > 160 ? Math.ceil(v.length / 120) : 1;      // very long answers go in a few letters at a time, so the page is never slowed down
        const NEAR = { q: 'wa', w: 'qes', e: 'wrd', r: 'etf', t: 'ryg', y: 'tuh', u: 'yij', i: 'uok', o: 'ipl', p: 'ol', a: 'qsz', s: 'awdx', d: 'sefc', f: 'drgv', g: 'fthb', h: 'gyjn', j: 'hukm', k: 'jil', l: 'ko', z: 'asx', x: 'zsc', c: 'xdv', v: 'cfb', b: 'vgn', n: 'bhm', m: 'nj' };
        let cur = '';
        const put = () => { try { setVal(cur); first.setSelectionRange(cur.length, cur.length); } catch (e) { /* not a text box */ } };
        const typeCh = (ch) => { cur += ch; if (rich) document.execCommand('insertText', false, ch); else { put(); first.dispatchEvent(new InputEvent('input', { bubbles: true, data: ch, inputType: 'insertText' })); } };
        const back = () => { cur = cur.slice(0, -1); if (rich) document.execCommand('delete', false); else { put(); first.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward' })); } };
        const restore = async () => {   // Stopped: the typed text is highlighted for a moment, then deleted, then what was there before comes back
          if (C && C.msg) C.msg.textContent = 'Taking it back';
          try { first.focus(); } catch (e) { /* none */ }
          if (cur.length) {
            if (rich) document.execCommand('selectAll', false); else { try { first.setSelectionRange(0, cur.length); } catch (e) { /* not a text box */ } }
            await wait(rnd(420, 560));
            if (rich) document.execCommand('delete', false); else { cur = ''; setVal(''); first.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward' })); }
            await wait(rnd(120, 200));
          }
          if (before) { if (rich) document.execCommand('insertText', false, before); else { setVal(before); fire(first); } }
          else if (!rich) fire(first);
        };
        // the hand rests on the mouse and drifts a little while the other hand types
        const drift = () => { if (!C || !C.cur || !C.cur.isConnected) return; const nx = Math.max(8, Math.min(innerWidth - 40, C.x + rnd(-7, 7))), ny = Math.max(8, Math.min(innerHeight - 40, C.y + rnd(-5, 5))); C.cur.classList.remove('snap'); C.cur.style.transitionDuration = Math.round(rnd(300, 480)) + 'ms'; C.cur.style.transform = 'translate(' + nx + 'px,' + ny + 'px)'; C.x = nx; C.y = ny; };
        try { first.scrollIntoView({ block: 'center', inline: 'nearest' }); } catch (e) { /* none */ }
        first.focus();
        if (rich) { document.execCommand('selectAll', false); document.execCommand('delete', false); } else { setVal(''); fire(first); }
        if (C && C.msg) C.msg.textContent = 'Typing';
        await wait(rnd(70, 160));
        let burst = Math.round(rnd(4, 9)), slips = 0, sinceDrift = 0;
        const maxSlips = step > 1 ? 0 : v.length > 60 ? 2 : v.length > 18 ? 1 : 0;
        for (let i = 0; i < v.length; i += step) {
          if (C && C.stop) { await restore(); return { ok: false, why: 'Stopped.' }; }
          const chunk = v.slice(i, i + step), ch = chunk[chunk.length - 1], low = ch.toLowerCase();
          if (slips < maxSlips && i > 4 && i < v.length - 4 && NEAR[low] && /[a-z]/i.test(ch) && Math.random() < 0.04) {
            // a slip on a neighbouring key, noticed a moment later and fixed
            slips++;
            const w0 = NEAR[low][Math.floor(Math.random() * NEAR[low].length)], wrong = ch === low ? w0 : w0.toUpperCase();
            const more = Math.random() < 0.5 ? 0 : (/^[a-z]{2}$/i.test(v.slice(i + 1, i + 3)) ? 2 : 0);
            typeCh(wrong); await wait(rnd(20, 45) * scale);
            for (let k = 1; k <= more; k++) { typeCh(v[i + k]); await wait(rnd(20, 45) * scale); }
            await wait(rnd(120, 240));                                  // the "oh" beat
            for (let k = 0; k < 1 + more; k++) { back(); await wait(rnd(30, 60)); }
            await wait(rnd(40, 90));
          }
          typeCh(chunk);
          let d = rnd(12, 32);                                          // the usual gap between letters
          if (burst-- <= 0) { burst = Math.round(rnd(4, 9)); d += rnd(25, 80); }   // a tiny gap between bursts
          if (ch === ' ') { d += rnd(8, 30); if (Math.random() < 0.03) d += rnd(150, 350); }   // a bit longer between words, and now and then a think
          else if (ch !== low) d += rnd(10, 30);                        // the shift key
          if (/[,;:]/.test(ch)) d += rnd(60, 120);
          if (/[.!?]/.test(ch)) d += rnd(110, 220);
          if (++sinceDrift > rnd(10, 22)) { sinceDrift = 0; drift(); }
          await wait(d * scale);
        }
        if (C && C.cur) C.cur.style.transitionDuration = '';
        if (!rich) first.dispatchEvent(new Event('change', { bubbles: true }));
        await wait(rnd(80, 160));
        return { ok: true, before };
      }
      if (halted()) return { ok: false, why: 'Stopped.' };
      if (rich) { first.focus(); document.execCommand('selectAll', false); document.execCommand('insertText', false, v); }
      else { setVal(v); fire(first); }
      return { ok: true, before };
    }
    if (q.kind === 'select') {
      const want = norm(Array.isArray(answer) ? answer[0] : answer), sel = first, before = sel.selectedOptions[0] ? sel.selectedOptions[0].text : '';
      const o = [...sel.options].find((x) => norm(x.text) === want) || [...sel.options].find((x) => norm(x.text).includes(want) || (want && want.includes(norm(x.text)) && norm(x.text).length > 1));
      if (!o) return { ok: false, why: 'That option is not in the list.' };
      if (halted()) return { ok: false, why: 'Stopped.' };
      sel.value = o.value; fire(sel); return { ok: true, before };
    }
    // one choice or many: match the wanted option names to the options on the page
    const wants = (Array.isArray(answer) ? answer : String(answer == null ? '' : answer).split(/\s*(?:;|\n| \| )\s*/)).map(norm).filter(Boolean);
    const labels = q.els.map(labelOf), hit = [];
    for (const w of wants) {
      let i = labels.findIndex((l) => l === w);
      if (i < 0) i = labels.findIndex((l) => l.replace(/^\(?[a-d][.)]\s+/, '') === w.replace(/^\(?[a-d][.)]\s+/, ''));
      if (i < 0) i = labels.findIndex((l) => l && (l.includes(w) || w.includes(l)) && Math.min(l.length, w.length) > 1);
      if (i >= 0 && !hit.includes(i)) hit.push(i);
    }
    const before = q.els.map((e, i) => (checked(e) ? labels[i] : '')).filter(Boolean).join('; ');
    if (undo) {   // put the ticks back as they were (an empty list means nothing was ticked)
      for (let i = 0; i < q.els.length; i++) if (q.kind === 'many' && checked(q.els[i]) !== hit.includes(i)) q.els[i].click();
      if (q.kind === 'one' && hit.length && !checked(q.els[hit[0]])) q.els[hit[0]].click();
      return { ok: true, before };
    }
    if (!hit.length) return { ok: false, why: 'Could not match that answer to an option on the page.' };
    if (halted()) return { ok: false, why: 'Stopped.' };
    for (const i of q.kind === 'one' ? hit.slice(0, 1) : hit) if (!checked(q.els[i])) q.els[i].click();
    return { ok: true, before };
  } catch (e) { return { ok: false, why: 'The page stopped that.' }; }
}

/**
 * Works out what kind of page this is and what on it is not a question, so the answers are about the right thing.
 * It only looks. Kinds: homework (a teacher-set site), game (a live quiz game), quiz (a test or form), code, doc, article, shop, video, mail, search, page.
 */
function coeKnowPage() {
  const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim();
  const vis = (el) => { try { const r = el.getBoundingClientRect(), cs = getComputedStyle(el); return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none'; } catch (e) { return false; } };
  const host = location.hostname.replace(/^www\./, ''), path = location.pathname;
  const SITES = [
    [/blooket|kahoot|gimkit|quizizz|wayground|baamboozle|quizlet\.com\/live|educaplay|socrative|mentimeter|menti\.com|pollev|wordwall|quizalize|gamestolearn|peardeck|joinpd|slido/i, 'game'],
    [/sparx|seneca|smart-?revise|go-?code|edpuzzle|educake|hegarty|tassomai|century\.tech|mathswatch|drfrost|kerboodle|doddle|nearpod|memrise|languagenut|bedrock|carousel|pixl|ixl\.com|khanacademy|mathletics|gcsepod|educationperfect|activelearn|showmyhomework|satchelone|kognity|mymaths|sumdog|ttrockstars|numbots|oxfordowl|cambridgeone|collinsconnect|renlearn|schoology|blackboard|brightspace|d2l\.com|turnitin|edmodo/i, 'homework'],
    [/forms\.(gle|office|microsoft)|instructure|classroom\.google/i, 'quiz'],
  ];
  let kind = '', label = host;
  for (const [re, k] of SITES) if (re.test(host + path)) { kind = k; break; }
  if (!kind && /docs\.google\.com/.test(host)) kind = /^\/forms\//.test(path) ? 'quiz' : /^\/(document|presentation|spreadsheets)\//.test(path) ? 'doc' : '';
  if (!kind && /\/mod\/quiz\//.test(path)) kind = 'quiz';
  const q = (s) => document.querySelector(s);
  const controls = [...document.querySelectorAll('input:not([type=hidden]):not([type=search]):not([type=submit]):not([type=button]),textarea,select,[role=radio],[role=checkbox]')].filter(vis).length;
  const body = (document.body && document.body.innerText) || '';
  if (!kind) {
    if (q('.monaco-editor,.cm-editor,.CodeMirror,.ace_editor')) kind = 'code';
    else if (/mail\.google|outlook\.(live|office)|mail\.yahoo/.test(host)) kind = 'mail';
    else if (/youtube\.com|vimeo|netflix|twitch|disneyplus|primevideo/.test(host)) kind = 'video';
    else if (/(^|\.)google\.[a-z.]+$/.test(host) && /^\/search/.test(path) || /bing\.com|duckduckgo|search\.brave/.test(host)) kind = 'search';
    else if (/£\s?\d|\$\s?\d/.test(body) && /(add to (basket|cart|bag)|buy now|checkout)/i.test(body)) kind = 'shop';
    else if (controls >= 2 && /(question|quiz|test|exam|worksheet)/i.test(document.title + ' ' + body.slice(0, 600))) kind = 'quiz';
    else if (q('article') || body.length > 2500) kind = 'article';
  }
  // what is not a question: counters, buttons, timers and scores that sit next to the real question
  const furniture = [];
  const prog = (() => { const m = /\b(?:question|q|step)\s*(\d{1,3})\s*(?:\/|of|out of)\s*(\d{1,3})\b/i.exec(body) || /\b(\d{1,3})\s*\/\s*(\d{1,3})\b/.exec(body.slice(0, 400)); return m ? { at: Number(m[1]), of: Number(m[2]) } : null; })();
  if (prog) furniture.push('the counter "Question ' + prog.at + ' of ' + prog.of + '"');
  for (const [re, name] of [[/\b(skip|next question|submit|check answer|continue|hint)\b/i, 'the buttons (skip, next, submit, hint)'], [/\b\d{1,2}:\d{2}\b/, 'a timer'], [/\b(score|points|streak|coins|xp|leaderboard)\b/i, 'the score and points'], [/cookie|accept all/i, 'a cookie banner']]) if (re.test(body.slice(0, 3000))) furniture.push(name);
  const h1 = norm((q('h1') && q('h1').innerText) || '').slice(0, 120);
  const sub = (() => { const t = norm(document.title); return t.length > 80 ? t.slice(0, 80) : t; })();
  const instr = (() => { const m = /(?:^|\n)\s*((?:choose|select|pick|circle|tick|write|complete|work out|calculate|find|give|explain|match|order|drag)[^\n]{6,140})/i.exec(body); return m ? norm(m[1]) : ''; })();
  const bm = /\b(AQA|Edexcel|Pearson|OCR|WJEC|Eduqas|CCEA|SQA|Cambridge International|IGCSE|IB Diploma)\b/.exec(document.title + ' ' + body.slice(0, 4000));
  return { kind: kind || 'page', host, title: sub, heading: h1, progress: prog, furniture, instruction: instr, board: bm ? bm[1] : '', controls, letters: body.length };
}

/**
 * The Coe cursor: a small cursor with the word "Coe" that shows what Coe is doing while it puts answers in, so nobody is surprised.
 * One function, several commands: show, say (the little note at the bottom), to (move to a question's box or option), click, state (was it stopped?), stop, hide.
 * It lives in its own shadow box, so the page cannot change how it looks, and it never takes a click from the page.
 */
async function coeCursor(cmd, a) {
  const W = window, wait = (ms) => new Promise((r) => setTimeout(r, ms));
  const calm = () => { try { return matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; } };
  let C = W.__coeCur;
  const build = () => {
    const host = document.createElement('div'); host.id = 'coe-cursor-host'; host.setAttribute('aria-hidden', 'true');
    host.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none;';
    const root = host.attachShadow({ mode: 'open' });
    root.innerHTML = '<style>' +
      ':host{all:initial}*{box-sizing:border-box;font-family:"PMC Header","Arial Narrow",Impact,sans-serif}' +
      '.cur{position:fixed;left:0;top:0;width:0;height:0;transition:transform .72s cubic-bezier(.22,.8,.24,1);will-change:transform;opacity:0}' +
      '.cur.on{opacity:1}.cur.snap{transition:none}' +
      '.arrow{position:absolute;left:-3px;top:-3px;width:26px;height:30px;filter:drop-shadow(2px 3px 0 rgba(23,23,23,.55));transform-origin:3px 3px;transition:transform .12s}' +
      '.cur.press .arrow{transform:scale(.82) rotate(-6deg)}' +
      '.tag{position:absolute;left:20px;top:22px;display:flex;align-items:center;padding:3px 9px 2px;background:#B49A57;color:#171717;border:3px solid #171717;box-shadow:3px 3px 0 #171717;font-size:15px;letter-spacing:.05em;text-transform:uppercase;line-height:1.1;white-space:nowrap}' +
      '.tag .logo{width:17px;height:17px;flex:none;margin:-2px 0 -1px}.tag .msg{font-size:14px;letter-spacing:.04em}.tag .msg:not(:empty){margin-left:8px;padding-left:8px;border-left:2px solid #171717}' +
      '.cur.fl .tag{left:auto;right:6px}.cur.fu .tag{top:auto;bottom:10px}' +
      '.ring{position:fixed;width:14px;height:14px;margin:-7px 0 0 -7px;border:3px solid #B49A57;border-radius:50%;opacity:0;pointer-events:none}' +
      '.ring.go{animation:ring .6s ease-out}@keyframes ring{0%{opacity:1;transform:scale(.6)}100%{opacity:0;transform:scale(4.2)}}' +
      '.st{position:fixed;width:12px;height:12px;margin:-6px 0 0 -6px;pointer-events:none;opacity:0;background:#B49A57;clip-path:polygon(50% 0,62% 38%,100% 50%,62% 62%,50% 100%,38% 62%,0 50%,38% 38%)}' +
      '.st.go{animation:st .75s ease-out forwards}@keyframes st{0%{opacity:1;transform:translate(0,0) rotate(0) scale(1)}100%{opacity:0;transform:translate(var(--dx),var(--dy)) rotate(160deg) scale(.3)}}' +
      '.tr{position:fixed;width:9px;height:9px;margin:-4px 0 0 -4px;pointer-events:none;opacity:.8;background:#1A4934;clip-path:polygon(50% 0,62% 38%,100% 50%,62% 62%,50% 100%,38% 62%,0 50%,38% 38%);animation:tr .6s ease-out forwards}@keyframes tr{to{opacity:0;transform:scale(.2) rotate(90deg)}}' +
      '.box{position:fixed;border:3px solid #B49A57;background:rgba(180,154,87,.16);box-shadow:3px 3px 0 #171717;pointer-events:none;opacity:0;transition:opacity .2s}.box.on{opacity:1}' +
      '@media (prefers-reduced-motion:reduce){.cur{transition:none}.tr,.st.go,.ring.go{animation:none}}' +
      '</style>' +
      '<div class="box"></div><div class="cur"><svg class="arrow" viewBox="0 0 26 30"><path d="M3 3l0 22 6-5.5 4.500 9.500 4-2-4.500-9L22 17.500z" fill="#1A4934" stroke="#F2E4CE" stroke-width="2.200" stroke-linejoin="round"/></svg><div class="tag"><svg class="logo" viewBox="406 8 780 780" aria-label="Coe"><path fill="#171717" fill-rule="evenodd" clip-rule="evenodd" d="M786.886 22.9033C790.107 14.1976 802.421 14.1978 805.643 22.9033L825.213 75.79C875.855 212.649 983.761 320.556 1120.62 371.198L1173.51 390.768C1182.21 393.989 1182.21 406.304 1173.51 409.525L1120.62 429.095C983.761 479.737 875.855 587.643 825.213 724.503L805.643 777.39C802.421 786.095 790.107 786.095 786.886 777.39L767.316 724.503C716.674 587.643 608.768 479.737 471.908 429.095L419.021 409.525C410.316 406.304 410.316 393.989 419.021 390.768L471.908 371.198C608.768 320.556 716.674 212.65 767.316 75.79L786.886 22.9033ZM796.265 272.595C726.494 272.595 669.934 329.155 669.934 398.926C669.934 468.696 726.494 525.257 796.265 525.257C866.035 525.257 922.595 468.696 922.596 398.926C922.596 329.155 866.035 272.595 796.265 272.595Z"/></svg><span class="msg"></span></div></div>';
    try {
      if (!W.__coeFont && chrome && chrome.runtime && chrome.runtime.getURL) {
        W.__coeFont = true; const f = new FontFace('PMC Header', 'url(' + chrome.runtime.getURL('fonts/PMCHeader.woff2') + ')');
        f.load().then(() => document.fonts.add(f)).catch(() => { /* the page may not allow it: the tag then uses a plain font */ });
      }
    } catch (e) { /* plain font */ }
    document.documentElement.appendChild(host);
    const o = { host, root, cur: root.querySelector('.cur'), msg: root.querySelector('.msg'), box: root.querySelector('.box'), x: innerWidth / 2, y: innerHeight / 2, stop: false };
    o.key = (e) => { if (e.key === 'Escape' && o.cur.classList.contains('on') && !o.stop) { o.stop = true; o.msg.textContent = 'Stopping…'; e.preventDefault(); e.stopImmediatePropagation(); } };
    W.addEventListener('keydown', o.key, true);
    return o;
  };
  const edge = (x, y) => { C.cur.classList.toggle('fl', x > innerWidth - 300); C.cur.classList.toggle('fu', y > innerHeight - 80); };   // the label flips so it never runs off the page
  const move = (x, y) => { C.cur.style.transform = 'translate(' + x + 'px,' + y + 'px)'; C.x = x; C.y = y; edge(x, y); };
  const place = (x, y, snap) => { C.cur.classList.toggle('snap', !!snap); C.cur.style.transform = 'translate(' + x + 'px,' + y + 'px)'; C.x = x; C.y = y; edge(x, y); };
  const trail = async (x0, y0, x1, y1, ms) => {
    if (calm()) return;
    const n = Math.max(3, Math.min(10, Math.round(Math.hypot(x1 - x0, y1 - y0) / 90)));
    for (let i = 1; i <= n; i++) { await wait(ms / (n + 1)); const t = i / (n + 1), e = 1 - Math.pow(1 - t, 3), d = document.createElement('i'); d.className = 'tr'; d.style.left = (x0 + (x1 - x0) * e) + 'px'; d.style.top = (y0 + (y1 - y0) * e) + 'px'; C.root.appendChild(d); setTimeout(() => d.remove(), 650); }
  };
  if (cmd === 'show') {
    if (!C || !C.host.isConnected) C = W.__coeCur = build();
    C.stop = false; place(C.x, C.y, true); C.cur.classList.add('on'); C.msg.textContent = (a && a.text) || ''; return { ok: true };
  }
  if (!C) return { ok: false, stop: false };
  if (cmd === 'state') return { ok: true, stop: C.stop };
  if (cmd === 'stop') { C.stop = true; C.idleTok = (C.idleTok || 0) + 1; C.msg.textContent = 'Stopping…'; return { ok: true }; }
  if (cmd === 'say') { if (C.stop && !(a && a.force)) return { ok: true }; C.msg.textContent = (a && a.text) || ''; if (a && a.reset) C.box.classList.remove('on'); return { ok: true }; }
  if (cmd === 'hide') { C.idleTok = (C.idleTok || 0) + 1; clearInterval(C.idle); C.cur.classList.remove('on'); C.box.classList.remove('on'); W.removeEventListener('keydown', C.key, true); setTimeout(() => { try { C.host.remove(); } catch (e) { /* gone */ } if (W.__coeCur === C) W.__coeCur = null; }, 400); return { ok: true }; }
  if (cmd === 'click') {
    if (C.stop) return { ok: false, stopped: true };
    const r = document.createElement('i'); r.className = 'ring'; r.style.left = C.x + 'px'; r.style.top = C.y + 'px'; C.root.appendChild(r);
    C.cur.classList.add('press'); r.classList.add('go');
    if (!calm()) for (let i = 0; i < 6; i++) { const s = document.createElement('i'), ang = (Math.PI * 2 * i) / 6 + 0.4; s.className = 'st'; s.style.left = C.x + 'px'; s.style.top = C.y + 'px'; s.style.setProperty('--dx', Math.round(Math.cos(ang) * 34) + 'px'); s.style.setProperty('--dy', Math.round(Math.sin(ang) * 34) + 'px'); C.root.appendChild(s); s.classList.add('go'); setTimeout(() => s.remove(), 800); }
    await wait(160); C.cur.classList.remove('press'); await wait(200); r.remove(); return { ok: true };
  }
  if (cmd === 'idle') {
    // Still waiting: it drifts about slowly, like a person who is not sure what to do next. Long smooth glides (they speed up and slow down gently),
    // a rest between them with a tiny sway of the hand, and it stays around where it was instead of wandering off.
    C.idleTok = (C.idleTok || 0) + 1; const tok = C.idleTok; clearInterval(C.idle); C.idle = 0;
    if (!(a && a.on)) { C.cur.style.transitionDuration = ''; return { ok: true }; }
    C.msg.textContent = (a && a.text) || 'Still going…';
    if (calm()) return { ok: true };
    const rnd = (m, n) => m + Math.random() * (n - m), ease = (t) => t * t * t * (t * (6 * t - 15) + 10);   // the smoothest possible start and stop
    const frame = () => new Promise((r) => { let d = false; const f = () => { if (!d) { d = true; r(); } }; requestAnimationFrame(f); setTimeout(f, 60); });
    const live = () => C.idleTok === tok && C.cur.isConnected && !C.stop;
    const ax = C.x, ay = C.y;
    C.cur.classList.add('snap'); C.cur.style.transitionDuration = '';
    (async () => {
      let k = 0;
      while (live()) {
        const r0 = performance.now(), rest = rnd(450, 1200), bx = C.x, by = C.y, ph = rnd(0, 6);
        while (live() && performance.now() - r0 < rest) { const t = (performance.now() - r0) / 1000 + ph; move(bx + Math.sin(t * 1.6) * 1.1, by + Math.cos(t * 1.1) * 0.9); await frame(); }
        if (!live()) break;
        k++; const ang = rnd(0, Math.PI * 2), rad = k % 4 === 0 ? rnd(90, 150) : rnd(35, 90);
        const tx = Math.max(10, Math.min(innerWidth - 40, ax + Math.cos(ang) * rad)), ty = Math.max(10, Math.min(innerHeight - 40, ay + Math.sin(ang) * rad));
        const x0 = C.x, y0 = C.y, d = Math.hypot(tx - x0, ty - y0) || 1, dur = Math.max(800, Math.min(1700, 600 + d * 7)), side = Math.random() < 0.5 ? -1 : 1, bow = rnd(0.1, 0.22) * side;
        const cx = (x0 + tx) / 2 - ((ty - y0) / d) * d * bow, cy = (y0 + ty) / 2 + ((tx - x0) / d) * d * bow, s0 = performance.now();
        while (live()) { const p = Math.min(1, (performance.now() - s0) / dur), e = ease(p); move((1 - e) * (1 - e) * x0 + 2 * (1 - e) * e * cx + e * e * tx, (1 - e) * (1 - e) * y0 + 2 * (1 - e) * e * cy + e * e * ty); if (p >= 1) break; await frame(); }
      }
    })();
    return { ok: true };
  }
  if (cmd === 'to') {
    C.idleTok = (C.idleTok || 0) + 1; clearInterval(C.idle); C.idle = 0;
    if (C.stop) return { ok: false, stopped: true };
    const aimed = a && a.aim && W.__coeAim && W.__coeAim.isConnected ? W.__coeAim : null, q = aimed ? { kind: 'press', els: [aimed] } : (W.__coeQ || [])[a && a.qi]; if (!q) return { ok: false };
    const lab = (e) => String((e.labels && e.labels[0] && e.labels[0].innerText) || e.getAttribute('aria-label') || (e.closest('label') && e.closest('label').innerText) || e.innerText || (e.parentElement && e.parentElement.innerText) || '').replace(/\s+/g, ' ').trim().toLowerCase();
    let el = q.els[0];
    if (a.opt && (q.kind === 'one' || q.kind === 'many')) {
      const wants = String(a.opt).split('|').map((x) => x.trim().toLowerCase()).filter(Boolean);
      const hit = q.els.find((e) => wants.includes(lab(e))) || q.els.find((e) => wants.some((w) => lab(e).includes(w) || (lab(e) && w.includes(lab(e)))));
      if (hit) el = hit;
    }
    if (!el || !el.isConnected) return { ok: false };
    // a tiny radio circle is clicked through its label, which is the bigger target a person would aim at
    const aim = (q.kind === 'one' || q.kind === 'many') && el.matches && el.matches('input') && el.closest('label') ? el.closest('label') : el;
    let r = aim.getBoundingClientRect();
    if (r.top < 40 || r.bottom > innerHeight - 70) { aim.scrollIntoView({ block: 'center', behavior: calm() ? 'auto' : 'smooth' }); await wait(calm() ? 60 : 520); r = aim.getBoundingClientRect(); }
    // never the dead centre: a person lands somewhere inside the box, a little off
    let fx, fy, g = 0; do { fx = 0.16 + Math.random() * 0.68; fy = 0.24 + Math.random() * 0.52; g++; } while (g < 8 && Math.abs(fx - 0.5) < 0.1 && Math.abs(fy - 0.5) < 0.14);
    const tx = Math.max(8, Math.min(innerWidth - 40, r.left + Math.min(r.width, 280) * fx)), ty = Math.max(8, Math.min(innerHeight - 40, r.top + r.height * fy));
    C.box.style.left = r.left - 4 + 'px'; C.box.style.top = r.top - 4 + 'px'; C.box.style.width = r.width + 8 + 'px'; C.box.style.height = r.height + 8 + 'px'; C.box.classList.add('on');
    const x0 = C.x, y0 = C.y, dist = Math.hypot(tx - x0, ty - y0);
    if (calm() || dist < 4) { place(tx, ty, true); C.x = tx; C.y = ty; return { ok: true }; }
    // a curved, slightly shaky path with its own speed, and now and then it goes a little too far and comes back
    const run = async (xa, ya, xb, yb, ms, bow) => {
      const d = Math.hypot(xb - xa, yb - ya) || 1, nx = -(yb - ya) / d, ny = (xb - xa) / d, side = Math.random() < 0.5 ? -1 : 1;
      const cx = (xa + xb) / 2 + nx * d * bow * side, cy = (ya + yb) / 2 + ny * d * bow * side, t0 = performance.now(); let lastTr = 0, jx = 0, jy = 0;
      C.cur.classList.add('snap');
      for (;;) {
        const p = Math.min(1, (performance.now() - t0) / ms), e = p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2;   // slow start, quick middle, slow arrival
        jx = jx * 0.7 + (Math.random() - 0.5) * 2.2 * (1 - p); jy = jy * 0.7 + (Math.random() - 0.5) * 2.2 * (1 - p);   // the hand is never quite steady
        const px = (1 - e) * (1 - e) * xa + 2 * (1 - e) * e * cx + e * e * xb + jx, py = (1 - e) * (1 - e) * ya + 2 * (1 - e) * e * cy + e * e * yb + jy;
        C.cur.style.transform = 'translate(' + px + 'px,' + py + 'px)'; C.x = px; C.y = py; edge(px, py);
        if (performance.now() - lastTr > 70 && p < 0.95) { lastTr = performance.now(); const i = document.createElement('i'); i.className = 'tr'; i.style.left = px + 'px'; i.style.top = py + 'px'; C.root.appendChild(i); setTimeout(() => i.remove(), 650); }
        if (p >= 1 || C.stop) break; await wait(16);
      }
    };
    // A person reads the question first, then the hand goes. Short trips are quick, long ones take a little longer.
    const rnd = (m, n) => m + Math.random() * (n - m), cx = (v) => Math.max(8, Math.min(innerWidth - 40, v)), cy = (v) => Math.max(8, Math.min(innerHeight - 40, v));
    await wait(rnd(70, 190)); if (C.stop) return { ok: false, stopped: true };
    const total = Math.round(Math.max(300, Math.min(820, 240 + dist * 0.55)) * rnd(0.88, 1.12)), roll = Math.random(), ang = Math.atan2(ty - y0, tx - x0);
    if (roll < 0.34 && dist > 120) {                       // goes a little too far, then comes back
      const over = rnd(8, 22);
      await run(x0, y0, cx(tx + Math.cos(ang) * over), cy(ty + Math.sin(ang) * over), total * 0.82, rnd(0.08, 0.18)); await wait(rnd(40, 100)); await run(C.x, C.y, tx, ty, rnd(130, 220), 0.02);
    } else if (roll < 0.5 && dist > 160) {                 // stops just short, then a small second move
      const k = rnd(0.86, 0.94); await run(x0, y0, x0 + (tx - x0) * k, y0 + (ty - y0) * k, total * 0.8, rnd(0.06, 0.16)); await wait(rnd(50, 130)); await run(C.x, C.y, tx, ty, rnd(120, 200), 0.02);
    } else if (roll < 0.66 && dist > 320) {                // slows down partway, as if looking at something else
      const k = rnd(0.42, 0.62), wx = x0 + (tx - x0) * k, wy = y0 + (ty - y0) * k; await run(x0, y0, wx, wy, total * 0.5, rnd(0.06, 0.14)); await wait(rnd(70, 150)); await run(C.x, C.y, tx, ty, total * 0.58, rnd(0.03, 0.1));
    } else await run(x0, y0, tx, ty, total, rnd(0.06, 0.18));
    if (C.stop) return { ok: false, stopped: true };
    // lining it up: a few tiny nudges, then a short hover before anything happens
    for (let k = 0; k < 2; k++) { const nx = cx(tx + rnd(-3, 3)), ny = cy(ty + rnd(-2.5, 2.5)); C.cur.classList.add('snap'); C.cur.style.transform = 'translate(' + nx + 'px,' + ny + 'px)'; C.x = nx; C.y = ny; await wait(rnd(40, 80)); }
    await wait(rnd(60, 150));
    return { ok: true };
  }
  return { ok: false };
}

/** "Do a job on this page" (Coe Mini only). It looks at the page, then does one step at a time with the Coe cursor.
 *  Never on homework, quiz or school sites. Never types a password, card detail or code. Anything that cannot be undone is asked about first, in the panel (see jobRun). */
async function coeScreen(cmd, a) {
  const W = window, wait = (ms) => new Promise((r) => setTimeout(r, ms));
  const SCHOOL = /sparx|baamboozle|educaplay|bedrock|carousel|doddle|languagenut|memrise|pixl\.org|seneca|smart-?revise|go-?code|blooket|kahoot|gimkit|quizizz|wayground|edpuzzle|educake|hegarty|tassomai|century\.tech|mathswatch|drfrost|kerboodle|socrative|nearpod|classroom\.google|instructure|ixl\.com|khanacademy|mathletics|gcsepod|educationperfect|activelearn|showmyhomework|satchelone|kognity|mymaths|sumdog|ttrockstars|numbots|oxfordowl|cambridgeone|collinsconnect|renlearn|schoology|blackboard|brightspace|d2l\.com|turnitin|edmodo|mentimeter|menti\.com|pollev|wordwall|quizalize|gamestolearn|peardeck|joinpd|slido/i;
  if (SCHOOL.test(location.hostname) || /\/mod\/quiz\//.test(location.pathname)) return { ok: false, school: true, why: 'This is a homework or quiz site. Coe does not do jobs on these.' };
  const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim();
  const vis = (el) => { try { const r = el.getBoundingClientRect(), cs = getComputedStyle(el); return r.width > 1 && r.height > 1 && cs.visibility !== 'hidden' && cs.display !== 'none' && cs.opacity !== '0'; } catch (e) { return false; } };
  const SECRET = /pass(word|code)|passwd|\bcvv\b|\bcvc\b|card.?(number|no\b)|credit|debit|security code|one.?time|\botp\b|2fa|verification code|authenticator|\bssn\b|national insurance|\biban\b|account number|sort code|expir/i;
  const DANGER = /\b(commit|publish|deploy|release|delete|remove|erase|discard|destroy|reset|revoke|send|post|reply|comment|share|submit|pay|buy|purchase|order|checkout|check out|subscribe|donate|transfer|confirm|accept|agree|approve|merge|push|force|upload|invite|public|private|archive|unpublish|sign out|log ?out|sign up|create (an )?account|save|apply|place)\b/i;
  const label = (el) => norm(el.getAttribute('aria-label') || (el.labels && el.labels[0] && el.labels[0].innerText) || (el.tagName === 'INPUT' && /^(submit|button|reset)$/i.test(el.type) ? el.value : '') || el.innerText || el.title || el.placeholder || el.getAttribute('name') || el.textContent || '').slice(0, 80);
  const secret = (el) => el.type === 'password' || /^(cc-|one-time-code|current-password|new-password)/.test(el.autocomplete || '') || SECRET.test([el.name, el.id, el.getAttribute('aria-label'), el.placeholder, el.labels && el.labels[0] && el.labels[0].innerText].join(' '));
  const danger = (el) => { const l = label(el), href = el.tagName === 'A' ? (el.getAttribute('href') || '') : ''; return DANGER.test(l) || (el.tagName === 'INPUT' && el.type === 'submit') || /\/(delete|logout|signout|sign_out|destroy|remove)\b/i.test(href); };
  const kindOf = (el) => {
    const t = el.tagName, ty = (el.type || '').toLowerCase(), r = (el.getAttribute('role') || '').toLowerCase();
    if (t === 'SELECT') return 'select'; if (t === 'TEXTAREA' || el.isContentEditable) return 'text';
    if (t === 'INPUT') return ty === 'file' ? 'file' : /^(checkbox|radio)$/.test(ty) ? 'check' : /^(submit|button|reset|image)$/.test(ty) ? 'button' : 'text';
    if (/^(checkbox|radio|switch)$/.test(r)) return 'check'; if (t === 'A' || r === 'link') return 'link'; return 'button';
  };
  const ids = () => W.__coeIds || [];
  if (cmd === 'look') {
    const sel = 'a[href],button,[role=button],[role=link],[role=menuitem],[role=tab],[role=option],[role=checkbox],[role=radio],[role=switch],input:not([type=hidden]),textarea,select,summary,[contenteditable=true],[contenteditable=""]';
    const all = [...document.querySelectorAll(sel)].filter((el) => !el.closest('#coe-cursor-host') && vis(el));
    const top = all.filter((el) => { const r = el.getBoundingClientRect(); return r.bottom > -150 && r.top < innerHeight + 500; });
    const keep = top.filter((el) => !(el.matches('a[href],button,[role=button],[role=link]') && el.parentElement && el.parentElement.closest('a[href],button,[role=button],[role=link]'))).slice(0, 70);   // a button inside a link counts once
    W.__coeIds = keep;
    const items = keep.map((el, i) => {
      const r = el.getBoundingClientRect(), k = kindOf(el), o = { id: i + 1, kind: k, label: label(el), off: r.bottom < 0 || r.top > innerHeight };
      if (k === 'text' || k === 'select') o.value = norm(el.isContentEditable ? el.innerText : (k === 'select' ? (el.options[el.selectedIndex] || {}).text : el.value)).slice(0, 60);
      if (k === 'check') o.checked = el.checked != null ? !!el.checked : el.getAttribute('aria-checked') === 'true';
      if (k === 'link') { try { const u = new URL(el.href, location.href); o.to = (u.origin === location.origin ? '' : u.hostname) + u.pathname.slice(0, 40); } catch (e) { /* none */ } }
      if (k === 'text' && secret(el)) o.secret = true;
      if (el.disabled || el.getAttribute('aria-disabled') === 'true') o.disabled = true;
      if (k !== 'text' && danger(el)) o.danger = true;
      return o;
    });
    const text = norm((document.body && document.body.innerText) || '').slice(0, 1500);
    return { ok: true, url: location.href, origin: location.origin, title: document.title, items, text, secretBox: !!document.querySelector('input[type=password]') && [...document.querySelectorAll('input[type=password]')].some(vis), scrollY: Math.round(scrollY), scrollMax: Math.max(0, Math.round(document.documentElement.scrollHeight - innerHeight)) };
  }
  if (cmd === 'aim') {
    const el = ids()[(a && a.id || 0) - 1]; if (!el || !el.isConnected) return { ok: false, why: 'The page changed, so Coe looks again.' };
    el.scrollIntoView({ block: 'center' }); await wait(320); W.__coeAim = el; return { ok: true, label: label(el), kind: kindOf(el), danger: danger(el), secret: kindOf(el) === 'text' && secret(el) };
  }
  if (cmd === 'do') {
    const c = W.__coeCur; if (c && c.stop) return { ok: false, stopped: true, why: 'Stopped.' };
    const act = a && a.act;
    if (act === 'scroll') { const d = /up/i.test(a.text || '') ? -1 : 1; scrollBy({ top: d * Math.round(innerHeight * 0.8), behavior: 'smooth' }); await wait(550); return { ok: true }; }
    if (act === 'wait') { await wait(1500); return { ok: true }; }
    const el = ids()[(a && a.id || 0) - 1]; if (!el || !el.isConnected) return { ok: false, why: 'The page changed, so Coe looks again.' };
    const k = kindOf(el);
    if (k === 'file') return { ok: false, why: 'Coe cannot choose files from your computer. You choose them, then press Continue.', needYou: true };
    if (act === 'type') {
      if (k !== 'text') return { ok: false, why: 'That is not a box for typing.' };
      if (secret(el)) return { ok: false, secret: true, needYou: true, why: 'Coe never types passwords, card details or codes. Type that yourself, then press Continue.' };
      const text = String(a.text == null ? '' : a.text).slice(0, 4000), before = el.isContentEditable ? el.innerText : el.value;
      el.focus();
      const set = (v) => { if (el.isContentEditable) { el.textContent = v; } else { const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype, d = Object.getOwnPropertyDescriptor(proto, 'value'); if (d && d.set) d.set.call(el, v); else el.value = v; } el.dispatchEvent(new Event('input', { bubbles: true })); };
      set('');
      if (text.length <= 200) { for (let i = 1; i <= text.length; i++) { if (W.__coeCur && W.__coeCur.stop) { set(before); return { ok: false, stopped: true, why: 'Stopped.' }; } set(text.slice(0, i)); await wait(14 + Math.random() * 30); } } else set(text);
      el.dispatchEvent(new Event('change', { bubbles: true })); return { ok: true, before };
    }
    if (act === 'select') {
      if (k !== 'select') return { ok: false, why: 'That is not a list to pick from.' };
      const want = norm(a.text).toLowerCase(), op = [...el.options].find((o) => norm(o.text).toLowerCase() === want) || [...el.options].find((o) => norm(o.text).toLowerCase().includes(want));
      if (!op) return { ok: false, why: 'That choice is not in the list.' };
      el.value = op.value; el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); return { ok: true };
    }
    if (act === 'click') {
      if (el.disabled || el.getAttribute('aria-disabled') === 'true') return { ok: false, why: 'That button is switched off.' };
      if (el.tagName === 'A') el.removeAttribute('target');   // stay in this tab
      el.click(); await wait(700); return { ok: true, url: location.href };
    }
    return { ok: false, why: 'Coe did not understand that step.' };
  }
  return { ok: false };
}
