// Runs on coe.pmcstudios.uk only. It does these jobs:
// 1. tells Coe Mini where the account lives (public settings) and lets the person connect Coe and Coe Mini with a matching code;
// 2. only while they are connected: shares About you, lets the Coe site read and change Coe Mini's settings (Settings > Coe Mini),
//    and sends back what you did in the sidebar (chats, tokens given back), so the Coe site shows it too;
// 3. delivers "Continue this chat in Coe" from the sidebar into a new Coe chat.
// No sign-in is ever passed between them. Each signs in by itself, to the same account.
(() => {
  const api = typeof browser !== 'undefined' && browser.runtime ? browser : chrome;
  const read = (k) => { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch { return null; } };
  const send = () => {
    try {
      const s = read('pmc:coe:settings') || {};
      const me = { name: String(s.name || '').slice(0, 30), ageBand: s.ageBand || '', role: s.role || '', yearOrJob: String(s.yearOrJob || '').slice(0, 60), subjects: String(s.subjects || '').slice(0, 100), length: s.length || '', easy: !!s.easy, aboutText: String(s.about || '').slice(0, 700), system: String(s.system || '').slice(0, 1500), tone: s.tone || '', level: s.level || '', replyLang: String(s.replyLang || '').slice(0, 30), maxWords: Number(s.maxWords) || 0, goal: Number(s.goal) || 0, at: Number(s.profileAt) || 0 };
      // "Connect Coe Mini": the person looked at the code on the site, saw it match the one in Coe Mini, and pressed Connect.
      const pair = read('pmc:coe:pair'), connect = pair && typeof pair.code === 'string' && Date.now() - Number(pair.at) < 900000 ? pair.code : '';
      const email = String((read('pmc:coe:session') || {}).email || '');   // only the address, to check both are the same account
      const lead = localStorage.getItem('pmc:coe:lead') || 'cream', accent = localStorage.getItem('pmc:coe:accent') || '#337957', lookAt = Number(localStorage.getItem('pmc:coe:look-at')) || 0;
      api.runtime.sendMessage({ type: 'sync', met: !!localStorage.getItem('pmc:coe:met'), ext: read('pmc:coe:ext'), code: s.code || '', serverUrl: s.serverUrl || '', site: location.origin, me, connect, email, look: { lead, accent, at: lookAt } }, (r) => {
        try { void api.runtime.lastError; } catch { /* none */ }
        if (connect) {
          if (r && r.connected) { try { localStorage.removeItem('pmc:coe:pair'); } catch { /* blocked */ } linked = true; post({ type: 'connected', yes: true }); post({ type: 'link', linked: true }); deliver(); }
          else if (r && r.refused) post({ type: 'connected', yes: false, why: r.refused });
        }
        if (r && r.profile && ready && linked) post({ type: 'profile', me: r.profile });
        if (r && r.met && ready && linked) post({ type: 'met' });   // setup was done in Coe Mini, so the website does not ask again
        if (r && r.look && ready && linked) post({ type: 'look', look: r.look });   // Coe Mini has the newer page colour   // the sidebar has newer About you answers than this site
      });
    } catch { /* the extension was reloaded; this page will be refreshed next time */ }
  };
  const prefs = async () => { const o = await api.storage.local.get(['scope', 'speed', 'askTabs', 'askChg']); return { scope: o.scope === 'screen' ? 'screen' : 'page', speed: ['swift', 'core', 'deep'].includes(o.speed) ? o.speed : 'core', askTabs: o.askTabs === 'allow' ? 'allow' : 'ask', askChg: o.askChg === 'allow' ? 'allow' : 'ask' }; };
  const post = (m) => postMessage({ coe: 'from-ext', ...m }, location.origin);
  let ready = false, linked = false;
  try { api.storage.local.get('connected').then((o) => { linked = !!o.connected; }); } catch { /* reloaded */ }
  const deliver = async () => {
    if (!ready) return;
    try {
      const { handoff } = await api.storage.local.get('handoff');
      if (handoff && handoff.text && Date.now() - handoff.ts < 600000) { post({ type: 'handoff', text: String(handoff.text).slice(0, 6000) }); }   // the person pressed "Continue in Coe", so this one always goes
      if (handoff) await api.storage.local.remove('handoff');
      if (!linked) return;
      const { refunds, chats, me } = await api.storage.local.get(['refunds', 'chats', 'me']);   // what the sidebar did: Coe shows it in its history and in Settings > Usage > Refunds
      if (Array.isArray(refunds) && refunds.length) post({ type: 'refunds', items: refunds.slice(0, 50) });
      if (Array.isArray(chats) && chats.length) post({ type: 'chats', items: chats.slice(0, 30) });
      if (me && me.at) { if (Number((read('pmc:coe:settings') || {}).profileAt) > me.at) send(); else post({ type: 'profile', me }); }   // the older copy gets put right, never the newer one
    } catch { /* reloaded */ }
  };
  addEventListener('message', async (e) => {
    const d = e.data;
    if (e.source !== window || !d || d.coe !== 'to-ext') return;
    try {
      if (d.type === 'hello') { ready = true; linked = !!(await api.storage.local.get('connected')).connected; post({ type: 'hello', version: api.runtime.getManifest().version_name || api.runtime.getManifest().version, browser: /Firefox\//.test(navigator.userAgent) ? 'firefox' : 'chrome', linked, prefs: linked ? await prefs() : null }); send(); deliver(); }
      if (d.type === 'unlink') { await api.runtime.sendMessage({ type: 'unlink' }); }
      if (d.type === 'refunds-ack' && Array.isArray(d.ids)) {
        const { refunds } = await api.storage.local.get('refunds');
        await api.storage.local.set({ refunds: (Array.isArray(refunds) ? refunds : []).filter((x) => !d.ids.includes(x.id)) });
      }
      if (d.type === 'set' && d.prefs && linked) {
        const p = d.prefs, o = {};
        if (p.scope === 'page' || p.scope === 'screen') o.scope = p.scope;
        if (['swift', 'core', 'deep'].includes(p.speed)) o.speed = p.speed;
        if (p.askTabs === 'ask' || p.askTabs === 'allow') o.askTabs = p.askTabs;
        if (p.askChg === 'ask' || p.askChg === 'allow') o.askChg = p.askChg;
        await api.storage.local.set(o); post({ type: 'prefs', prefs: await prefs() });
      }
    } catch { /* the extension was reloaded */ }
  });
  try { api.storage.onChanged.addListener((c) => { if (c.look && linked && ready && c.look.newValue) post({ type: 'look', look: { lead: c.look.newValue.lead, accent: c.look.newValue.accent, at: c.look.newValue.at } }); }); } catch { /* the extension was reloaded */ }
  try { api.storage.onChanged.addListener((c) => { if (c.connected) { linked = !!c.connected.newValue; if (ready) { post({ type: 'link', linked }); if (linked) deliver(); } } if (linked && (c.scope || c.speed || c.askTabs || c.askChg)) prefs().then((p) => ready && post({ type: 'prefs', prefs: p })); if (c.handoff || (linked && (c.refunds || c.chats || c.me))) deliver(); }); } catch { /* reloaded */ }
  send(); setTimeout(send, 2500); setTimeout(send, 7000);
  setInterval(send, 60000);
  addEventListener('storage', send);
  addEventListener('pmc:coe-pair', () => { send(); setTimeout(send, 700); });   // Connect was pressed on this page
  let sendT = 0; addEventListener('pmc:coe-settings', () => { clearTimeout(sendT); sendT = setTimeout(send, 400); });   // changed on this page: pass it on at once
  document.addEventListener('visibilitychange', () => { if (!document.hidden) send(); });
})();
