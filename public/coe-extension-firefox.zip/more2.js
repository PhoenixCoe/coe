// Coe Mini: Settings, the way Coe has them (Account, Usage, Memory, Chat, Learn, Look, Coe Mini, Data, About),
// plus what follows the account: memory, working styles and study cards. Lists and wording come from shared.js,
// which is made from the Coe website itself.
(() => {
  'use strict';
  const CX = window.CX; if (!CX) return;
  const SH = window.COE_SHARED || {};

  function start() {
    const { S, $, el, esc, bg, store, openDlg, closeDlg } = CX;
    const say = (t) => (CX.say ? CX.say(t) : void 0);
    const IC = (n, sz) => '<svg class="ico" viewBox="0 0 24 24" aria-hidden="true" width="' + (sz || 18) + '" height="' + (sz || 18) + '"><path d="' + ((SH.ICONS || {})[n] || '') + '"/></svg>';
    CX.IC = IC;
    const clamp = (n, a, b) => Math.max(a, Math.min(b, n));

    // ------------------------------------------------------------ how it looks and sounds (the same options, names and colours as Coe)
    const DEF_ACCENT = '#337957';
    const DEF = { lead: 'cream', accent: DEF_ACCENT, scale: 100, motion: 'full', density: 'normal', contrast: false, sfx: false, enter: 'send' };
    let L = { ...DEF };
    const rgb = (h) => { const m = /^#?([0-9a-f]{6})$/i.exec(String(h).trim()); const n = parseInt(m ? m[1] : '337957', 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
    const hex = (c) => '#' + c.map((v) => Math.round(clamp(v, 0, 255)).toString(16).padStart(2, '0')).join('');
    const mix = (a, b, t) => { const x = rgb(a), y = rgb(b); return hex(x.map((v, i) => v + (y[i] - v) * t)); };
    const lum = (h) => { const [r, g, b] = rgb(h).map((v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
    /** White words must stay readable on the accent, so a colour that is too light is darkened until it is. */
    const fitAccent = (h) => { let c = /^#?[0-9a-f]{6}$/i.test(String(h).trim()) ? '#' + String(h).trim().replace('#', '').toLowerCase() : DEF_ACCENT; for (let i = 0; i < 12 && 1.05 / (lum(c) + 0.05) < 4.5; i++) c = mix(c, '#000000', 0.1); return c; };
    const BASE = {
      cream: {},
      ink: { paper: '#141414', cream: '#242424', ink: '#F2E4CE', tint: '#1E3A2D', g1: '#4FA57C', g2: '#337957', g3: '#9BD3B0', bad: '#E58B7A' },
      gold: { paper: '#B49A57', cream: '#E4D1A1', ink: '#171717', tint: '#F2E4CE', g1: '#1A4934', g2: '#171717', g3: '#133125', bad: '#8F2A1D' },
      green: { paper: '#1A4934', cream: '#133125', ink: '#F2E4CE', tint: '#245C43', g1: '#7FC79C', g2: '#0B1F16', g3: '#9BD3B0', bad: '#E58B7A' },
    };
    function palette() {
      const a = fitAccent(L.accent), v = { ...(BASE[L.lead] || {}) };
      if (a !== DEF_ACCENT) {
        const dk = mix(a, '#000000', 0.42), lt = mix(a, '#ffffff', 0.42);
        if (L.lead === 'ink') Object.assign(v, { g1: mix(a, '#ffffff', 0.3), g2: a, g3: mix(a, '#ffffff', 0.55), tint: mix(a, '#141414', 0.7) });
        else if (L.lead === 'gold') Object.assign(v, { g1: dk, g3: mix(dk, '#000000', 0.4) });
        else if (L.lead === 'green') Object.assign(v, { paper: dk, cream: mix(a, '#000000', 0.62), tint: mix(dk, '#ffffff', 0.12), g1: mix(a, '#ffffff', 0.5), g2: mix(a, '#000000', 0.78), g3: mix(a, '#ffffff', 0.62) });
        else Object.assign(v, { g1: a, g2: dk, g3: lt, tint: mix(a, '#ffffff', 0.84) });
      }
      return v;
    }
    const effDensity = () => (S.me && S.me.easy ? 'easy' : L.density === 'compact' ? 'compact' : 'normal');
    function applyLook() {
      const h = document.documentElement;
      let st = document.getElementById('coe-look'); if (!st) { st = document.createElement('style'); st.id = 'coe-look'; document.head.appendChild(st); }
      const v = palette(), dark = L.lead === 'ink' || L.lead === 'green';
      st.textContent = 'html:root{' + Object.entries(v).map(([k, x]) => '--' + k + ':' + x).join(';') + (dark ? ';color-scheme:dark' : '') + '}';
      h.dataset.lead = L.lead;
      h.style.fontSize = Math.round(16 * clamp(Number(L.scale) || 100, 80, 150)) / 100 + 'px';
      if (L.motion === 'full') delete h.dataset.motion; else h.dataset.motion = L.motion;
      const d = effDensity(); if (d === 'normal') delete h.dataset.density; else h.dataset.density = d;
      if (L.contrast) h.dataset.contrast = 'high'; else delete h.dataset.contrast;
    }
    CX.applyLook = applyLook;
    const saveLook = () => { store.set({ look: L }); applyLook(); };

    // ------------------------------------------------------------ soft sounds (off until switched on)
    let ac = null, bus = null;
    const ctx = () => { try { const A = window.AudioContext || window.webkitAudioContext; if (!A) return null; ac = ac || new A(); if (ac.state === 'suspended') ac.resume(); return ac; } catch { return null; } };
    const tn = (freq, ms, o) => {
      o = o || {}; const c = ctx(); if (!c) return;
      if (!bus) { const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 1600; lp.Q.value = 0.4; const g = c.createGain(); g.gain.value = 0.8; g.connect(lp); lp.connect(c.destination); bus = g; }
      const t0 = c.currentTime + (o.at || 0), len = ms / 1000, os = c.createOscillator(), g = c.createGain();
      os.type = 'sine'; os.frequency.setValueAtTime(freq, t0); if (o.to) os.frequency.exponentialRampToValueAtTime(o.to, t0 + len);
      const peak = o.vol || 0.03, atk = Math.min(0.03, len * 0.3);
      g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(peak, t0 + atk); g.gain.exponentialRampToValueAtTime(0.0001, t0 + len + 0.12);
      os.connect(g); g.connect(bus); os.start(t0); os.stop(t0 + len + 0.15);
    };
    CX.sfx = {
      send() { if (L.sfx) tn(440, 110, { to: 392, vol: 0.025 }); },
      done() { if (L.sfx) { tn(523, 160, { vol: 0.022 }); tn(659, 240, { at: 0.11, vol: 0.02 }); } },
      on() { if (L.sfx) { tn(440, 120, { vol: 0.02 }); tn(587, 170, { at: 0.07, vol: 0.018 }); } },
      right() { if (L.sfx) { tn(587, 130, { vol: 0.02 }); tn(784, 220, { at: 0.09, vol: 0.018 }); } },
      wrong() { if (L.sfx) tn(262, 240, { to: 220, vol: 0.02 }); },
    };

    // ------------------------------------------------------------ small form builders
    const srow = (label, hint, ctl, wide) => { const d = el('div', 'srow' + (wide ? ' wide' : '')); d.appendChild(el('div', 'sr-t', '<b class="d">' + esc(label) + '</b>' + (hint ? '<span class="tx">' + esc(hint) + '</span>' : ''))); d.appendChild(ctl); return d; };
    const sel = (value, opts, on, label) => { const s = el('select'); s.setAttribute('aria-label', label || ''); for (const o of opts) { const op = document.createElement('option'); op.value = o.value; op.textContent = o.label; s.appendChild(op); } s.value = String(value); s.onchange = () => on(s.value); return s; };
    const swc = (label, hint, on, f) => { const b = el('button', 'sw'); b.type = 'button'; b.setAttribute('role', 'switch'); b.setAttribute('aria-checked', String(!!on)); b.innerHTML = '<i aria-hidden="true"></i><span><b class="d">' + esc(label) + '</b>' + (hint ? '<em class="tx">' + esc(hint) + '</em>' : '') + '</span>'; b.onclick = () => { const v = b.getAttribute('aria-checked') !== 'true'; b.setAttribute('aria-checked', String(v)); f(v); }; return b; };
    const rng = (value, min, max, step, fmt, on, label, marks) => {
      const w = el('div', 'rng'), r = el('input'), o = el('output', 'd'); r.type = 'range'; r.min = min; r.max = max; r.step = step; r.value = value; r.setAttribute('aria-label', label);
      const paint = () => { o.textContent = fmt(Number(r.value)); }; paint(); r.oninput = paint; r.onchange = () => on(Number(r.value));
      w.append(r, o); if (marks) w.appendChild(el('div', 'rng-m tx', marks.map((m) => '<span>' + esc(m) + '</span>').join(''))); return w;
    };
    const heading = (t, sub) => el('div', 'sh', '<h3 class="d">' + esc(t) + '</h3>' + (sub ? '<p class="tx">' + sub + '</p>' : ''));
    const saveMe = (patch) => { S.me = { ...S.me, ...patch, at: Date.now() }; store.set({ me: S.me }); chrome.runtime.sendMessage({ type: 'about-push' }); applyLook(); };
    CX.saveMe = saveMe;

    // ------------------------------------------------------------ the tabs
    const TABS = [['account', 'Account', 'user'], ['usage', 'Usage', 'chart'], ['you', 'Memory', 'sparkle'], ['chat', 'Chat', 'chat'], ['learn', 'Learn', 'graduate'], ['look', 'Look', 'theme'], ['browser', 'Coe Mini', 'globe'], ['data', 'Data', 'backup'], ['about', 'About', 'info']];
    const PAINT = {};
    let tab = 'account';
    const bar = $('set-tabs');
    for (const [id, name, ic] of TABS) {
      if (!$('tp-' + id)) { const p = el('div', 'tp'); p.id = 'tp-' + id; p.hidden = true; p.appendChild(el('div')); p.firstChild.id = 'x-' + id; $('tp-about').parentElement.insertBefore(p, $('tp-about')); }
      const b = el('button', 'stab', IC(ic, 16) + '<span class="d">' + esc(name) + '</span>'); b.type = 'button'; b.id = 'st-' + id; b.setAttribute('role', 'tab');
      b.onclick = () => show(id); bar.appendChild(b);
    }
    function show(id) {
      tab = id; S.setTab = id;
      for (const [t] of TABS) { const on = t === id; $('tp-' + t).hidden = !on; $('st-' + t).setAttribute('aria-selected', String(on)); $('st-' + t).classList.toggle('on', on); }
      if (PAINT[id]) PAINT[id]();
      $('st-' + id).scrollIntoView({ block: 'nearest', inline: 'nearest' });
    }
    CX.showSettingsTab = (id) => { if ($('tp-' + id)) { if ($('setup').hidden) CX.showSetup(); show(id); } };
    new MutationObserver(() => { if (!$('setup').hidden) { show(tab); loadAcct(false); } }).observe($('setup'), { attributes: true, attributeFilter: ['hidden'] });

    // ---- Chat: the extra choices
    PAINT.chat = async () => {
      const o = await store.get(['check', 'whileBusy']), host = $('x-chat'); host.replaceChildren();
      host.appendChild(srow('Checking its work', 'Coe re-reads an answer and fixes mistakes before you see it. Each check uses a few tokens.', sel(o.check || 'smart', [{ value: 'off', label: 'Off' }, { value: 'smart', label: 'Smart: only when it matters' }, { value: 'always', label: 'Always' }], (v) => { store.set({ check: v }); }, 'Checking its own work')));
      host.appendChild(srow('While Coe is busy', 'What a new message does if Coe is still answering.', sel(o.whileBusy || 'queue', [{ value: 'queue', label: 'Wait in line: it is sent when Coe finishes' }, { value: 'interrupt', label: 'Interrupt: Coe stops and reads it now' }], (v) => { S.whileBusy = v; store.set({ whileBusy: v }); }, 'Sending while Coe is busy')));
      CX.paintCounts();
    };
    CX.paintCounts = () => { for (const id of ['pf-about', 'pf-sys']) { const n = $(id + '-n'), t = $(id); if (n && t) n.textContent = t.value.length + '/' + t.maxLength; } };
    for (const id of ['pf-about', 'pf-sys']) { const t = $(id); if (t) t.addEventListener('input', CX.paintCounts); }
    // little chips that add a line, the same ones as on Coe
    const chips = (id, list) => { const t = $(id); if (!t || t.dataset.chips) return; t.dataset.chips = '1'; const w = el('div', 'ci-chips'); for (const x of list) { const b = el('button', 'ci-chip tx', '+ ' + esc(x)); b.type = 'button'; b.onclick = () => { if (!t.value.includes(x)) { t.value = (t.value ? t.value.replace(/\s*$/, '. ') : '') + x + '.'; t.dispatchEvent(new Event('input', { bubbles: true })); } }; w.appendChild(b); } t.parentElement.appendChild(w); };
    chips('pf-about', ['I am in Year 9', 'I am doing GCSEs', 'I am doing A levels', 'I am learning to code', 'English is my second language']);
    chips('pf-sys', ['Show every step', 'Keep answers short', 'Check I understood with a question', 'Give an example first', 'Never just give the answer: guide me']);

    // ---- Learn
    PAINT.learn = () => {
      const host = $('x-learn'); host.replaceChildren(); const m = S.me || {};
      host.appendChild(srow('What you already know', 'So explanations start in the right place.', sel(m.level || 'auto', [{ value: 'auto', label: 'Work it out' }, { value: 'simple', label: 'Beginner: everyday words, small steps' }, { value: 'standard', label: 'Some experience' }, { value: 'expert', label: 'Expert: skip the basics' }], (v) => saveMe({ level: v }), 'What you already know')));
      host.appendChild(srow('Reply language', 'Coe always answers in this language. Code stays as it is.', sel(m.replyLang || '', [{ value: '', label: 'The one I write in' }, ...(SH.SAYS || []).map((v) => ({ value: v, label: v }))], (v) => saveMe({ replyLang: v }), 'Reply language')));
      host.appendChild(srow('Daily card goal', 'How many study cards you want to review each day.', rng(m.goal || 10, 5, 60, 5, (n) => n + ' cards', (n) => saveMe({ goal: n }), 'Daily card goal', ['5', '20', '40', '60']), true));
      host.appendChild(el('div', 'acts', '<button class="btn gold" type="button" id="open-study">' + 'Open Study' + '</button>'));
      $('open-study').onclick = () => CX.openStudy && CX.openStudy();
    };

    // ---- Look
    PAINT.look = () => {
      const host = $('x-look'); host.replaceChildren();
      const acc = fitAccent(L.accent);
      const g = el('div', 'cx-fr'); g.appendChild(el('span', 'label d', 'Themes'));
      const grid = el('div', 'th-grid'); grid.setAttribute('role', 'group'); grid.setAttribute('aria-label', 'Themes');
      for (const t of SH.THEMES || []) {
        const Ld = (SH.LEADS || []).find((l) => l.id === t.lead) || {}, on = L.lead === t.lead && acc.toLowerCase() === fitAccent(t.accent);
        const b = el('button', 'th-card' + (on ? ' on' : ''), '<span class="th-pv" style="background:' + Ld.page + ';border-color:' + Ld.edge + '" aria-hidden="true"><i style="background:' + fitAccent(t.accent) + '"></i><b style="background:' + Ld.edge + ';opacity:.85"></b><b style="background:' + Ld.edge + ';opacity:.4;width:40%"></b></span><span class="th-n d">' + esc(t.name) + '</span>');
        b.type = 'button'; b.setAttribute('aria-pressed', String(on)); b.onclick = () => { L.lead = t.lead; L.accent = t.accent; saveLook(); PAINT.look(); };
        grid.appendChild(b);
      }
      g.appendChild(grid); host.appendChild(g);
      const a = el('div', 'cx-fr'); a.appendChild(el('span', 'label d', 'Accent colour <i class="tx th-sub">replaces the green everywhere</i>'.replace(/<i.*$/, '')));
      a.appendChild(el('p', 'tx th-sub', 'Replaces the green everywhere.'));
      const row = el('div', 'ac-row'); row.setAttribute('role', 'group'); row.setAttribute('aria-label', 'Accent colour');
      for (const c of SH.ACCENTS || []) { const on = acc.toLowerCase() === c.hex.toLowerCase(); const b = el('button', 'ac-dot' + (on ? ' on' : ''), on ? IC('check', 16) : ''); b.type = 'button'; b.style.background = c.hex; b.setAttribute('aria-label', c.name); b.title = c.name; b.setAttribute('aria-pressed', String(on)); b.onclick = () => { L.accent = c.hex; saveLook(); PAINT.look(); }; row.appendChild(b); }
      const own = el('label', 'ac-own', '<input type="color" aria-label="Pick any colour"><span class="tx">Any colour</span>'); own.querySelector('input').value = acc; own.querySelector('input').onchange = (e) => { L.accent = e.target.value; saveLook(); PAINT.look(); }; row.appendChild(own);
      a.appendChild(row);
      const hx = el('div', 'ac-hex', '<input type="text" aria-label="Colour code" placeholder="#337957" maxlength="7"><button type="button" class="btn sm">' + IC('refresh', 15) + 'Back to green</button>');
      hx.querySelector('input').oninput = (e) => { if (/^#[0-9a-f]{6}$/i.test(e.target.value)) { L.accent = e.target.value; saveLook(); } };
      hx.querySelector('button').onclick = () => { L.accent = DEF_ACCENT; saveLook(); PAINT.look(); };
      a.appendChild(hx); a.appendChild(el('p', 'tx th-sub', 'Too-light colours are darkened a little so the white words on buttons stay easy to read.')); host.appendChild(a);
      host.appendChild(srow('Page colour', 'Light, dark, gold or green page.', sel(L.lead, (SH.LEADS || []).map((l) => ({ value: l.id, label: l.name + ': ' + l.blurb })), (v) => { L.lead = v; saveLook(); PAINT.look(); }, 'Colour')));
      host.appendChild(srow('Text size', '', rng(L.scale, 80, 150, 5, (n) => n + '%', (n) => { L.scale = n; saveLook(); }, 'Text size', ['Small', 'Normal', 'Large', 'Huge']), true));
      host.appendChild(srow('Animations', 'Slow or stop the movement across Coe.', sel(L.motion, [{ value: 'full', label: 'Full: everything moves' }, { value: 'calm', label: 'Calm: only small movements' }, { value: 'off', label: 'Off: nothing moves' }], (v) => { L.motion = v; saveLook(); }, 'Animations')));
      host.appendChild(srow('Spacing', 'How tight or roomy the page feels.', sel(effDensity(), [{ value: 'compact', label: 'Compact: more fits on screen' }, { value: 'normal', label: 'Normal' }, { value: 'easy', label: 'Roomy: bigger buttons, easier to tap' }], (v) => { L.density = v === 'compact' ? 'compact' : 'normal'; store.set({ look: L }); saveMe({ easy: v === 'easy' }); PAINT.look(); }, 'Spacing')));
      host.appendChild(swc('High contrast', 'Stronger text and borders.', L.contrast, (v) => { L.contrast = v; saveLook(); }));
      host.appendChild(swc('Click sounds', 'Soft sounds when you send and when Coe finishes.', L.sfx, (v) => { L.sfx = v; saveLook(); CX.sfx.on(); }));
      const beep = swc('Tell me when a reply is ready', 'A soft chime and a mark on the button when Coe finishes while you are on another tab.', S.beep, (v) => { S.beep = v; store.set({ beep: v }); const old = $('beep'); if (old) old.setAttribute('aria-checked', String(v)); });
      host.appendChild(beep);
      host.appendChild(srow('Enter key', 'What pressing Enter does in the message box.', sel(L.enter, [{ value: 'send', label: 'Sends the message: Shift+Enter adds a line' }, { value: 'newline', label: 'Adds a line: Ctrl+Enter sends' }], (v) => { L.enter = v; saveLook(); }, 'Enter key')));
      const r = el('div', 'acts', '<button type="button" class="btn sm">' + IC('refresh', 15) + 'Reset the look</button>'); r.firstChild.onclick = () => { L = { ...DEF, sfx: L.sfx, enter: L.enter }; saveLook(); saveMe({ easy: false }); PAINT.look(); };
      host.appendChild(r);
    };
    // The old "beep when a reply is ready" switch moves into Look, so it is not shown twice.
    { const old = $('beep'); if (old) old.hidden = true; }
    // Enter key mode: "Adds a line" means Ctrl+Enter sends
    $('ta').addEventListener('keydown', (e) => {
      if (L.enter !== 'newline' || e.key !== 'Enter' || e.isComposing) return;
      if (e.ctrlKey || e.metaKey) { e.preventDefault(); e.stopImmediatePropagation(); send($('ta').value); } else if (!e.shiftKey) { e.stopImmediatePropagation(); }
    }, true);
    const send = (t) => CX.send(t);

    // ---- Usage
    PAINT.usage = async () => {
      const host = $('x-usage'); host.replaceChildren(); host.appendChild(el('p', 'tx note', 'Looking…'));
      const r = await new Promise((ok) => chrome.runtime.sendMessage({ type: 'status' }, (x) => ok(chrome.runtime.lastError ? null : x)));
      host.replaceChildren();
      const card = (h, inner) => { const c = el('section', 'acc-card'); c.appendChild(el('h3', 'd', esc(h))); if (inner) c.appendChild(inner); return c; };
      const fmt = (n) => (n >= 1e6 ? (n / 1e6).toFixed(n % 1e6 ? 1 : 0) + 'M' : n >= 1000 ? Math.round(n / 1000) + 'k' : String(Math.max(0, Math.round(n))));
      const t = el('div');
      if (r && r.ok && r.limit != null) {
        const pct = clamp(Math.round((r.used / r.limit) * 100), 0, 100);
        t.innerHTML = '<div class="ubar' + (pct >= 100 ? ' out' : pct >= 90 ? ' hot' : '') + '" role="img" aria-label="' + pct + ' percent used"><i style="width:' + pct + '%"></i></div><p class="tx"><b class="d">' + fmt(r.limit - r.used) + '</b> tokens left of ' + fmt(r.limit) + ' today. They come back at midnight (UTC).' + (r.plan ? ' Plan: ' + esc(String(r.plan)) + '.' : '') + '</p>';
        const a = el('div', 'acts'), b = el('button', 'btn sm', 'See plans'); b.type = 'button'; b.onclick = () => chrome.tabs.create({ url: CX.siteBase() + 'plans/' }); a.appendChild(b); t.appendChild(a);
      } else t.innerHTML = '<p class="tx">' + (r && r.code === 'network' ? 'Could not reach Coe just now.' : 'Sign in to see what is left today. Signed-in accounts get more tokens a day.') + '</p>';
      host.appendChild(card('Today', t));
      const o = await store.get('refunds'), list = Array.isArray(o.refunds) ? o.refunds : [];
      const when = (x) => new Date(x).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' });
      const day = Date.now() - 86400000, wk = Date.now() - 7 * 86400000;
      const sum = (f) => list.filter((x) => f(x.t)).reduce((n, x) => n + (Number(x.tokens) || 0), 0);
      const rf = el('div');
      rf.appendChild(el('p', 'tx', 'If a reply goes wrong, Coe gives back the tokens it used. That means code that was cut off, a picture or a file that could not be made, or an answer that never arrived. It does not count when you stop a reply yourself.'));
      rf.appendChild(el('div', 'rf-sum', '<div><b class="d">' + fmt(sum((x) => x > day)) + '</b><span class="tx">given back today</span></div><div><b class="d">' + fmt(sum((x) => x > wk)) + '</b><span class="tx">in the last 7 days</span></div>'));
      if (!list.length) rf.appendChild(el('p', 'tx', 'No refunds yet. Nothing has gone wrong.'));
      else { const ul = el('ul', 'rf-list'); for (const x of list.slice(0, 30)) ul.appendChild(el('li', '', '<div class="rf-top"><b class="d">+' + fmt(Number(x.tokens) || 0) + '</b><span class="tx">' + esc(when(x.t)) + '</span></div><p class="tx">' + esc(x.why || '') + '</p>')); rf.appendChild(ul); const c = el('div', 'acts', '<button type="button" class="btn sm">Clear this list</button>'); c.firstChild.onclick = async () => { await store.set({ refunds: [] }); PAINT.usage(); }; rf.appendChild(c); }
      host.appendChild(card('Refunds', rf));
    };

    // ---- Account: what is on Coe's side too
    PAINT.account = () => { /* the existing account steps are already drawn */ };

    // ---- Data
    PAINT.data = async () => {
      const host = $('x-data'); host.replaceChildren();
      const o = await store.get('chats'), list = Array.isArray(o.chats) ? o.chats : [];
      host.appendChild(el('p', 'tx', list.length + (list.length === 1 ? ' conversation is' : ' conversations are') + ' kept in this browser. They are only sent anywhere when you send a message in them.'));
      const a = el('div', 'acts'); const mk = (t, f, dis) => { const b = el('button', 'btn', esc(t)); b.type = 'button'; b.disabled = !!dis; b.onclick = f; a.appendChild(b); return b; };
      mk('Save everything as a file', async () => {
        const all = await store.get(['chats', 'memory', 'styles', 'study', 'me']);
        const body = JSON.stringify({ app: 'coe-mini', v: 1, saved: new Date().toISOString(), chats: all.chats || [], memory: all.memory || [], styles: all.styles || [], study: all.study || null, me: all.me || {} }, null, 1);
        CX.saveFile('coe-mini-backup.json', body, 'application/json'); say('Saved as a file.');
      });
      const fi = el('input'); fi.type = 'file'; fi.accept = '.json,application/json'; fi.hidden = true; a.appendChild(fi);
      mk('Open a saved file', () => fi.click());
      fi.onchange = async () => {
        const f = fi.files && fi.files[0]; fi.value = ''; if (!f) return;
        try {
          const j = JSON.parse(await f.text()); if (!j || (j.app !== 'coe-mini' && !Array.isArray(j.chats) && !Array.isArray(j.conversations))) throw new Error('x');
          const cur = (await store.get('chats')).chats || [], have = new Set(cur.map((c) => c.id)); let added = 0;
          for (const c of Array.isArray(j.chats) ? j.chats : []) if (c && c.id && !have.has(c.id)) { cur.push(c); added++; }
          await store.set({ chats: cur.slice(0, 200) });
          if (Array.isArray(j.memory)) saveMem([...mem, ...j.memory.filter((x) => typeof x === 'string')]);
          if (Array.isArray(j.styles)) { mergeStyles(j.styles); }
          if (j.study && Array.isArray(j.study.cards)) { mergeStudy(j.study); }
          say(added ? added + ' conversations brought in.' : 'Nothing new in that file.'); PAINT.data();
        } catch { say('That is not a Coe Mini file.'); }
      };
      host.appendChild(a);
      const b = el('div', 'acts'), del = el('button', 'btn', 'Delete all conversations'); del.type = 'button'; del.disabled = !list.length; b.appendChild(del); host.appendChild(b);
      del.onclick = () => { b.replaceChildren(el('span', 'sure', '<b class="d">Delete all ' + list.length + '?</b>')); const y = el('button', 'btn sm danger', 'Yes, delete'), n = el('button', 'btn sm', 'No'); y.type = n.type = 'button'; y.onclick = async () => { await store.set({ chats: [] }); say('Deleted.'); PAINT.data(); }; n.onclick = () => PAINT.data(); b.append(y, n); };
    };

    // ---- About: what Coe can do (the list on the website) and a way to tell us something
    PAINT.about = () => {
      const host = $('x-about'); host.replaceChildren();
      const F = SH.FEATURES || [], G = SH.FEATURE_GROUPS || [], TAG = { free: 'Free', pro: 'Pro', both: 'Free + Pro' };
      host.appendChild(el('div', 'ab-top', '<b class="d ab-n">' + F.length + '</b><div><b class="d">Things Coe can do</b><p class="tx">Every one of these works today. <span class="ab-tag free">Free</span> is for everyone, <span class="ab-tag pro">Pro</span> needs a plan, and <span class="ab-tag both">Free + Pro</span> has a taste on Free and much more on Pro.</p></div>'));
      const q = el('input'); q.type = 'search'; q.className = 'cx-in'; q.placeholder = 'Search the list'; q.setAttribute('aria-label', 'Search features'); host.appendChild(q);
      const list = el('div'); host.appendChild(list); let openG = null;
      const draw = () => {
        list.replaceChildren(); const f = q.value.trim().toLowerCase(), shown = F.filter((x) => !f || (x.title + ' ' + x.text).toLowerCase().includes(f));
        if (f) list.appendChild(el('p', 'tx small', shown.length + ' found'));
        for (const g of G) {
          const rows = shown.filter((x) => x.group === g.id); if (!rows.length) continue; const on = !!f || openG === g.id;
          const s = el('section', 'ab-g'), h = el('button', 'ab-h', '<span class="ab-gi" aria-hidden="true">' + IC(g.icon, 20) + '</span><span class="ab-gt"><b class="d">' + esc(g.name) + '</b><span class="tx">' + esc(g.blurb) + '</span></span><i class="ab-c">' + rows.length + '</i>');
          h.type = 'button'; h.setAttribute('aria-expanded', String(on)); h.onclick = () => { openG = openG === g.id ? null : g.id; draw(); }; s.appendChild(h);
          if (on) { const ul = el('ul', 'ab-l'); for (const x of rows) ul.appendChild(el('li', x.wow ? 'wow' : '', '<span class="ab-ic" aria-hidden="true">' + IC(x.icon, 18) + '</span><div><b class="d">' + esc(x.title) + '</b><p class="tx">' + esc(x.text) + '</p></div><span class="ab-tag ' + x.plan + '">' + TAG[x.plan] + '</span>')); s.appendChild(ul); }
          list.appendChild(s);
        }
      };
      q.oninput = draw; draw();
      const fb = el('form', 'cx-fbform', '<b class="d">Tell us something</b>');
      const k = sel('idea', [{ value: 'idea', label: 'An idea' }, { value: 'problem', label: 'Something is wrong' }, { value: 'other', label: 'Something else' }], () => {}, 'What is it?');
      const ta = el('textarea'); ta.rows = 4; ta.maxLength = 2000; ta.placeholder = 'Write it here'; ta.setAttribute('aria-label', 'Your message');
      const row = el('div', 'acts'), go = el('button', 'btn sm gold', 'Send'), st = el('span', 'tx'); go.type = 'submit'; go.disabled = true; row.append(go, st);
      ta.oninput = () => { go.disabled = !ta.value.trim(); st.textContent = ''; };
      fb.append(k, ta, row);
      fb.onsubmit = async (e) => {
        e.preventDefault(); if (!ta.value.trim()) return; go.disabled = true; go.textContent = 'Sending…';
        const r = await bg({ type: 'feedback', message: ta.value, kind: k.value });
        go.textContent = 'Send';
        if (r && r.ok && r.emailed) { st.textContent = 'Sent. Thank you.'; ta.value = ''; go.disabled = true; }
        else { st.textContent = 'It could not be sent from here. '; const m = el('button', 'btn sm', 'Email it instead'); m.type = 'button'; m.onclick = () => chrome.tabs.create({ url: 'mailto:contact@pmcstudios.uk?subject=' + encodeURIComponent('Coe Mini feedback: ' + k.value) + '&body=' + encodeURIComponent(ta.value) }); st.appendChild(m); go.disabled = false; }
      };
      host.appendChild(fb);
      host.appendChild(el('p', 'tx small', 'Coe Mini is made by PMC Studios. It can be wrong, so check anything important.'));
    };

    // ------------------------------------------------------------ what follows the account: memory, working styles, study
    const MAXF = 60, STYLE_MAX = 12;
    let mem = [], styles = [], persona = 'coe';
    const emptyStudy = () => ({ decks: [], cards: [], log: {}, xp: 0 });
    let study = emptyStudy();
    const cleanMem = (list) => [...new Set(list.map((x) => String(x).replace(/\s+/g, ' ').trim().slice(0, 240)).filter(Boolean))].slice(0, MAXF);
    const sid = () => 'u-' + Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-3);
    const suid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
    const today = () => { const d = new Date(); return Math.floor((d.getTime() - d.getTimezoneOffset() * 60000) / 86400000); };
    const dayKey = (n) => new Date(n * 86400000).toISOString().slice(0, 10);
    const norm = (s) => String(s).replace(/\s+/g, ' ').trim().toLowerCase();
    let pushT = 0;
    const pushSoon = () => { clearTimeout(pushT); pushT = setTimeout(pushNow, 1500); };
    async function pushNow() {
      if (!(S.status && S.status.signedIn)) return;
      const patch = { memory: mem, study }; if (styles.length) patch.styles = styles;
      try { await bg({ type: 'acct-set', patch }); } catch { /* try again next change */ }
    }
    const persist = () => store.set({ memory: mem, styles, study, persona });
    const saveMem = (list) => { mem = cleanMem(list); persist(); pushSoon(); paintMem(); return mem; };
    const saveStudy = () => { persist(); pushSoon(); };
    function mergeStyles(other) {
      if (!Array.isArray(other)) return false; let changed = false;
      for (const o of other) {
        if (!o || typeof o.id !== 'string' || !/^u-[\w]{1,20}$/.test(o.id) || typeof o.name !== 'string') continue;
        const i = styles.findIndex((p) => p.id === o.id);
        const one = { id: o.id, name: String(o.name).slice(0, 30), blurb: String(o.blurb || '').slice(0, 90), prompt: String(o.prompt || '').slice(0, 1500), mine: true, upd: Number(o.upd) || 0, ...(o.del ? { del: true } : {}) };
        if (i < 0) { if (styles.length < 60 && (one.del || (one.name && one.prompt))) { styles.push(one); changed = true; } }
        else if ((one.upd || 0) > (styles[i].upd || 0)) { styles[i] = one; changed = true; }
      }
      if (changed) { persist(); }
      return changed;
    }
    function mergeStudy(other) {
      if (!other || !Array.isArray(other.cards) || !Array.isArray(other.decks)) return 0; let fresh = 0;
      for (const d of other.decks) if (!study.decks.some((x) => x.id === d.id)) study.decks.push(d);
      for (const c of other.cards) { const mine = study.cards.find((x) => x.id === c.id); if (!mine) { if (study.decks.some((d) => d.id === c.deck)) { study.cards.push(c); fresh++; } } else if ((c.upd || 0) > (mine.upd || 0)) Object.assign(mine, c); }
      for (const [k, v] of Object.entries(other.log || {})) study.log[k] = Math.max(study.log[k] || 0, Number(v) || 0);
      study.xp = Math.max(study.xp || 0, Number(other.xp) || 0); persist(); return fresh;
    }
    let lastPull = 0;
    async function loadAcct(force) {
      if (!(S.status && S.status.signedIn) || (!force && Date.now() - lastPull < 20000)) return; lastPull = Date.now();
      const r = await bg({ type: 'acct-get' }); if (!r || !r.ok) return; const d = r.data || {};
      const theirs = Array.isArray(d.memory) ? d.memory.filter((x) => typeof x === 'string') : [];
      const before = JSON.stringify([mem, styles, study]);
      mem = cleanMem([...theirs, ...mem]); mergeStyles(d.styles); mergeStudy(d.study);
      persist();
      const after = JSON.stringify([mem, styles, study]);
      if (after !== before || mem.length !== theirs.length || mem.some((m, i) => m !== theirs[i]) || (styles.length && !Array.isArray(d.styles))) pushSoon();
      if (after !== before) { paintMem(); CX.onStudyChange && CX.onStudyChange(); }
    }
    CX.acct = {
      get mem() { return mem; }, get styles() { return styles.filter((s) => !s.del); }, get study() { return study; }, get persona() { return persona; },
      remember: (f) => { const n = cleanMem([...mem, f]); if (n.length === mem.length && n.every((x, i) => x === mem[i])) return false; saveMem(n); return true; },
      forget: (f) => saveMem(mem.filter((x) => x !== f)),
      save: saveStudy, pull: loadAcct, today, dayKey, norm, suid, push: pushSoon,
    };
    const BI = () => (SH.PERSONAS || []);
    const allStyles = () => [...BI(), ...styles.filter((s) => !s.del)];
    const personaOf = (id) => allStyles().find((p) => p.id === id) || BI()[0];
    CX.personaOf = personaOf;

    // ---- Memory tab (the same notes as on Coe) and "Coe works as" (working styles)
    function paintMem() {
      const host = $('x-you'); if (!host || $('tp-you').hidden) return; const keepScroll = $('setup').scrollTop; host.replaceChildren();
      const signed = !!(S.status && S.status.signedIn);
      const sec = el('section', 'cx-sec'); sec.appendChild(el('h3', 'd', 'What Coe remembers'));
      sec.appendChild(el('p', 'tx small', 'Short notes Coe keeps about you so you do not repeat yourself. ' + (signed ? 'They follow your account to other devices and to Coe.' : 'They stay in this browser. Sign in to have them follow you.') + ' Say “remember that…” in a chat to add one.'));
      if (!mem.length) sec.appendChild(el('p', 'tx small', '<i>Nothing yet.</i>'));
      const ul = el('ul', 'cx-notes');
      mem.forEach((n, i) => {
        const li = el('li'); const span = el('span', 'tx', esc(n)); li.appendChild(span);
        const ed = el('button', 'ib sm', IC('edit', 16)); ed.type = 'button'; ed.title = ed.ariaLabel = 'Edit: ' + n;
        ed.onclick = () => { li.replaceChildren(); const f = el('form', 'inl'), inp = el('input'); inp.maxLength = 240; inp.value = n; inp.setAttribute('aria-label', 'Edit note'); const s = el('button', 'btn sm', 'Save'), c = el('button', 'btn sm', 'Cancel'); s.type = 'submit'; c.type = 'button'; f.append(inp, s, c); li.appendChild(f); inp.focus(); f.onsubmit = (e) => { e.preventDefault(); const next = mem.slice(); next[i] = inp.value; saveMem(next); }; c.onclick = () => paintMem(); };
        const de = el('button', 'ib sm', IC('trash', 16)); de.type = 'button'; de.title = de.ariaLabel = 'Delete: ' + n; de.onclick = () => saveMem(mem.filter((_, k) => k !== i));
        li.append(ed, de); ul.appendChild(li);
      });
      sec.appendChild(ul);
      const f = el('form', 'inl'), inp = el('input'); inp.maxLength = 240; inp.placeholder = mem.length >= MAXF ? 'The list is full. Delete one first.' : 'Add a note, e.g. I am studying GCSE chemistry'; inp.disabled = mem.length >= MAXF; inp.setAttribute('aria-label', 'New note');
      const add = el('button', 'btn sm', 'Add'); add.type = 'submit'; add.disabled = true; inp.oninput = () => { add.disabled = !inp.value.trim(); }; f.append(inp, add);
      f.onsubmit = (e) => { e.preventDefault(); if (inp.value.trim()) saveMem([...mem, inp.value]); }; sec.appendChild(f);
      if (mem.length) { const a = el('div', 'acts'), fa = el('button', 'btn sm', 'Forget all'); fa.type = 'button'; a.appendChild(fa); fa.onclick = () => { a.replaceChildren(el('span', 'sure', '<b class="d">Forget all ' + mem.length + '?</b>')); const y = el('button', 'btn sm', 'Yes, forget'), n = el('button', 'btn sm', 'No'); y.type = n.type = 'button'; y.onclick = () => saveMem([]); n.onclick = () => paintMem(); a.append(y, n); }; sec.appendChild(a); }
      host.appendChild(sec);
      // working style
      const ws = el('section', 'cx-sec'); ws.appendChild(el('h3', 'd', 'Coe works as'));
      ws.appendChild(el('p', 'tx small', 'A way of working that shapes every answer. Pick one, or write your own.'));
      ws.appendChild(sel(persona, allStyles().map((p) => ({ value: p.id, label: p.name + (p.blurb ? ': ' + p.blurb : '') })), (v) => { persona = v; persist(); paintMem(); }, 'Coe works as'));
      const mine = styles.filter((s) => !s.del);
      if (mine.length) { const l = el('ul', 'cx-notes'); for (const s of mine) { const li = el('li', '', '<span class="tx"><b class="d">' + esc(s.name) + '</b> ' + esc(s.blurb) + '</span>'); const ed = el('button', 'ib sm', IC('edit', 16)), de = el('button', 'ib sm', IC('trash', 16)); ed.type = de.type = 'button'; ed.title = 'Edit ' + s.name; de.title = 'Delete ' + s.name; ed.onclick = () => styleForm(s); de.onclick = () => { const i = styles.findIndex((p) => p.id === s.id); styles[i] = { id: s.id, name: '', blurb: '', prompt: '', mine: true, upd: Date.now(), del: true }; if (persona === s.id) persona = 'coe'; persist(); pushSoon(); paintMem(); }; li.append(ed, de); l.appendChild(li); } ws.appendChild(l); }
      const nb = el('button', 'btn sm', 'Write my own style'); nb.type = 'button'; nb.disabled = mine.length >= STYLE_MAX; nb.onclick = () => styleForm(null); const a2 = el('div', 'acts'); a2.appendChild(nb); ws.appendChild(a2);
      host.appendChild(ws);
      $('setup').scrollTop = keepScroll;
    }
    function styleForm(cur) {
      const f = el('form', 'cx-sf'), nm = el('input'), bl = el('input'), pr = el('textarea');
      nm.maxLength = 30; nm.placeholder = 'Name, e.g. Strict examiner'; nm.value = cur ? cur.name : ''; bl.maxLength = 90; bl.placeholder = 'A few words about it'; bl.value = cur ? cur.blurb : ''; pr.rows = 6; pr.maxLength = 1500; pr.placeholder = 'How Coe should work, in your own words. For example: Mark my answers like an exam board, and say how many marks each would get.'; pr.value = cur ? cur.prompt : '';
      for (const [t, e] of [['Name', nm], ['What it is', bl], ['How Coe should work', pr]]) { const l = el('label', 'fld', '<span class="d">' + t + '</span>'); l.appendChild(e); f.appendChild(l); }
      const a = el('div', 'acts'), s = el('button', 'btn gold', 'Save style'); s.type = 'submit'; a.appendChild(s); f.appendChild(a);
      f.onsubmit = (e) => {
        e.preventDefault(); const name = nm.value.trim().slice(0, 30), prompt = pr.value.trim().slice(0, 1500); if (!name || !prompt) return;
        const i = cur ? styles.findIndex((p) => p.id === cur.id) : -1;
        const one = { id: i >= 0 ? styles[i].id : sid(), name, blurb: bl.value.trim().slice(0, 90) || 'Your own way of working.', prompt, mine: true, upd: Date.now() };
        if (i >= 0) styles[i] = one; else styles.push(one); persona = one.id; persist(); pushSoon(); closeDlg(); paintMem();
      };
      openDlg(cur ? 'Change this style' : 'Write my own style', [f]);
    }
    PAINT.you = () => { paintMem(); loadAcct(false); };

    // ------------------------------------------------------------ what Coe is told (the same sections as on Coe)
    const P = (SH.PROMPTS || {}), sect = P.sect || {}, SHOWP = P.show || {};
    const BASE_KEYS = ['Who you are for', 'Think first, then check', 'Be honest, not agreeable', 'Study help', 'Code help', 'Keep private', 'Limits'];
    CX.system.push(() => BASE_KEYS.map((k) => sect[k]).filter(Boolean).join('\n\n'));
    CX.system.push(() => '# Showing things (in addition to the blocks above)\n' + ['graph', 'slides', 'data', 'chartMore', 'mermaid', 'html', 'followups'].map((k) => SHOWP[k]).filter(Boolean).join('\n') + '\n- Remembering: when the person asks you to remember something, or clearly states a lasting preference, give one block:\n```coe-remember\n{"fact":"short note"}\n```\nCoe saves it. Never say you saved it without the block.');
    CX.system.push(() => { const p = personaOf(persona); return p && p.prompt && p.id !== 'coe' ? 'Working style the person chose (' + p.name + '): ' + p.prompt : ''; });
    CX.system.push(() => (mem.length && !S.temp ? 'What the person has asked you to remember (use it quietly, only where it helps):\n' + mem.map((x) => '- ' + x).join('\n') : ''));
    CX.system.push(() => 'Today is ' + new Date().toDateString() + '.');

    // a "remember" block from Coe: saved once, with Undo
    CX.blocks['coe-remember'] = (m, n, p, bk, st) => {
      let f = ''; try { f = String(CX.jsonOf(p.s).fact || '').trim().slice(0, 240); } catch { /* not JSON */ }
      if (!f) return bk;
      if (S.temp) { bk.appendChild(el('p', 'tx', 'This is a private chat, so nothing is kept in your notes.')); return bk; }
      if (!st.done) { st.done = true; st.added = CX.acct.remember(f); }
      const c = el('div', 'remb', IC('sparkle', 16) + '<span class="tx">' + (st.undone ? 'Not kept: ' : st.added ? 'Saved to what Coe remembers: ' : 'Already in your notes: ') + esc(f) + '</span>');
      if (st.added && !st.undone) { const u = CX.bkBtn('Undo', () => { st.undone = true; CX.acct.forget(f); CX.renderMsgs(); }); c.appendChild(u); }
      bk.appendChild(c); return bk;
    };
    CX.titles['coe-remember'] = 'Remembering'; if (!CX.BLK.includes('coe-remember')) CX.BLK.push('coe-remember');

    // ------------------------------------------------------------ Coe checks its own work (the same words as on Coe)
    const worth = (mode, draft, ask) => {
      if (mode === 'off') return false; if (draft.length < 30 || draft.length > 7000) return false;
      if (/`{3}(ask|followups)/.test(draft) && draft.length < 400) return false; if (mode === 'always') return true;
      if (/\d\s*[-+*/=^×÷]\s*\d|\$[^$]+\$|\\\(|\\\[|`{3}\s*(js|javascript|ts|typescript|py|python|java|c|cpp|cs|csharp|go|rust|ruby|php|sql|html|css|bash|sh)\b/i.test(draft)) return true;
      if (/\b(solve|calculate|work out|how many|how much|what is \d|prove|simplify|factorise|expand|differentiate|integrate|convert|percentage|average|mean|median|probability|equation|fix|bug|error|debug|code|function|script)\b/i.test(ask)) return true;
      return draft.length > 900;
    };
    CX.check = async (bot, ask) => {
      const o = await store.get('check'), mode = o.check || 'smart';
      if (S.stopped || bot.cut || !worth(mode, String(bot.text || ''), String(ask || ''))) return;
      S.phase = 'Double-checking'; CX.renderMsgs();
      const r = await CX.callText(SH.CHECK_SYSTEM || '', 'The chat so far:\n' + CX.chatForCheck() + '\n\nThe draft answer to check:\n' + bot.text);
      S.phase = '';
      if (!r.ok) return;
      const t = String(r.text || '').trim();
      if (/^FIX:/i.test(t)) { const rest = t.replace(/^FIX:\s*/i, ''), i = rest.search(/\n\s*\n/); if (i > 0 && rest.slice(i).trim().length > 20) { bot.fixed = rest.slice(0, i).trim().slice(0, 240); bot.text = rest.slice(i).trim(); } }
      bot.checked = true; CX.renderMsgs();
    };
    CX.chatForCheck = () => S.msgs.filter((m) => !m.hidden && !m.kind && m.text).slice(-6, -1).map((m) => (m.role === 'user' ? 'Person: ' : 'Coe: ') + String(m.send || m.text).slice(0, 1500)).join('\n');
    CX.callText = (system, user) => new Promise((done) => {
      const port = CX.connect(); let text = '', over = false;
      port.onMessage.addListener((m) => {
        if (over) return;
        if (m.t === 'd') text += m.s;
        else if (m.t === 'end') { over = true; try { port.disconnect(); } catch { /* done */ } if (m.credits) CX.setMeter(m.credits); done({ ok: !m.stopped, text }); }
        else if (m.t === 'err') { over = true; try { port.disconnect(); } catch { /* done */ } done({ ok: false }); }
      });
      port.postMessage({ type: 'send', system, messages: [{ role: 'user', content: user }] });
    });

    // ------------------------------------------------------------ start up
    (async () => {
      const o = await store.get(['look', 'memory', 'styles', 'study', 'persona', 'whileBusy']);
      L = { ...DEF, ...(o.look || {}) }; if (!['cream', 'ink', 'gold', 'green'].includes(L.lead)) L.lead = 'cream';
      mem = Array.isArray(o.memory) ? cleanMem(o.memory) : []; styles = Array.isArray(o.styles) ? o.styles : []; study = o.study && Array.isArray(o.study.cards) ? { ...emptyStudy(), ...o.study } : emptyStudy(); persona = o.persona || 'coe';
      if (!allStyles().some((p) => p.id === persona)) persona = 'coe';
      S.whileBusy = o.whileBusy || 'queue';
      applyLook(); CX.paintCounts(); show('account');
      setTimeout(() => loadAcct(true), 1500);
      addEventListener('focus', () => loadAcct(false));
    })();
    chrome.storage.onChanged.addListener((c) => { if (c.me && !$('setup').hidden) { applyLook(); if (tab === 'learn' || tab === 'look') PAINT[tab](); } if (c.session) { lastPull = 0; setTimeout(() => loadAcct(true), 800); } });
  }

  if (CX.S) start(); else CX.ready.push(start);
})();
