// Coe Mini: the rest of what Coe can do, so the sidebar and the website match.
// This plugs into sidepanel.js through window.CX. Lists (slash commands, styles, maths keys, colours) come from shared.js,
// which is made from the Coe website itself, so both always offer the same things.
(() => {
  'use strict';
  const CX = window.CX; if (!CX) return;
  const SH = window.COE_SHARED || {};

  function start() {
    const { S, $, el, esc, send, bg, openDlg, closeDlg, store, first } = CX;
    CX.cmdSources = []; CX.addCmds = (f) => CX.cmdSources.push(f);
    const hand = (text) => chrome.runtime.sendMessage({ type: 'handoff', text });
    const openCoe = () => chrome.runtime.sendMessage({ type: 'open-coe' });
    const say = (t) => { const b = el('div', 'toast tx', esc(t)); document.body.appendChild(b); setTimeout(() => b.remove(), 2600); };
    CX.say = say;
    const ta = () => $('ta');
    const put = (text, replace) => { const t = ta(); t.value = replace ? text : (t.value ? t.value.replace(/\s*$/, '\n\n') : '') + text; t.dispatchEvent(new Event('input', { bubbles: true })); CX.grow(); t.focus(); t.setSelectionRange(t.value.length, t.value.length); };
    const rows = () => S.msgs.filter((m) => m.text && !m.hidden && !m.kind);
    const chatTitle = () => first((S.tx.find((x) => x.r === 'u') || { t: 'Coe Mini chat' }).t, 60);
    const inChat = () => !$('chat').hidden;

    // ------------------------------------------------------------ keyboard shortcuts list
    const KEYS = [['Ctrl+K', 'Commands: find anything Coe can do'], ['Ctrl+Shift+O', 'New chat'], ['Ctrl+/', 'This list'], ['Enter', 'Send'], ['Shift+Enter', 'New line'], ['Esc', 'Stop a reply, or close a window'], ['/', 'At the start of a message: commands like /quiz and /flashcards'], ['Space', 'In Study: show the answer'], ['1 2 3 4', 'In Study: Again, Hard, Good, Easy']];
    function openKeys() {
      const dl = el('dl', 'keys'); for (const [k, v] of KEYS) dl.appendChild(el('div', '', '<dt><kbd>' + esc(k) + '</kbd></dt><dd class="tx">' + esc(v) + '</dd>'));
      openDlg('Keyboard shortcuts', [dl]);
    }
    CX.openKeys = openKeys;

    // ------------------------------------------------------------ save and share
    const html = (m) => CX.mdBlock(m.text);
    const pageHtml = (forPrint) => {
      const body = rows().map((m) => '<section class="' + m.role + '"><h3>' + (m.role === 'user' ? 'Me' : 'Coe') + '</h3>' + html(m) + '</section>').join('');
      return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' + esc(chatTitle()) + '</title><style>'
        + 'body{margin:0;background:#FBF6EC;color:#171717;font:16px/1.55 Georgia,serif}main{max-width:760px;margin:0 auto;padding:28px 18px 60px}h1{font:400 2.4rem/1 Impact,Haettenschweiler,sans-serif;text-transform:uppercase;margin:0 0 18px}'
        + 'section{border:3px solid #171717;background:#fff;box-shadow:5px 5px 0 #1A4934;padding:6px 16px 10px;margin:16px 0}section.user{background:#F2E4CE}h3{font:400 1.15rem Impact,sans-serif;text-transform:uppercase;margin:8px 0 4px}pre{background:#171717;color:#F2E4CE;padding:10px;overflow:auto}code{font-family:monospace}table{border-collapse:collapse}td,th{border:2px solid #171717;padding:4px 8px}img,svg{max-width:100%}'
        + (forPrint ? '@media print{body{background:#fff}section{box-shadow:none}}' : '') + '</style></head><body><main><h1>' + esc(chatTitle()) + '</h1>' + body + '<p style="opacity:.6;font-size:.85rem">Saved from Coe Mini.</p></main></body></html>';
    };
    const saveMd = () => { const r = rows(); if (!r.length) return say('There is nothing in this chat to save yet.'); CX.saveFile('coe-mini-chat.md', '# ' + chatTitle() + '\n\n' + r.map((m) => '**' + (m.role === 'user' ? 'Me' : 'Coe') + '**\n\n' + m.text).join('\n\n---\n\n'), 'text/markdown'); };
    const saveHtml = () => { if (!rows().length) return say('There is nothing in this chat to save yet.'); CX.saveFile('coe-mini-chat.html', pageHtml(false), 'text/html'); };
    const savePdf = async () => { if (!rows().length) return say('There is nothing in this chat to save yet.'); await store.set({ printJob: { html: pageHtml(true), ts: Date.now() } }); chrome.tabs.create({ url: chrome.runtime.getURL('print.html') }); say('A page opens. Choose Save as PDF in the print box.'); };
    CX.saveMd = saveMd; CX.saveHtml = saveHtml; CX.savePdf = savePdf;
    function openSave() {
      const box = el('div', 'saver'); box.appendChild(el('p', 'tx', 'Save this chat as:'));
      for (const [t, d, f] of [['Markdown', 'A text file with the words', saveMd], ['PDF', 'Opens the print box: choose Save as PDF', savePdf], ['A web page', 'One file you can open in any browser', saveHtml]]) { const b = el('button', 'btn wide', '<b>' + esc(t) + '</b><small class="tx">' + esc(d) + '</small>'); b.type = 'button'; b.onclick = () => { closeDlg(); f(); }; box.appendChild(b); }
      openDlg('Save this chat', [box]);
    }
    CX.openSave = openSave;

    const shareOf = async () => ((await store.get('shares')).shares || {})[S.chatId] || '';
    async function openShare() {
      if (S.temp) return say('A private chat cannot be shared.');
      const o = await store.get(['session']); if (!(o.session && o.session.uid)) return say('Sign in to share a link.');
      let id = await shareOf(); const box = el('div', 'shr');
      const paint = () => {
        box.replaceChildren();
        if (!id) { box.appendChild(el('p', 'tx', 'This makes a link to a <b>read-only copy</b> of “' + esc(chatTitle()) + '”. Anyone with the link can read it, and nobody can change it.')); box.appendChild(el('ul', 'tx shr-facts', '<li>Only the words are shared. Pictures, files and your account details are left out.</li><li>You can stop sharing whenever you like, and the link stops working.</li>')); }
        else {
          const link = CX.siteBase() + 'share/#' + id;
          box.appendChild(el('p', 'tx', 'Anyone with this link can read a copy of this chat.'));
          const row = el('div', 'shr-link'); const inp = el('input', 'cx-in'); inp.readOnly = true; inp.value = link; inp.setAttribute('aria-label', 'Share link'); inp.onfocus = () => inp.select();
          const cp = el('button', 'btn sm', 'Copy'); cp.type = 'button'; cp.onclick = async () => { try { await navigator.clipboard.writeText(link); cp.textContent = 'Copied'; setTimeout(() => (cp.textContent = 'Copy'), 1600); } catch { inp.select(); } };
          row.append(inp, cp); box.appendChild(row); box.appendChild(el('p', 'tx small', 'Chat changed since? Press Update to put the new messages on the same link.'));
        }
        const err = el('p', 'tx bad'); err.hidden = true; box.appendChild(err);
        const bar = el('div', 'act');
        const mk = el('button', 'btn gold', id ? 'Update' : 'Make a link'); mk.type = 'button';
        mk.onclick = async () => {
          mk.disabled = true; mk.textContent = 'One moment…';
          const data = { title: chatTitle().slice(0, 120), ts: Date.now(), from: 'mini', v: (CX.release && CX.release.v) || '', messages: rows().map((m) => ({ role: m.role, text: String(m.text).replace(/```coe-(?:tool|plan|edit|highlight|open|search|remember)[\s\S]*?```/g, '').trim().slice(0, 60000) })).filter((m) => m.text) };
          const r = await bg({ type: 'share-make', id, data });
          if (r && r.ok) { id = r.id; const sh = (await store.get('shares')).shares || {}; sh[S.chatId] = id; await store.set({ shares: sh }); paint(); }
          else { mk.disabled = false; mk.textContent = id ? 'Update' : 'Make a link'; err.hidden = false; err.textContent = (r && r.error) || 'That could not be shared. Try again.'; }
        };
        bar.appendChild(mk);
        if (id) { const st = el('button', 'btn sm', 'Stop sharing'); st.type = 'button'; st.onclick = async () => { await bg({ type: 'share-stop', id }); const sh = (await store.get('shares')).shares || {}; delete sh[S.chatId]; await store.set({ shares: sh }); id = ''; say('This chat is not shared any more. The link no longer works.'); paint(); }; bar.appendChild(st); }
        box.appendChild(bar);
      };
      paint(); openDlg('Share this chat', [box]);
    }
    CX.openShare = openShare;

    // ------------------------------------------------------------ this chat: quiz, cards, summary, and squeezing the old part
    const thisChat = (t, s) => { if (!rows().length) return say('Talk about something first, then try this.'); send(t, { say: s || t }); };
    async function compact() {
      const r = rows(); if (r.length < 10 || S.busy) return say(r.length < 10 ? 'This chat is still short. It needs no summary yet.' : 'Wait for Coe to finish first.');
      const old = S.msgs.filter((m) => m.text && !m.hidden && !m.kind), keep = old.slice(-4), cut = old.slice(0, -4);
      say('Summarising the older messages…');
      const res = await CX.callJson('You squeeze the old part of a chat into a short summary so the chat stays quick. Keep names, numbers, decisions, what the person wants and what is still open. Reply with JSON only: {"summary":"the summary, at most 220 words"}', cut.map((m) => (m.role === 'user' ? 'Me: ' : 'Coe: ') + m.text.slice(0, 1500)).join('\n\n'));
      if (!res || !res.ok || !res.data || !res.data.summary) return CX.showErr(res && res.code || 'other', res && res.error);
      S.msgs = [{ role: 'assistant', text: '**Earlier messages, summarised**\n\n' + String(res.data.summary), at: Date.now(), compact: true }, ...S.msgs.filter((m) => !cut.includes(m))];
      CX.renderMsgs(); say('Older messages are now one short summary.');
    }
    CX.compact = compact;

    // ------------------------------------------------------------ the maths keyboard
    const CUR = '‸';
    function openMaths() {
      const kx = (t, d) => { try { return window.katex.renderToString(t, { displayMode: !!d, throwOnError: false, output: 'html' }); } catch { return esc(t); } };
      const box = el('div', 'mpad'); let tab = SH.MATH_TABS[0].id, display = false;
      const tabs = el('div', 'mp-tabs'), keys = el('div', 'mp-keys');
      const area = el('textarea', 'mp-ta'); area.rows = 2; area.spellcheck = false; area.setAttribute('aria-label', 'LaTeX'); area.placeholder = 'Type LaTeX here, or use the keys. For example \\frac{1}{2}';
      const view = el('div', 'mp-view'), ex = el('div', 'mp-ex', '<span class="tx">Try</span>'), bar = el('div', 'act');
      const draw = () => { const t = area.value.trim(); view.innerHTML = t ? kx(t, true) : '<i class="tx">Your equation shows here as you build it.</i>'; add.disabled = cp.disabled = !t; };
      const insert = (snip) => {
        const a = area.selectionStart, b = area.selectionEnd, sel = area.value.slice(a, b), at = snip.indexOf(CUR);
        const piece = at >= 0 ? snip.slice(0, at) + sel + snip.slice(at + 1) : snip, pos = a + (at >= 0 ? at + sel.length : piece.length);
        area.value = area.value.slice(0, a) + piece + area.value.slice(b); draw(); area.focus(); area.setSelectionRange(pos, pos);
      };
      const paintKeys = () => {
        tabs.replaceChildren(...SH.MATH_TABS.map((t) => { const b = el('button', tab === t.id ? 'on' : '', esc(t.name)); b.type = 'button'; b.setAttribute('role', 'tab'); b.setAttribute('aria-selected', String(tab === t.id)); b.onclick = () => { tab = t.id; paintKeys(); }; return b; }));
        keys.replaceChildren(...SH.MATH_TABS.find((t) => t.id === tab).items.map(([show, ins]) => { const b = el('button', 'mp-key', kx(show, false)); b.type = 'button'; b.title = ins.replace(CUR, ''); b.onclick = () => insert(ins); return b; }));
      };
      for (const [n, t] of SH.MATH_EXAMPLES) { const b = el('button', 'link', esc(n)); b.type = 'button'; b.onclick = () => { area.value = t; draw(); }; ex.appendChild(b); }
      const dsp = el('label', 'mp-dsp', '<input type="checkbox"> On its own line'); dsp.querySelector('input').onchange = (e) => { display = e.target.checked; };
      const cp = el('button', 'btn sm', 'Copy LaTeX'); cp.type = 'button'; cp.onclick = () => navigator.clipboard.writeText(area.value.trim()).then(() => { cp.textContent = 'Copied'; setTimeout(() => (cp.textContent = 'Copy LaTeX'), 1200); }, () => {});
      const add = el('button', 'btn gold sm', 'Add to message'); add.type = 'button';
      add.onclick = () => { const t = area.value.trim(); if (!t) return; closeDlg(); put(display || /\\begin|\\\\|\\tag/.test(t) ? '\n$$\n' + t + '\n$$\n' : '$' + t + '$'); };
      area.oninput = draw; bar.append(dsp, cp, add);
      box.append(tabs, keys, area, view, ex, bar); paintKeys(); draw(); openDlg('Maths keyboard', [box]); area.focus();
    }
    CX.openMaths = openMaths;

    // ------------------------------------------------------------ code check
    function openCode() {
      const box = el('div', 'cchk'); box.appendChild(el('p', 'tx', 'Paste some code and Coe finds the mistakes and shows how to fix them. Nothing is sent until you press Check.'));
      const code = el('textarea', 'mp-ta code'); code.rows = 9; code.spellcheck = false; code.setAttribute('aria-label', 'Code'); code.placeholder = 'Paste your code here';
      const sel = (S.page && S.page.editor && S.page.editor.code) || ''; if (sel) code.value = sel;
      const go = el('button', 'btn gold', 'Check my code'); go.type = 'button';
      go.onclick = () => { const c = code.value.trim(); if (!c) return code.focus(); closeDlg(); send('Find the mistakes in this code, line by line, and show the fix:\n\n```\n' + c + '\n```', { say: 'Check my code.' }); };
      box.append(code, go); openDlg('Code check', [box]); code.focus();
    }
    CX.openCode = openCode;

    // ------------------------------------------------------------ typing / at the start of a message
    const SL = (SH.SLASH || []);
    const slashRun = (c) => {
      if (c.go === 'owner') { ta().value = ''; CX.grow(); if (CX.showSettingsTab) CX.showSettingsTab('owner'); return; }
      if (c.go === 'maths') { ta().value = ''; CX.grow(); return openMaths(); }
      if (c.go === 'code') { ta().value = ''; CX.grow(); return openCode(); }
      if (c.cmd === 'questions') { ta().value = ''; CX.grow(); return CX.findQuestions(); }
      put(c.text, true);
    };
    const sl = el('ul', 'slash'); sl.id = 'slash'; sl.hidden = true; sl.setAttribute('role', 'listbox');
    let slAt = 0, slList = [];
    const slPaint = () => { sl.replaceChildren(...slList.map((c, i) => { const li = el('li'); li.setAttribute('role', 'option'); li.setAttribute('aria-selected', String(i === slAt)); const b = el('button', i === slAt ? 'on' : '', '<b>/' + esc(c.cmd) + '</b><span class="tx">' + esc(c.title) + '</span>'); b.type = 'button'; b.onmousedown = (e) => { e.preventDefault(); slashRun(c); sl.hidden = true; }; li.appendChild(b); return li; })); };
    const slUpdate = () => {
      const v = ta().value; const m = /^\/([a-z]*)$/i.exec(v);
      if (!m) { sl.hidden = true; return; }
      const q = m[1].toLowerCase(); slList = [...SL, ...(S.status && S.status.owner ? [{ cmd: 'owner', title: 'Owner tools', text: '/owner', go: 'owner' }] : [])].filter((c) => !q || c.cmd.startsWith(q) || c.title.toLowerCase().includes(q)).slice(0, 8);
      if (!slList.length) { sl.hidden = true; return; }
      slAt = Math.min(slAt, slList.length - 1); slPaint(); sl.hidden = false;
    };
    $('box').appendChild(sl);
    ta().addEventListener('input', slUpdate);
    ta().addEventListener('keydown', (e) => {
      if (sl.hidden) return;
      if (e.key === 'ArrowDown') { e.preventDefault(); slAt = (slAt + 1) % slList.length; slPaint(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); slAt = (slAt - 1 + slList.length) % slList.length; slPaint(); }
      else if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); e.stopImmediatePropagation(); const c = slList[slAt]; sl.hidden = true; slashRun(c); }
      else if (e.key === 'Escape') { sl.hidden = true; }
    }, true);

    // ------------------------------------------------------------ the command palette (Ctrl+K)
    const base = () => [
      { id: 'new', group: 'Chat', title: 'New chat', hint: 'Ctrl+Shift+O', run: () => CX.newChat(false) },
      { id: 'dict', group: 'Chat', title: 'Dictate a message', run: () => { CX.showChat(); $('mic').click(); } },
      { id: 'attach', group: 'Chat', title: 'Add a picture, sound, video or file', run: () => { CX.showChat(); $('attach').click(); } },
      { id: 'chats', group: 'Chat', title: 'Your chats', hint: 'open, search, archive', run: () => CX.openChats() },
      { id: 'temp', group: 'Chat', title: S.temp ? 'Leave the private chat' : 'Start a private (temporary) chat', run: () => CX.newChat(!S.temp) },
      { id: 'find', group: 'Chat', title: 'Find in this chat', hint: 'search the messages', run: () => CX.openFind() },
      { id: 'compact', group: 'Chat', title: 'Summarise the older messages', hint: 'keeps a long chat quick', run: compact },
      { id: 'sketch', group: 'Tools', title: 'Sketch for Coe', hint: 'opens in Coe', run: openCoe },
      { id: 'lab', group: 'Tools', title: 'Sound lab', hint: 'opens in Coe', run: openCoe },
      { id: 'screen', group: 'Tools', title: 'Look at the screen', hint: 'show Coe what is on this tab', run: () => { CX.showChat(); send('Look at the screen. Say what you see in one or two lines, then what to do next.', { shot: true, say: 'Look at the screen.' }); } },
      { id: 'math', group: 'Tools', title: 'Maths keyboard', hint: 'equations and chemistry', run: openMaths },
      { id: 'code', group: 'Tools', title: 'Code check', run: openCode },
      ...SL.filter((c) => !c.go).map((c) => ({ id: 'sl-' + c.cmd, group: 'Start with', title: c.title, hint: '/' + c.cmd, run: () => { CX.showChat(); slashRun(c); } })),
      { id: 'ex-chat-quiz', group: 'This chat', title: 'Quiz me on this chat', run: () => thisChat('Make me a quiz (a quiz block, 6 questions) on what we have talked about in this chat.', 'Quiz me on this chat.') },
      { id: 'ex-chat-cards', group: 'This chat', title: 'Make flash cards from this chat', run: () => thisChat('Make flash cards (a flashcards block, about 12 cards) from what we have talked about in this chat.', 'Make flash cards from this chat.') },
      { id: 'ex-chat-sum', group: 'This chat', title: 'Summarise this chat', run: () => thisChat('Summarise this chat in 5 short bullet points.', 'Summarise this chat.') },
      { id: 'md', group: 'Save', title: 'Save this chat as Markdown', run: saveMd },
      { id: 'pdf', group: 'Save', title: 'Save this chat as PDF', hint: 'opens the print box', run: savePdf },
      { id: 'share', group: 'Save', title: 'Share this chat as a link', hint: 'read-only', run: openShare },
      { id: 'html', group: 'Save', title: 'Save this chat as a web page', run: saveHtml },
      { id: 'keys', group: 'Help', title: 'Keyboard shortcuts', hint: 'Ctrl+/', run: openKeys },
      { id: 'acct', group: 'Account', title: 'Account', run: () => CX.showSetup() },
      { id: 'plans', group: 'Account', title: 'Plans and tokens', run: () => chrome.tabs.create({ url: CX.siteBase() + 'plans/' }) },
      { id: 'set', group: 'Account', title: 'Settings', run: () => CX.showSetup() },
    ];
    CX.addCmds(base);
    const GROUPS = ['Chat', 'Study', 'This chat', 'Tools', 'Start with', 'Save', 'Coe works as', 'Look', 'Help', 'Account'];
    function openPalette() {
      if ($('pal')) return closePalette();
      const cmds = CX.cmdSources.flatMap((f) => { try { return f(); } catch { return []; } }).sort((a, b) => GROUPS.indexOf(a.group) - GROUPS.indexOf(b.group));
      const bgd = el('div', 'pal-bg'); bgd.id = 'pal'; const box = el('div', 'pal'); box.setAttribute('role', 'dialog'); box.setAttribute('aria-label', 'Commands');
      const inp = el('input'); inp.type = 'text'; inp.placeholder = 'Do anything: quiz, save, share, switch style…'; inp.setAttribute('aria-label', 'Search commands'); inp.autocomplete = 'off';
      const head = el('div', 'pal-in'); head.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 9V6.5a2.5 2.5 0 1 0-2.5 2.5H9zm0 0h6m-6 0v6m6-6V6.5A2.5 2.5 0 1 1 17.5 9H15zm0 0v6m0 0h2.5a2.5 2.5 0 1 1-2.5 2.5V15zm0 0H9m0 0H6.5A2.5 2.5 0 1 0 9 17.5V15z"/></svg>'; head.appendChild(inp);
      const list = el('ul'); list.setAttribute('role', 'listbox'); let shown = [], at = 0;
      const go = (c) => { if (!c) return; closePalette(); setTimeout(c.run, 0); };
      const paint = () => {
        const words = inp.value.toLowerCase().split(/\s+/).filter(Boolean);
        shown = cmds.filter((c) => words.every((w) => (c.title + ' ' + c.group + ' ' + (c.hint || '')).toLowerCase().includes(w))).slice(0, 60); at = Math.min(at, Math.max(0, shown.length - 1));
        let last = ''; list.replaceChildren(...(shown.length ? shown.map((c, i) => { const li = el('li'); li.setAttribute('role', 'presentation'); if (c.group !== last) { li.appendChild(el('div', 'pal-g d', esc(c.group))); last = c.group; } const b = el('button', i === at ? 'on' : '', '<span>' + esc(c.title) + '</span>' + (c.hint ? '<small class="tx">' + esc(c.hint) + '</small>' : '') + (c.on ? '<b>' + (CX.IC ? CX.IC('check', 16) : '') + '</b>' : '')); b.type = 'button'; b.setAttribute('role', 'option'); b.setAttribute('aria-selected', String(i === at)); b.onmousemove = () => { if (at !== i) { at = i; paint(); } }; b.onclick = () => go(c); li.appendChild(b); return li; }) : [el('li', 'tx pal-none', 'Nothing matches. Try a shorter word.')]));
        const on = list.querySelector('button.on'); if (on) on.scrollIntoView({ block: 'nearest' });
      };
      inp.oninput = () => { at = 0; paint(); };
      box.onkeydown = (e) => { if (e.key === 'ArrowDown') { e.preventDefault(); at = Math.min(shown.length - 1, at + 1); paint(); } else if (e.key === 'ArrowUp') { e.preventDefault(); at = Math.max(0, at - 1); paint(); } else if (e.key === 'Enter') { e.preventDefault(); go(shown[at]); } else if (e.key === 'Escape') { e.preventDefault(); closePalette(); } };
      bgd.onpointerdown = (e) => { if (e.target === bgd) closePalette(); };
      box.append(head, list); bgd.appendChild(box); document.body.appendChild(bgd); paint(); inp.focus();
    }
    function closePalette() { const p = $('pal'); if (p) p.remove(); if (inChat()) ta().focus(); }
    CX.openPalette = openPalette;

    document.addEventListener('keydown', (e) => {
      const k = e.key.toLowerCase(), mod = e.ctrlKey || e.metaKey;
      if (mod && k === 'k') { e.preventDefault(); openPalette(); }
      else if (mod && k === '/') { e.preventDefault(); openKeys(); }
      else if (mod && e.shiftKey && k === 'o') { e.preventDefault(); CX.newChat(false); }
    });

    // ------------------------------------------------------------ the ⋯ menu: these lines join the ones in the sidebar, each with its icon
    CX.menuItems.push(
      { g: 1, icon: 'layers', label: 'Summarise the older messages', run: compact },
      { g: 2, icon: 'command', label: 'Commands', sub: 'Ctrl+K', run: openPalette },
      { g: 2, icon: 'sigma', label: 'Maths keyboard', run: openMaths },
      { g: 2, icon: 'keyboard', label: 'Keyboard shortcuts', sub: 'Ctrl+/', run: openKeys },
    );
  }

  if (CX.S) start(); else CX.ready.push(start);
})();
