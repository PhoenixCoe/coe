// Shows a saved chat as a clean page and opens the print box, so it can be saved as a PDF.
chrome.storage.local.get('printJob').then((o) => {
  const j = o && o.printJob;
  if (!j || !j.html) { document.body.textContent = 'There is nothing to print. Go back to Coe Mini and try again.'; return; }
  document.open(); document.write(j.html); document.close();
  chrome.storage.local.remove('printJob');
  setTimeout(() => window.print(), 500);
});
