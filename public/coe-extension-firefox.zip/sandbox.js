// Runs a page Coe wrote, in a box with no access to the person's data, the browser or the internet.
addEventListener('message', (e) => { if (e.source !== parent || !e.data || typeof e.data.html !== 'string') return; document.open(); document.write(e.data.html); document.close(); });
