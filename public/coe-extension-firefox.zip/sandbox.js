// Runs a page Coe wrote, or draws a diagram, in a box with no access to the person's data, the browser or the internet.
addEventListener('message', (e) => {
  if (e.source !== parent || !e.data) return;
  if (typeof e.data.html === 'string') { document.open(); document.write(e.data.html); document.close(); return; }
  if (typeof e.data.mermaid === 'string') draw(e.data.mermaid, e.data.id);
});
let loading = null;
const load = () => loading || (loading = new Promise((ok, no) => { const s = document.createElement('script'); s.src = 'mermaid.min.js'; s.onload = ok; s.onerror = no; document.head.appendChild(s); }));
async function draw(code, id) {
  try {
    await load();
    mermaid.initialize({ startOnLoad: false, securityLevel: 'strict', theme: 'neutral', flowchart: { htmlLabels: false }, fontFamily: 'Courier New, monospace' });
    const r = await mermaid.render('d' + id, code);
    parent.postMessage({ id, mermaidSvg: r.svg }, '*');
  } catch (err) { parent.postMessage({ id, mermaidErr: true }, '*'); }
}
