// The extension's brain. It holds your Coe sign-in, talks to your Coe server (the page itself never does), and keeps the answers in a fixed shape.
const store = {
  get: (k) => chrome.storage.local.get(k),
  set: (o) => chrome.storage.local.set(o),
};

/** The public settings (where the account lives, which server to ask). Coe Mini finds them on the Coe site by itself, so it never needs the site open. */
async function ensureExt() {
  const { ext, site } = await store.get(['ext', 'site']);
  if (ext && ext.sb && ext.key) return ext;
  const base = String(site || 'https://coe.pmcstudios.uk').replace(/\/+$/, '');
  try {
    const r = await fetch(base + '/coe-config.json', { cache: 'no-store' });
    if (r.ok) { const j = await r.json(); if (j && j.sb && j.key) { const e = { sb: String(j.sb).replace(/\/+$/, ''), key: String(j.key), server: String(j.server || '').replace(/\/+$/, '') }; await store.set({ ext: e }); return e; } }
  } catch { /* offline or blocked */ }
  return null;
}
const cfg = async () => {
  const s = await store.get(['session', 'ext', 'code', 'serverUrl', 'me', 'speed']);
  let server = String((s.ext && s.ext.server) || s.serverUrl || '').trim().replace(/\/+$/, '');
  if (!server) { const e = await ensureExt(); if (e) { s.ext = e; server = String(e.server || '').trim().replace(/\/+$/, ''); } }
  return { ...s, server };
};

// ---- Coe Mini signs in by itself: an emailed code, to the same account as Coe. No password.
const authHead = (key) => ({ apikey: key, ...(String(key).startsWith('sb_') ? {} : { authorization: 'Bearer ' + key }), 'content-type': 'application/json' });
const authFail = async (r) => { let m = ''; try { const j = await r.json(); m = j.msg || j.message || j.error_description || j.error || ''; } catch { /* no body */ } return m || 'That did not work. Try again.'; };
const jwtBody = (jwt) => { try { return JSON.parse(atob(String(jwt).split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))); } catch { return {}; } };
async function keepSession(j) {
  const p = jwtBody(j && j.access_token); if (!p.sub) return null;
  const session = { access: j.access_token, refresh: j.refresh_token, exp: (p.exp || 0) * 1000, email: p.email || '', uid: p.sub };
  await store.set({ session }); return session;
}
async function authSend(email) {
  const ext = await ensureExt(); if (!ext) return { ok: false, error: 'Coe Mini cannot find Coe. Check your internet and try again.' };
  try {
    const r = await fetch(ext.sb + '/auth/v1/otp', { method: 'POST', headers: authHead(ext.key), body: JSON.stringify({ email, create_user: true }) });
    return r.ok ? { ok: true } : { ok: false, error: await authFail(r) };
  } catch { return { ok: false, error: 'Could not reach Coe. Check your internet and try again.' }; }
}
async function authVerify(email, code) {
  const ext = await ensureExt(); if (!ext) return { ok: false, error: 'Coe Mini cannot find Coe. Check your internet and try again.' };
  try {
    const r = await fetch(ext.sb + '/auth/v1/verify', { method: 'POST', headers: authHead(ext.key), body: JSON.stringify({ type: 'email', email, token: String(code).trim() }) });
    if (!r.ok) return { ok: false, error: await authFail(r) };
    const s = await keepSession(await r.json()); if (!s) return { ok: false, error: 'That sign-in did not work. Try again.' };
    aboutPull().catch(() => {});   // the About you answers on the account come with it, so there is nothing to set up
    return { ok: true, email: s.email };
  } catch { return { ok: false, error: 'Could not reach Coe. Check your internet and try again.' }; }
}
async function token() {
  const { session } = await store.get('session');
  if (!session || !session.access) return null;
  if (session.exp - Date.now() > 60000) return session.access;
  const ext = await ensureExt(); if (!ext || !session.refresh) return null;
  try {
    const r = await fetch(ext.sb + '/auth/v1/token?grant_type=refresh_token', { method: 'POST', headers: authHead(ext.key), body: JSON.stringify({ refresh_token: session.refresh }) });
    if (!r.ok) { if (r.status === 400 || r.status === 401) await store.set({ session: null, connected: false }); return null; }
    const s = await keepSession(await r.json()); return s ? s.access : null;
  } catch { return null; }
}

async function call(path, init, c) {
  const h = { 'content-type': 'application/json', ...(init.headers || {}) };
  const t = await token(); if (t) h.authorization = 'Bearer ' + t;
  if (c.code) h['x-coe-code'] = c.code;
  h['x-coe-ext'] = chrome.runtime.id;   // Chrome may send no Origin for a sidebar with site access, so the server also looks at this
  return fetch(c.server + path, { ...init, headers: h });
}
const why = async (res) => { let m = '', code = ''; try { const j = await res.json(); m = j.error?.message || ''; code = j.error?.code || ''; } catch { /* no body */ } return { ok: false, error: m || `The server said ${res.status}.`, code: code || (res.status === 401 ? 'signin' : res.status === 402 ? 'limit' : '') }; };

async function feedback(m) {
  const c = await cfg(); if (!c.server) return { ok: false };
  try { const res = await call('/feedback', { method: 'POST', body: JSON.stringify({ message: String(m.message || '').trim().slice(0, 2000), kind: ['idea', 'problem', 'other'].includes(m.kind) ? m.kind : 'other', page: 'coe-mini' }) }, c); if (!res.ok) return { ok: false }; const j = await res.json().catch(() => ({})); return { ok: true, emailed: !!j.emailed }; } catch { return { ok: false }; }
}
async function status() {
  const c = await cfg();
  const { session } = await store.get('session');
  if (!c.server) return { ok: false, code: 'setup', error: 'Open Coe once and sign in, so this extension can find your Coe server.' };
  try {
    const res = await call('/me', { method: 'GET' }, c);
    if (!res.ok) return { ...(await why(res)), signedIn: !!session };
    const j = await res.json();
    return { ok: true, signedIn: !!j.signedIn, email: j.email || (session && session.email) || '', plan: j.plan, used: j.used, limit: j.limit };
  } catch { return { ok: false, code: 'network', error: 'Could not reach the Coe server.' }; }
}

const AGE = { under11: 'under 11', '11-13': '11 to 13', '14-16': '14 to 16', '17-18': '17 to 18', '19-24': '19 to 24', '25+': '25 or over' };
const ROLE = { student: 'a student', teacher: 'a teacher', parent: 'a parent or carer', working: 'working', other: '' };
/** Who Coe is talking to, from the About you answers (set here or on the Coe website). */
const mineOf = (c) => {
  const m = c.me; if (!m) return '';
  const who = [m.name && `Their name is ${m.name} (use it rarely).`, m.ageBand && AGE[m.ageBand] && `Age group: ${AGE[m.ageBand]}.`, m.role && ROLE[m.role] && `They are ${ROLE[m.role]}.`, m.yearOrJob && `Year, course or job: ${m.yearOrJob}.`, m.subjects && `They study or work on: ${m.subjects}.`].filter(Boolean).join(' ');
  const young = m.ageBand === 'under11' || m.ageBand === '11-13' ? ' They are young: use very simple words and short sentences, and keep everything suitable for children.' : '';
  const out = [];
  if (m.length === 'short') out.push('Keep answers short: the answer first, then only what is needed.'); else if (m.length === 'detailed') out.push('Give thorough answers with reasons, steps and examples.');
  if (Number(m.maxWords) > 0) out.push(`Keep every reply under ${Number(m.maxWords)} words unless the person asks for more in that message.`);
  if (m.tone === 'neutral') out.push('Keep a calm, neutral tone.'); else if (m.tone === 'formal') out.push('Write formally and politely.'); else if (m.tone === 'playful') out.push('Be light and playful, but still clear.');
  if (m.level === 'simple') out.push('Explain as if to a beginner: everyday words, small steps, no jargon without a quick meaning.'); else if (m.level === 'expert') out.push('The person is experienced: skip the basics and use the proper terms.');
  if (m.replyLang && String(m.replyLang).trim()) out.push(`Always reply in ${String(m.replyLang).trim()}, even if the person writes in another language (keep code and names as they are).`);
  const about = m.aboutText && String(m.aboutText).trim();
  const how = [about && `What the person told you about themselves (use it quietly, where it helps):\n${about.slice(0, 700)}`, out.length ? 'The person set these preferences in Settings:\n- ' + out.join('\n- ') : '', m.system && String(m.system).trim() && `How the person wants you to answer (their own instructions):\n${String(m.system).trim().slice(0, 1500)}`].filter(Boolean).join('\n\n');
  return [who && 'WHO YOU ARE TALKING TO: ' + who + young + ' Pitch your words, examples and depth to them.', how].filter(Boolean).join('\n');
};


// ---- the person's chats on their Coe account (the same table the Coe website uses). Only their own rows can be read: the database checks the sign-in.
async function sb(path, init) {
  const { ext } = await store.get('ext');
  if (!ext || !ext.sb || !ext.key) return { ok: false, code: 'setup' };
  const t = await token(); if (!t) return { ok: false, code: 'signin' };
  try {
    const r = await fetch(String(ext.sb).replace(/\/+$/, '') + '/rest/v1/' + path, { ...(init || {}), headers: { apikey: ext.key, authorization: 'Bearer ' + t, 'content-type': 'application/json', ...((init && init.headers) || {}) } });
    if (r.status === 401 || r.status === 403) return { ok: false, code: 'signin' };
    if (!r.ok) return { ok: false, code: 'other' };
    const txt = await r.text(); return { ok: true, json: txt ? JSON.parse(txt) : null };
  } catch { return { ok: false, code: 'network' }; }
}

// ---- About you lives on the account too, so signing in on any device (or Coe Mini) already knows you.
const ABOUT = ['name', 'ageBand', 'role', 'yearOrJob', 'subjects', 'length', 'easy', 'aboutText', 'system', 'tone', 'level', 'replyLang', 'maxWords', 'goal'];

/** Whole-profile helpers: the account keeps one small record per person (memory, study, styles, About you). Keys are merged, never replaced. */
async function acctGet() { const r = await sb('profiles?select=data'); return r.ok ? ((r.json && r.json[0] && r.json[0].data) || {}) : null; }
async function acctSet(patch) {
  const { session } = await store.get('session'); if (!session || !session.uid) return false;
  const cur = await acctGet(); if (cur === null) return false;
  const r = await sb('profiles?on_conflict=user_id', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }, body: JSON.stringify({ user_id: session.uid, data: { ...cur, ...patch }, updated: new Date().toISOString() }) });
  return r.ok;
}
const newShareId = () => { const a = new Uint8Array(16); crypto.getRandomValues(a); const c = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789'; return Array.from(a, (x) => c[x % c.length]).join(''); };
async function shareMake(m) {
  const { session } = await store.get('session'); if (!session || !session.uid) return { ok: false, error: 'Sign in to share a link.' };
  const data = m.data; if (!data || !Array.isArray(data.messages) || !data.messages.length) return { ok: false, error: 'There is nothing in this chat to share yet.' };
  if (JSON.stringify(data).length > 400000) return { ok: false, error: 'This chat is too long to share as one link. Share a shorter one.' };
  const id = /^[A-Za-z0-9]{12,40}$/.test(String(m.id || '')) ? m.id : newShareId();
  const r = await sb('shares?on_conflict=id', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }, body: JSON.stringify({ id, user_id: session.uid, data }) });
  return r.ok ? { ok: true, id } : { ok: false, error: r.code === 'signin' ? 'Sign in again to share a link.' : 'That could not be shared. Try again.' };
}
async function shareStop(id) { if (!/^[A-Za-z0-9]{12,40}$/.test(String(id || ''))) return { ok: false }; const r = await sb('shares?id=eq.' + encodeURIComponent(id), { method: 'DELETE' }); return { ok: r.ok }; }

async function aboutPull() {
  const r = await sb('profiles?select=data'); if (!r.ok) return;
  const ab = r.json && r.json[0] && r.json[0].data && r.json[0].data.about; if (!ab || !Number(ab.at)) return;
  const { me } = await store.get('me'); if (Number(ab.at) <= Number((me && me.at) || 0)) return;
  const next = { ...(me || {}) }; for (const k of ABOUT) if (ab[k] !== undefined) next[k] = ab[k]; next.at = Number(ab.at);
  await store.set({ me: next });
}
async function aboutPush() {
  const { me, session } = await store.get(['me', 'session']); if (!session || !session.uid || !me || !me.at) return;
  const r = await sb('profiles?select=data'); if (!r.ok) return;
  const data = (r.json && r.json[0] && r.json[0].data) || {};
  if (data.about && Number(data.about.at) >= Number(me.at)) return;
  const about = { at: Number(me.at) }; for (const k of ABOUT) about[k] = me[k];
  await sb('profiles?on_conflict=user_id', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }, body: JSON.stringify({ user_id: session.uid, data: { ...data, about }, updated: new Date().toISOString() }) });
}
const idsOk = (a) => (Array.isArray(a) ? a : []).map(String).filter((x) => /^[\w-]{1,80}$/.test(x)).slice(0, 100);
async function chatsList() {
  const r = await sb('chats?select=id,title,updated,pinned,archived:data->>archived&order=updated.desc&limit=300');
  return r.ok ? { ok: true, items: (r.json || []).map((x) => ({ id: x.id, title: String(x.title || 'Chat').slice(0, 80), t: Number(x.updated) || 0, arch: x.archived === 'true' })) } : r;
}
async function chatGet(id) {
  const [one] = idsOk([id]); if (!one) return { ok: false, code: 'other' };
  const r = await sb('chats?id=eq.' + encodeURIComponent(one) + '&select=title,data');
  const row = r.ok && r.json && r.json[0]; if (!row) return r.ok ? { ok: false, code: 'gone' } : r;
  const msgs = ((row.data && row.data.messages) || []).filter((m) => m && !m.hidden && !m.error && typeof m.text === 'string' && m.text.trim()).slice(-60).map((m) => ({ r: m.role === 'user' ? 'u' : 'a', t: m.text.slice(0, 6000), at: Number(m.ts) || 0 }));
  return { ok: true, title: String(row.title || 'Chat').slice(0, 80), msgs };
}
async function chatOp(op, ids) {
  ids = idsOk(ids); if (!ids.length) return { ok: true };
  if (op === 'delete') return sb('chats?id=in.(' + ids.map(encodeURIComponent).join(',') + ')', { method: 'DELETE' });
  if (op === 'archive' || op === 'unarchive') {
    for (const id of ids) {
      const g = await sb('chats?id=eq.' + encodeURIComponent(id) + '&select=*'); const row = g.ok && g.json && g.json[0]; if (!row) { if (!g.ok) return g; continue; }
      const data = { ...(row.data || {}), archived: op === 'archive' };
      const w = await sb('chats?on_conflict=user_id,id', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }, body: JSON.stringify({ ...row, updated: Date.now(), data }) });   // newer, so the Coe website picks the change up
      if (!w.ok) return w;
    }
    return { ok: true };
  }
  return { ok: false, code: 'other' };
}

chrome.runtime.onMessage.addListener((m, sender, reply) => {
  if (!m || !m.type) return;
  if (m.type === 'sync') {
    // Coe Mini and Coe stay separate unless the person connects them: they press Connect on Coe, and the code there matches the one Coe Mini shows.
    // Even then no sign-in is passed along. Each one signs in by itself, to the same account.
    store.get(['me', 'session', 'connected', 'pair']).then(({ me, session: mine, connected, pair }) => {
      let on = !!connected, now = false, refused = '';
      if (!on && m.connect) {
        const fresh = pair && pair.code && Date.now() - Number(pair.at) < 900000;
        if (!fresh || pair.code !== m.connect) refused = 'code';
        else if (!(mine && mine.access)) refused = 'signin';
        else if (!m.email || String(m.email).toLowerCase() !== String(mine.email || '').toLowerCase()) refused = 'account';
        else { on = true; now = true; }
      }
      const out = { site: m.site || '', coeTab: sender.tab ? sender.tab.id : null };
      if (m.ext && m.ext.sb) out.ext = m.ext;   // the public settings, so Coe Mini knows where to sign in
      let profile = null;
      if (on) {
        // The newest About you answers win, whether they were typed here or on the Coe website.
        const site = m.me || null, mn = me || null, keepMine = mn && mn.at && (!site || !site.at || mn.at > site.at);
        out.me = keepMine ? { ...(site || {}), ...mn } : site ? { ...(mn || {}), ...site } : mn;
        profile = keepMine ? mn : null;
        if (m.code) out.code = m.code; if (m.serverUrl) out.serverUrl = m.serverUrl;
      }
      if (now) { out.connected = true; out.pair = null; }
      store.set(out);
      reply({ profile, connected: on, refused });
    });
    return true;
  }
  if (m.type === 'link') { store.get('connected').then((o) => reply({ connected: !!o.connected })); return true; }
  if (m.type === 'unlink') { store.set({ connected: false, pair: null }).then(() => reply({ connected: false })); return true; }
  if (m.type === 'auth-send') { authSend(String(m.email || '').trim()).then(reply); return true; }
  if (m.type === 'auth-verify') { authVerify(String(m.email || '').trim(), m.code).then(reply); return true; }
  if (m.type === 'sign-out') { store.set({ session: null, connected: false, pair: null }).then(() => reply({ ok: true })); return true; }
  if (m.type === 'acct-get') { acctGet().then((d) => reply({ ok: d !== null, data: d || {} }), () => reply({ ok: false })); return true; }
  if (m.type === 'acct-set') { acctSet(m.patch || {}).then((ok) => reply({ ok }), () => reply({ ok: false })); return true; }
  if (m.type === 'share-make') { shareMake(m).then(reply, () => reply({ ok: false, error: 'That could not be shared. Try again.' })); return true; }
  if (m.type === 'share-stop') { shareStop(m.id).then(reply, () => reply({ ok: false })); return true; }
  if (m.type === 'about-pull') { aboutPull().then(() => reply({ ok: true }), () => reply({ ok: false })); return true; }
  if (m.type === 'about-push') { aboutPush().then(() => reply({ ok: true }), () => reply({ ok: false })); return true; }
  if (m.type === 'search') { search(m.q).then(reply); return true; }
  if (m.type === 'status') { status().then(reply); return true; }
  if (m.type === 'feedback') { feedback(m).then(reply, () => reply({ ok: false })); return true; }
  if (m.type === 'ask') { ask(m.body || {}).then(reply); return true; }
  if (m.type === 'chats-list') { chatsList().then(reply); return true; }
  if (m.type === 'chat-get') { chatGet(m.id).then(reply); return true; }
  if (m.type === 'chat-op') { chatOp(m.op, m.ids).then(reply); return true; }
  if (m.type === 'refund') { refund(m.receipts).then(reply); return true; }
  if (m.type === 'open-coe') { openCoe(m.page ? '#' + m.page : '', false); return; }
  if (m.type === 'handoff') { store.set({ handoff: { text: String(m.text || ''), ts: Date.now() } }).then(() => openCoe('', true)); return; }
});

// Brings the open Coe tab to the front, or opens one.
async function openCoe(hash, reuse) {
  const { site, coeTab } = await store.get(['site', 'coeTab']);
  const base = (site || 'https://coe.pmcstudios.uk').replace(/\/+$/, '') + '/';
  if (reuse && coeTab != null) {
    try { const t = await chrome.tabs.get(coeTab); await chrome.tabs.update(t.id, { active: true }); await chrome.windows.update(t.windowId, { focused: true }); return; } catch { /* that tab is gone */ }
  }
  chrome.tabs.create({ url: base + hash });
}

// The sidebar talks to us over a port so the reply can arrive word by word. Closing the port stops the reply.
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'chat') return;
  const ctl = new AbortController();
  port.onDisconnect.addListener(() => ctl.abort());
  port.onMessage.addListener((m) => { if (m && m.type === 'stop') ctl.abort(); else if (m && m.type === 'send') chatStream(m, port, ctl); });
});

async function chatStream(m, port, ctl) {
  const out = (o) => { try { port.postMessage(o); } catch { /* the sidebar closed */ } };
  const c = await cfg();
  if (!c.server) { out({ t: 'err', code: 'setup', error: 'Open Coe once and sign in, so this extension can find your Coe server.' }); return; }
  const mine = mineOf(c);
  const body = { model: m.model || (['swift', 'core', 'deep'].includes(c.speed) ? c.speed : 'core'), stream: true, stream_options: { include_usage: true }, max_completion_tokens: 1800, messages: [{ role: 'system', content: mine ? String(m.system || '') + '\n' + mine : String(m.system || '') }, ...(Array.isArray(m.messages) ? m.messages : [])] };
  let res;
  try { res = await call('/', { method: 'POST', body: JSON.stringify(body), signal: ctl.signal }, c); }
  catch { if (ctl.signal.aborted) { out({ t: 'end', stopped: true }); return; } out({ t: 'err', code: 'network', error: 'Could not reach the Coe server.' }); return; }
  if (!res.ok) { const w = await why(res); out({ t: 'err', code: w.code, error: w.error }); return; }
  let used = res.headers.get('x-coe-used'), limit = res.headers.get('x-coe-limit'), plan = res.headers.get('x-coe-plan');
  let receipt = '', tokens = 0, cut = false, any = false, done = false;
  try {
    const rd = res.body.getReader(), dec = new TextDecoder(); let buf = '';
    for (;;) {
      const { done: end, value } = await rd.read(); if (end) break;
      buf += dec.decode(value, { stream: true });
      let i; while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
        if (!line.startsWith('data:')) continue;
        const d = line.slice(5).trim(); if (d === '[DONE]') { done = true; continue; }
        try {
          const j = JSON.parse(d);
          if (j.coe_usage) { used = j.coe_usage.used; limit = j.coe_usage.limit; plan = j.coe_usage.plan; receipt = j.coe_usage.receipt || ''; tokens = Number(j.coe_usage.tokens) || 0; }
          if (j.error) { out({ t: 'err', code: 'server', error: String(j.error.message || 'The model stopped with an error.') }); return; }
          if (j.choices?.[0]?.finish_reason === 'length') cut = true;
          const s = j.choices?.[0]?.delta?.content; if (s) { any = true; out({ t: 'd', s }); }
        } catch { /* partial line */ }
      }
    }
  } catch { if (ctl.signal.aborted) { out({ t: 'end', stopped: true }); return; } out({ t: 'err', code: 'network', error: 'The reply was cut off. Try again.' }); return; }
  if (!done && !any) { out({ t: 'err', code: 'server', error: 'Coe did not get an answer back. Try again.' }); return; }
  out({ t: 'end', cut, receipt, tokens, credits: used != null && limit != null ? { used: Number(used), limit: Number(limit), plan } : null });
}

// A reply that went wrong is paid back by the server (it only pays back what it charged, once). The sidebar asks for it here.
async function refund(receipts) {
  const c = await cfg(); if (!c.server) return { ok: false };
  try {
    const res = await call('/refund', { method: 'POST', body: JSON.stringify({ receipts: (Array.isArray(receipts) ? receipts : []).filter((x) => typeof x === 'string').slice(0, 10) }) }, c);
    if (!res.ok) return { ok: false };
    const j = await res.json();
    return { ok: true, refunded: Number(j.refunded) || 0, used: j.used, limit: j.limit, plan: j.plan };
  } catch { return { ok: false }; }
}

// A web search for the sidebar: Coe's own server does it (it counts against the same daily searches as the Coe website).
async function search(q) {
  const c = await cfg(); if (!c.server) return { ok: false, error: 'Open Coe once and sign in, so this can find your Coe server.' };
  const query = String(q || '').slice(0, 300).trim(); if (!query) return { ok: false, error: 'There was nothing to search for.' };
  try {
    const res = await call('/search', { method: 'POST', body: JSON.stringify({ q: query }) }, c);
    if (!res.ok) { const w = await why(res); return { ok: false, error: w.code === 'limit' ? 'Today’s web searches are used up.' : w.code === 'signin' ? 'Sign in to Coe to search the web.' : w.error }; }
    const j = await res.json();
    return { ok: true, text: String(j.text || '').slice(0, 6000), sources: (Array.isArray(j.sources) ? j.sources : []).filter((x) => x && /^https?:/.test(x.url)).slice(0, 8).map((x) => ({ title: String(x.title || x.url).slice(0, 120), url: x.url })) };
  } catch { return { ok: false, error: 'Could not reach the Coe server.' }; }
}

// ---- where the panel lives. Chrome, Edge and Brave have a real side panel. Firefox has a sidebar. Any other browser gets the same panel in a small window on the right.
// Opera and Vivaldi may define the side panel API without showing a panel, so they get the small window on the right instead.
const NO_PANEL_UI = (() => { try { return /OPR\//.test(navigator.userAgent) || (navigator.userAgentData && navigator.userAgentData.brands || []).some((b) => /vivaldi|opera/i.test(b.brand)); } catch { return false; } })();
const HAS_PANEL = !!(chrome.sidePanel && chrome.sidePanel.setPanelBehavior) && !NO_PANEL_UI;
const FIREFOX = typeof browser !== 'undefined' && !!(browser.sidebarAction && browser.sidebarAction.toggle);
if (HAS_PANEL) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  chrome.runtime.onInstalled.addListener(() => { chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {}); });
  chrome.commands.onCommand.addListener((c, tab) => { if (c === 'toggle-coe' && tab && tab.id != null) chrome.sidePanel.open({ tabId: tab.id }).catch(() => {}); });
} else if (FIREFOX) {
  chrome.action.onClicked.addListener(() => { browser.sidebarAction.toggle().catch(() => {}); });   // Firefox also has its own shortcut, set in the manifest
} else {
  const popout = async (tab) => {
    try {
      const wins = await chrome.windows.getAll({ populate: true, windowTypes: ['popup'] });
      const mine = wins.find((w) => (w.tabs || []).some((t) => (t.url || '').startsWith(chrome.runtime.getURL('sidepanel.html'))));
      if (mine) { await chrome.windows.update(mine.id, { focused: true }); return; }
      const w = await chrome.windows.get(tab && tab.windowId != null ? tab.windowId : chrome.windows.WINDOW_ID_CURRENT);
      const width = 430, left = Math.max(0, (w.left || 0) + (w.width || 1200) - width);
      await chrome.windows.create({ url: chrome.runtime.getURL('sidepanel.html') + '?win=' + w.id, type: 'popup', width, height: w.height || 800, left, top: w.top || 0 });
    } catch { /* the browser would not open it */ }
  };
  chrome.action.onClicked.addListener((tab) => popout(tab));
  chrome.commands.onCommand.addListener((c, tab) => { if (c === 'toggle-coe') popout(tab); });
}
