// The Coe sidebar. It sits next to the page you are on, reads it only when you ask, and answers in the Coe look.
// It changes a page only after you press a button on a card that shows exactly what will change.
(() => {
  const $ = (id) => document.getElementById(id);
  // The parity layer (more.js) plugs in through this: extra reply blocks, extra prompt lines, extra menu items and screens.
  const CX = window.CX = { blocks: {}, titles: {}, system: [], ready: [], on: {} };
  const store = chrome.storage.local;
  const FORCE_TAB = Number(new URLSearchParams(location.search).get('tab')) || null;   // used for testing: look at one particular tab
  const WIN = Number(new URLSearchParams(location.search).get('win')) || null;   // when this opens as a small window, the browser window it belongs to
  const FF = /firefox/i.test(navigator.userAgent);
  // Pages where a teacher set the work, or where a quiz or game is live. Coe explains, hints and checks there. It never types into them.
  const SCHOOLWORK = /sparx|seneca|smart-?revise|go-?code|blooket|kahoot|gimkit|quizizz|wayground|edpuzzle|educake|hegarty|tassomai|century\.tech|mathswatch|drfrost|kerboodle|socrative|nearpod|classroom\.google|forms\.(gle|office|microsoft)|instructure/i;
  const hostOf = (u) => { try { return new URL(u).hostname; } catch { return ''; } };
  const isSchool = (u) => { try { const x = new URL(u); return SCHOOLWORK.test(x.hostname) || (/(^|\.)google\.com$/.test(x.hostname) && /^\/forms\//.test(x.pathname)) || /\/mod\/quiz\//.test(x.pathname) || (/docs\.google\.com/.test(x.hostname) && /^\/forms\//.test(x.pathname)); } catch { return false; } };
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const S = { tab: null, page: null, scope: 'page', msgs: [], atts: [], busy: false, port: null, status: null, shot: null, pending: null, setupDone: false, queue: [], tx: [], chatId: 'c' + Date.now().toString(36), askTabs: 'ask', askChg: 'ask', qs: null, me: {}, temp: false, find: '', fi: 0, beep: true, ch: { q: '', sel: false, picked: new Set(), arch: false, remote: null, confirm: false } };
  const QUICK = [
    ['Find the questions', '', { act: 'questions' }],
    ['Explain this page', 'Explain this page in simple words.'],
    ['Summarise', 'Summarise this page in five short points.'],
    ['Practice questions', 'Make five practice questions from this page. Put the answers at the end under a heading called Answers.', { say: 'Make practice questions from this page.' }],
    ['Explain my selection', 'Explain the part I selected in simple words.'],
    ['Highlight key points', 'Highlight the most important points on this page.'],
    ['Look at the screen', 'Look at the screen. Say what you see in one or two lines, then what to do next.', { shot: true, say: 'Look at the screen.' }],
  ];
  const SYS = [
    'You are Coe Mini, the Coe study helper in the browser sidebar, made by PMC Studios. You sit next to the web page the person is on. Be accurate, quick and kind.',
    'WHAT YOU CAN SEE: only what is written under "THE PAGE THE STUDENT IS ON" below. Coe read it just now, when the message was sent. It has the page title and address, the page text (all of it, or only what was on screen: it says which), any words they selected, the boxes on the page and what is in them, and code in a code editor. If a picture is attached, it shows what was on screen. You cannot see other tabs, videos, sound, or pictures on the page unless a screenshot is attached.',
    'WHAT YOU CAN DO: explain, summarise, make practice questions, check work, translate, find mistakes, rewrite words or code, and say what is in a screenshot (a record, a plant, a product, a diagram). The student can press Find the questions to list the questions on a page. You can search the web (see SEARCHING). With their OK you can change text on the page, highlight words and open a new tab. You cannot click, scroll, type, submit anything or use other tabs yourself. If asked, say so in one sentence and say what to click instead.',
    'HOW TO ANSWER: put the answer first, in short plain words. British spelling. No greeting, no "Great question", no closing offer, no repeating yourself. Say where an answer comes from when it matters ("The page says..."). If the page does not have what is needed, say so once, then what to try (select the words, switch between Whole page and On screen, or press Look at the screen). Never make up what the page says or what is on it. If you are not sure, say so.',
    'WHEN SOMETHING DID NOT WORK: say so once, in one plain sentence that includes the reason, then one thing to try. Never say you changed, marked, opened or saw something unless that is true.',
    'CHANGING THE PAGE: only when asked (rewrite a sentence, fix code, edit a slide). Give one or two lines, then exactly one block:\n```coe-edit\n{"find":"the exact words on the page to replace, copied exactly from the page text, or an empty string to replace what they selected","text":"the new words"}\n```\nIf you cannot copy the exact words, ask them to select the words first and use an empty find. The student presses a button to put it in. Never say you changed the page.',
    'HIGHLIGHTING: when asked to highlight, give one block with short exact phrases from the page (at most 12):\n```coe-highlight\n{"phrases":["exact words"]}\n```',
    'OPENING A TAB: only when it really helps (a shop, a source, a video). One block:\n```coe-open\n{"url":"https://example.com/page","why":"five words"}\n```\nor, to search: {"search":"words to search","why":"five words"}. The student is asked first. Never say you opened it.',
    'SEARCHING: when you need current facts, or to find where to buy or read something, give one block and stop writing:\n```coe-search\n{"q":"search words"}\n```\nCoe runs it and sends the results back to you. At most twice per question. Name the sites you use.',
    'MATHS AND SCIENCE: write maths in LaTeX between dollar signs: $x^2$ in a line, and $$ ... $$ on their own lines for a big one (fractions, roots, sums, integrals, matrices, working with several steps). Chemistry: $\\ce{2H2 + O2 -> 2H2O}$ and $\\ce{H2O}$. Units: $\\pu{9.8 m s^-2}$. Never use dollar signs for money: write 5 pounds or 5 dollars. Never put LaTeX inside a code block.',
    'THINGS YOU CAN DRAW (no box is drawn round them, so give each a short title in the first line of the block where it fits): a mind map, as an indented outline in a block called mindmap (the first line is the middle, each step of two spaces goes one level deeper, at most 4 levels):\n```mindmap\nPhotosynthesis\n  Inputs\n    Light\n    Water\n  Outputs\n    Glucose\n```\nA quiz: a block called quiz with JSON {"title":"","questions":[{"q":"","options":["a","b","c"],"answer":0,"why":"one line"}]} (answer is the number of the right option, counting from 0). Flash cards: a block called flashcards with JSON {"title":"","cards":[{"front":"","back":""}]}. A chart: a block called chart with JSON {"type":"bar" or "line","title":"","labels":["a","b"],"series":[{"name":"","data":[1,2]}]}. A diagram or picture: a block called svg holding one complete SVG picture (no scripts). Use these when they help, not for every answer.',
    'PICTURES: when a screenshot is attached you can identify what is in it. Say what it is and how sure you are in one line. For a product (a record, a game, a gadget), say what it is, then search for where to buy it.',
  ].join('\n\n');
  const SCHOOL = '\n\nTHIS PAGE IS SET WORK OR A QUIZ. Help the student learn it: explain the idea, give a hint first, and check the answer they tried. Do not hand over the final answer to a set question. Never give coe-edit blocks on this page, and never type into it.';

  // ------------------------------------------------------------------ small helpers
  const icon = (d) => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '"/></svg>';
  const X = icon('M6 6l12 12M18 6L6 18');
  function el(tag, cls, html) { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  const ext = (n) => (/\.([a-z0-9]{1,5})$/i.exec(n) || [])[1] || '';
  const first = (t, n) => String(t).replace(/\s+/g, ' ').trim().slice(0, n || 110);

  // ------------------------------------------------------------------ one problem box, never two
  const ERR = {
    credits: { t: 'Out of tokens', x: 'Today’s tokens are used up. They come back at midnight (UTC).', a: ['See plans', () => chrome.tabs.create({ url: siteBase() + 'plans/' })], lvl: 'warn' },
    signin: { t: 'Sign in to continue', x: 'Sign in to Coe Mini. It uses the same account as Coe.', a: ['Sign in', () => showSignin('a')], lvl: 'warn' },
    setup: { t: 'Not signed in yet', x: 'Sign in to Coe Mini. Then this sidebar is ready.', a: ['Sign in', () => showSignin('a')], lvl: 'warn' },
    network: { t: 'Cannot reach Coe', x: 'Check your internet, then try again.', a: ['Try again', () => retry()], lvl: 'warn' },
    noq: { t: 'No questions found', x: 'Open a page that has questions, or press Look at the screen.', lvl: 'warn' },
    page: { t: 'Cannot read this page', x: 'Open a website, then try again. Chrome keeps its own pages private.', lvl: 'warn' },
    other: { t: 'Something went wrong', x: 'Try again in a moment.', a: ['Try again', () => retry()], lvl: 'red' },
  };
  let site = 'https://coe.pmcstudios.uk/';
  const siteBase = () => site.replace(/\/+$/, '') + '/';
  function showErr(code, text) {
    const k = code === 'limit' || code === 'credits' ? 'credits' : ERR[code] ? code : 'other';
    const e = ERR[k], box = el('div', 'cx-err ' + (e.lvl === 'red' ? 'red' : ''), '<span class="i" aria-hidden="true">!</span><h3 class="d">' + esc(e.t) + '</h3><p class="tx" title="">' + esc(k === 'other' && text ? text : e.x) + '</p>');
    box.setAttribute('role', 'alert');
    box.querySelector('p').onclick = () => box.classList.toggle('open');
    if (e.a) { const b = el('button', 'btn sm' + (e.lvl === 'warn' ? ' gold' : ''), esc(e.a[0])); b.type = 'button'; b.onclick = e.a[1]; box.appendChild(b); }
    $('err').replaceChildren(box);   // replaces whatever was there
    S.errKind = k; paintSend(); paintQuick();
  }
  const clearErr = () => { $('err').replaceChildren(); S.errKind = ''; paintSend(); paintQuick(); };

  // ------------------------------------------------------------------ the page we are next to
  async function activeTab() {
    if (FORCE_TAB) return chrome.tabs.get(FORCE_TAB).catch(() => null);
    const [t] = await chrome.tabs.query(WIN ? { active: true, windowId: WIN } : { active: true, lastFocusedWindow: true });
    if (t) return t;
    const [u] = await chrome.tabs.query({ active: true, currentWindow: true }); return u || null;
  }
  async function refreshTab() { const old = S.tab && S.tab.url; S.tab = await activeTab(); if (!S.tab || S.tab.url !== old) S.page = null; paintPage(); }
  chrome.tabs.onActivated.addListener(refreshTab);
  chrome.tabs.onUpdated.addListener((id, ch) => { if (S.tab && id === S.tab.id && (ch.title || ch.url || ch.status === 'complete')) refreshTab(); });
  chrome.windows.onFocusChanged.addListener(refreshTab);

  function paintPage() {
    const t = S.tab, ok = t && /^https?:/.test(t.url || '');
    $('pt1').textContent = t ? (t.title || hostOf(t.url) || 'This page') : 'No page';
    $('pt2').textContent = ok ? hostOf(t.url) : 'Coe reads websites';
    const read = S.page && t && S.page.url === t.url;
    $('pst').textContent = !ok ? 'Cannot read' : read ? 'Read' : 'Not read yet'; $('pst').className = 'pst tx' + (read ? ' on' : '');
    const th = $('pth'); if (S.shot && read) { th.style.backgroundImage = 'url(' + S.shot + ')'; th.classList.add('has'); } else { th.style.backgroundImage = ''; th.classList.remove('has'); }
    const school = ok && isSchool(t.url);
    paintSend();
    paintQuick();
  }

  async function capture() {
    try { return await chrome.tabs.captureVisibleTab(S.tab ? S.tab.windowId : undefined, { format: 'jpeg', quality: 60 }); } catch { return null; }
  }
  async function noAccess(t) {
    const o = new URL(t.url).origin + '/*';
    return { code: 'allow', origin: o };
  }
  async function runInTab(func, args, world) {
    const t = S.tab; if (!t) throw { code: 'page' };
    const r = await chrome.scripting.executeScript({ target: { tabId: t.id }, func, args: args || [], ...(world ? { world } : {}) });
    return r && r[0] && r[0].result;
  }
  /** Reads the page you are on. This is the only place the sidebar looks at a page. */
  async function readTab(scope) {
    const t = S.tab;
    if (!t || !/^https?:/.test(t.url || '')) throw { code: 'page' };
    const run = async (func, args, world) => { const r = await chrome.scripting.executeScript({ target: { tabId: t.id }, func, args: args || [], ...(world ? { world } : {}) }); return r && r[0] && r[0].result; };
    let page;
    try { page = await run(coeReadPage, [scope]); } catch { throw await noAccess(t); }
    if (!page) throw { code: 'page' };
    if (hostOf(t.url) === 'docs.google.com') { const d = await run(coeReadDoc).catch(() => null); if (d && d.text) { page.docKind = d.kind; page.text = d.text; } }
    try { const ed = await run(coeReadEditor, [], 'MAIN'); if (ed) page.editor = ed; } catch { /* no editor */ }
    page.scope = scope; S.page = page;
    S.shot = await capture();   // null when Chrome will not let us, so an old picture is never shown for a new page
    paintPage(); return page;
  }
  function contextOf(p) {
    const b = ['PAGE TITLE: ' + p.title, 'ADDRESS: ' + p.url, 'WHAT WAS READ: ' + (p.docKind ? 'the words in a Google file' : p.scope === 'screen' ? 'only the text on screen' : 'the whole page') + (p.cut ? ', cut short because the page is long' : '') + ' (' + String((p.text || '').length) + ' letters)'];
    if (p.selection) b.push('THE STUDENT HAS SELECTED THIS TEXT:\n' + p.selection);
    if (p.editor) b.push('CODE IN THE ' + p.editor.editor.toUpperCase() + ' EDITOR' + (p.editor.lang ? ' (' + p.editor.lang + ')' : '') + ':\n' + p.editor.code + (p.editor.selection ? '\n\nSELECTED IN THE EDITOR:\n' + p.editor.selection : ''));
    b.push((p.docKind ? 'THE WORDS IN THIS GOOGLE ' + ({ document: 'DOC', presentation: 'SLIDES FILE', spreadsheets: 'SHEET' }[p.docKind] || 'FILE') : p.scope === 'screen' ? 'TEXT ON THE PAGE (only what is on screen)' : 'TEXT ON THE PAGE') + ':\n' + p.text + (p.cut ? '\n[The page was cut short.]' : '') + (!(p.text || '').trim() ? '\n[No text could be read from this page.]' : ''));
    if (p.fields && p.fields.length) b.push('BOXES ON THE PAGE:\n' + p.fields.map((f) => '- ' + (f.label || 'box') + ': ' + (f.value || '(empty)')).join('\n'));
    return b.join('\n\n');
  }

  // ------------------------------------------------------------------ talking to the Coe server
  let rafId = 0;
  function connect() {
    const port = chrome.runtime.connect({ name: 'chat' }); S.port = port;
    port.onDisconnect.addListener(() => { if (S.port === port) S.port = null; });
    return port;
  }
  function modelMessages() {
    const lastUsers = S.msgs.filter((m) => m.role === 'user' && !m.hidden).slice(-2);   // old pictures are not sent again
    return S.msgs.filter((m) => !m.skip && !m.kind).map((m) => {
      if (m.role === 'assistant') return { role: 'assistant', content: m.text };
      const parts = (lastUsers.includes(m) ? m.images || [] : []).map((u) => ({ type: 'image_url', image_url: { url: u } }));
      return { role: 'user', content: parts.length ? [...parts, { type: 'text', text: m.send || m.text }] : (m.send || m.text) };
    }).filter((m) => !(m.role === 'assistant' && !m.content));
  }
  let lastSend = null;
  const retry = () => { if (lastSend) { clearErr(); send(lastSend.text, lastSend.opts, true); } };
  const tell = (role, text) => { const t = String(text || '').trim(); if (t) { S.tx.push({ r: role, t: t.slice(0, 6000), at: Date.now() }); saveChat(); } };

  /** Sends what the person typed. While Coe is still working, it waits its turn (or goes first if they press Send now). */
  async function send(text, opts, again) {
    text = String(text || '').trim(); opts = opts || {};
    if (S.busy) {
      if (!text || again) return;
      if (S.queue.length >= 3) { showErr('other', 'Wait for Coe to catch up, then send that again.'); return; }
      S.queue.push({ text, opts, atts: S.atts.slice() }); S.atts = []; paintAtts(); $('ta').value = ''; grow(); paintQueue(); if (S.whileBusy === 'interrupt') sendNow(); return;
    }
    if (!text && !S.atts.length) return;
    if (S.errKind === 'credits') return;   // the one box above already says so
    clearErr(); lastSend = { text, opts };
    let mine;
    if (again) { mine = [...S.msgs].reverse().find((m) => m.role === 'user' && !m.hidden); S.msgs = S.msgs.filter((m) => m.role === 'user' || m.text); }
    else {
      const docs = S.atts.filter((x) => !x.img);
      mine = { role: 'user', text: opts.say || text, send: docs.map((d) => '[File: ' + d.name + ']\n' + d.text).join('\n\n') + (docs.length ? '\n\n' : '') + text, images: S.atts.filter((x) => x.img).map((x) => x.img), atts: S.atts.slice(), at: Date.now() };
      S.msgs.push(mine); S.atts = []; paintAtts(); $('ta').value = ''; grow(); tell('u', mine.text); CX.sfx && CX.sfx.send();
    }
    if (!mine) return;
    await turn(mine, text, opts);
  }

  /** One question from the person, and Coe's answer to it (which may include a web search along the way). */
  async function turn(mine, text, opts) {
    S.busy = true; S.phase = 'Reading the page'; S.stopped = false; S.searches = 0; paintSend(); renderMsgs(true); paintQueue();
    let page = null;
    try { page = await readTab(S.scope); }
    catch (e) {
      S.busy = false; S.phase = ''; paintSend();
      if (e && e.code === 'allow') { S.pending = () => send(text, opts, true); renderMsgs(); addAllowCard(e.origin); return; }
      S.msgs.pop(); $('ta').value = opts.say || opts.act ? '' : text; grow(); renderMsgs(); showErr((e && e.code) || 'other'); return;
    }
    if (opts.shot && S.shot) mine.images = [S.shot];
    const school = isSchool(page.url);
    const system = SYS + (CX.system.map((f) => { try { return f(); } catch { return ''; } }).filter(Boolean).map((x) => '\n\n' + x).join('')) + (school ? SCHOOL : '') + '\n\nTHE PAGE THE STUDENT IS ON\n' + contextOf(page);
    let bot = { role: 'assistant', text: '', at: Date.now() };
    S.msgs.push(bot); S.phase = opts.shot ? 'Looking at the screen' : 'Thinking'; renderMsgs();
    for (let n = 0; ; n++) {
      const ok = await streamReply(bot, system);
      if (!ok) break;
      const q = n < 2 && firstBlock(bot.text, 'coe-search');
      if (!q || !q.q) break;
      S.searches++; bot.search = { q: String(q.q).slice(0, 160), state: 'run' }; S.phase = 'Searching the web'; renderMsgs();
      const r = await webSearch(bot.search.q);
      bot.search = r.ok ? { q: bot.search.q, state: 'ok', sources: r.sources } : { q: bot.search.q, state: 'bad', why: r.error };
      S.msgs.push({ role: 'user', hidden: true, text: '', send: r.ok ? '[Result of the web search for "' + bot.search.q + '"]\n' + r.text + '\n\nSources:\n' + r.sources.map((x) => '- ' + x.title + ': ' + x.url).join('\n') + '\n\nAnswer from this. Name the sites you use. If it does not settle the question, say so.' : '[The web search FAILED: ' + r.error + ' Nothing was found. Say once, in one short sentence, that you could not search and why. Then answer from what you can see or know, and say it may be out of date.]' });
      bot = { role: 'assistant', text: '', at: Date.now() }; S.msgs.push(bot); S.phase = 'Thinking'; renderMsgs();
    }
    if (CX.check && !S.stopped && String(bot.text || '').trim()) { try { await CX.check(bot, text); } catch { S.phase = ''; } }
    S.busy = false; S.phase = ''; paintSend(); renderMsgs(); paintQuick(); paintQueue();
    if (!S.stopped && String(bot.text || '').trim()) { replyReady(); CX.sfx && CX.sfx.done(); }
    const intr = S.interrupt; S.interrupt = null;
    if (intr && intr.length) { S.queue = intr.slice(1); S.stopped = false; const nx = intr[0]; S.atts = nx.atts || []; paintAtts(); paintQueue(); send(nx.text, nx.opts); }
    else if (!S.stopped && S.queue.length) { const nx = S.queue.shift(); S.atts = nx.atts || []; paintAtts(); paintQueue(); send(nx.text, nx.opts); }
    else if (S.stopped) { S.queue = []; paintQueue(); }
  }

  /** Streams one reply from the Coe server into `bot`. Resolves true when it finished well, false when it was stopped or went wrong. */
  function streamReply(bot, system) {
    return new Promise((done) => {
      const port = connect(); let over = false;
      port.onMessage.addListener((m) => {
        if (over) return;
        if (m.t === 'd') { if (S.phase) S.phase = ''; bot.text += m.s; if (!rafId) rafId = requestAnimationFrame(() => { rafId = 0; renderMsgs(); }); }
        else if (m.t === 'end') {
          over = true; bot.receipts = [...(bot.receipts || []), ...(m.receipt ? [m.receipt] : [])]; bot.receipt = m.receipt || ''; bot.tokens = (bot.tokens || 0) + (m.tokens || 0); bot.cut = !!m.cut; bot.stopped = !!m.stopped;
          try { port.disconnect(); } catch { /* done */ } if (m.credits) setMeter(m.credits);
          if (m.stopped) S.stopped = true;
          renderMsgs(); checkReply(bot); if (!m.stopped && String(bot.text || '').trim()) tell('a', bot.text);
          done(!m.stopped && !!String(bot.text || '').trim());
        } else if (m.t === 'err') {
          over = true; try { port.disconnect(); } catch { /* done */ } S.msgs = S.msgs.filter((x) => x !== bot); S.busy = false; S.phase = ''; if (m.credits) setMeter(m.credits);
          S.stopped = true; showErr(m.code, m.error); paintSend(); renderMsgs(); done(false);
        }
      });
      port.postMessage({ type: 'send', system, messages: modelMessages() });
    });
  }
  function stop() { S.queue = []; paintQueue(); if (S.port) { try { S.port.postMessage({ type: 'stop' }); } catch { /* gone */ } } }
  /** Stops what Coe is doing and sends the waiting message straight away. */
  function sendNow() { if (!S.busy || !S.queue.length) return; S.stopped = false; const q = S.queue; S.queue = []; S.interrupt = q; if (S.port) { try { S.port.postMessage({ type: 'stop' }); } catch { /* gone */ } } }
  const firstBlock = (t, tag) => { const m = new RegExp('```' + tag + '[ \\t]*\\n([\\s\\S]*?)```').exec(String(t || '')); if (!m) return null; try { return JSON.parse(m[1]); } catch { return null; } };
  function webSearch(q) { return new Promise((ok) => chrome.runtime.sendMessage({ type: 'search', q }, (r) => ok(chrome.runtime.lastError || !r ? { ok: false, error: 'Could not reach Coe.' } : r))); }

  // ------------------------------------------------------------------ what the chat shows
  // ---- proper maths (KaTeX, bundled in this extension), chemistry and units
  const KX = { throwOnError: false, strict: 'ignore', trust: false, maxExpand: 1000, output: 'html' };
  function texHtml(tex, display) {
    try {
      if (!window.katex) throw 0;
      return '<span class="mx" data-tex="' + esc(tex.trim()) + '" title="Press to copy the maths">' + window.katex.renderToString(tex.trim(), { ...KX, displayMode: !!display }) + '</span>';
    } catch { return '<code>' + esc(tex) + '</code>'; }
  }
  let DISP = [];   // big (display) maths found in the reply being drawn, by number
  function mdInline(raw) {
    const hold = [], put = (h) => { hold.push(h); return '' + (hold.length - 1) + ''; };
    let t = String(raw).replace(/\\\$/g, '');
    t = t.replace(/`([^`\n]+)`/g, (m, c) => put('<code>' + esc(c) + '</code>'));
    t = t.replace(/(\d+)/g, (m, i) => put(DISP[+i] || ''));
    t = t.replace(/\\\((.+?)\\\)/g, (m, x) => put(texHtml(x, false)));
    t = t.replace(/\$\$([^\n]+?)\$\$/g, (m, x) => put(texHtml(x, false)));
    // a dollar pair is maths only when it hugs its words and a number does not follow: so "$5 and $6" stays money
    t = t.replace(/(?<![\\$])\$(?![\s$])((?:\\.|[^$\\\n])+?)(?<![\s\\])\$(?!\d)/g, (m, x) => put(texHtml(x, false)));
    let h = esc(t).replace(/\*\*([^*\n]+)\*\*/g, '<b>$1</b>').replace(/(^|[\s(])\*([^*\n]+)\*(?=[\s).,!?:;]|$)/g, '$1<i>$2</i>')
      .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
    return h.replace(/(\d+)/g, (m, i) => hold[+i]).replace(//g, '$');
  }
  function mdBlock(text) {
    DISP = [];
    const keepD = (x) => { DISP.push(texHtml(x, true)); return '\n' + (DISP.length - 1) + '\n'; };
    text = String(text).replace(/\$\$([\s\S]+?)\$\$/g, (m, x) => keepD(x)).replace(/\\\[([\s\S]+?)\\\]/g, (m, x) => keepD(x))
      .replace(/(^|\n)[ \t]*(\\begin\{(align\*?|aligned|equation\*?|gather\*?|cases|[pbvBV]?matrix)\}[\s\S]+?\\end\{\3\})/g, (m, lead, body) => lead + keepD(body));
    const out = []; let list = null, para = [];
    const flushP = () => { if (para.length) { out.push('<p>' + para.map(mdInline).join('<br>') + '</p>'); para = []; } };
    const flushL = () => { if (list) { out.push('<' + list.t + '>' + list.items.map((i) => '<li>' + mdInline(i) + '</li>').join('') + '</' + list.t + '>'); list = null; } };
    const lines = text.split('\n');
    for (let li = 0; li < lines.length; li++) {
      const line = lines[li]; let m;
      if ((m = /^\s*(\d+)\s*$/.exec(line))) { flushP(); flushL(); out.push(DISP[+m[1]]); continue; }
      if (/^\s*\|.*\|\s*$/.test(line) && /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(lines[li + 1] || '')) {
        flushP(); flushL();
        const cells = (x) => x.trim().replace(/^\||\|$/g, '').split('|').map((c) => c.trim());
        const head = cells(line); const rows = []; li += 2;
        while (li < lines.length && /^\s*\|.*\|\s*$/.test(lines[li])) { rows.push(cells(lines[li])); li++; }
        li--; out.push('<table><thead><tr>' + head.map((c) => '<th>' + mdInline(c) + '</th>').join('') + '</tr></thead><tbody>' + rows.map((r) => '<tr>' + r.map((c) => '<td>' + mdInline(c) + '</td>').join('') + '</tr>').join('') + '</tbody></table>');
        continue;
      }
      if ((m = /^\s{0,3}(#{1,4})\s+(.*)$/.exec(line))) { flushP(); flushL(); out.push('<h4>' + mdInline(m[2]) + '</h4>'); }
      else if ((m = /^\s*[-*]\s+(.*)$/.exec(line))) { flushP(); if (!list || list.t !== 'ul') { flushL(); list = { t: 'ul', items: [] }; } list.items.push(m[1]); }
      else if ((m = /^\s*\d+[.)]\s+(.*)$/.exec(line))) { flushP(); if (!list || list.t !== 'ol') { flushL(); list = { t: 'ol', items: [] }; } list.items.push(m[1]); }
      else if (!line.trim()) { flushP(); flushL(); }
      else { flushL(); para.push(line); }
    }
    flushP(); flushL(); return out.join('');
  }
  /** Splits a reply into words, code blocks, the cards (change this, highlight this) and the pictures Coe draws. */
  const BLK = ['mindmap', 'quiz', 'flashcards', 'cards', 'chart', 'svg'];
  CX.BLK = BLK;
  function parts(text) {
    const out = []; const re = /```([a-z-]*)[ \t]*\n([\s\S]*?)(```|$)/g; let at = 0, m;
    while ((m = re.exec(text))) {
      if (m.index > at) out.push({ k: 'text', s: text.slice(at, m.index) });
      const closed = m[3] === '```';
      if (m[1] === 'coe-edit' || m[1] === 'coe-highlight' || m[1] === 'coe-open' || m[1] === 'coe-search') { let j = null; if (closed) { try { j = JSON.parse(m[2]); } catch { /* not valid */ } } out.push({ k: m[1], j, closed }); }
      else if (BLK.includes(m[1])) out.push({ k: 'blk', lang: m[1] === 'cards' ? 'flashcards' : m[1], s: m[2].replace(/\n$/, ''), closed });
      else out.push({ k: 'code', lang: m[1], s: m[2].replace(/\n$/, '') });
      at = m.index + m[0].length;
    }
    if (at < text.length) out.push({ k: 'text', s: text.slice(at) });
    return out;
  }

  // ---- what Coe draws in a reply: no box and no border, only a title (the same idea as on the Coe website)
  const msgsWidth = () => { const b = $('msgs'), cs = getComputedStyle(b); return Math.max(200, Math.min(820, b.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight))); };
  const jsonOf = (t) => { try { return JSON.parse(t); } catch { return null; } };
  const cleanSvg = (t) => {
    const x = String(t).trim(); if (!/^<svg[\s>]/i.test(x) || !/<\/svg>\s*$/i.test(x)) return '';
    if (/<script|<foreignObject|<iframe|<object|<embed|\son\w+\s*=|javascript:|<!ENTITY|<link|<style[^>]*@import/i.test(x)) return '';
    return /xmlns=/.test(x) ? x : x.replace(/^<svg/i, '<svg xmlns="http://www.w3.org/2000/svg"');
  };
  function saveFile(name, text, type) { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: type || 'text/plain' })); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); }
  const bkBtn = (label, f) => { const b = el('button', 'btn sm', esc(label)); b.type = 'button'; b.onclick = f; return b; };
  function chartSvg(spec) {
    if (CX.chart) { const r = CX.chart(spec); if (r) return r; }
    const series = (spec.series || (spec.data ? [{ name: '', data: spec.data }] : [])).filter((x) => x && Array.isArray(x.data) && x.data.length).slice(0, 6);
    if (!series.length) return '';
    const num = (v) => (Array.isArray(v) ? Number(v[1]) : Number(v)) || 0, labels = (spec.labels || series[0].data.map((_, i) => String(i + 1))).map(String);
    const W = 640, H = 360, L = 56, R = 12, T = 14, B = 70, pw = W - L - R, ph = H - T - B;
    const all = series.flatMap((x) => x.data.map(num)), max = Math.max(0, ...all), min = Math.min(0, ...all), span = (max - min) || 1;
    const nice = (() => { const raw = span / 5, p = Math.pow(10, Math.floor(Math.log10(raw))), f = raw / p; return (f < 1.5 ? 1 : f < 3.5 ? 2 : f < 7.5 ? 5 : 10) * p; })();
    const top = Math.ceil(max / nice) * nice, bot = Math.floor(min / nice) * nice, rng = (top - bot) || 1;
    const Y = (v) => T + ph - ((v - bot) / rng) * ph, COLS = ['#337957', '#B49A57', '#1A4934', '#6FB894', '#A33A2B', '#171717'];
    let g = '';
    for (let v = bot; v <= top + nice / 2; v += nice) g += '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + Y(v).toFixed(1) + '" y2="' + Y(v).toFixed(1) + '" stroke="rgba(23,23,23,.15)"/><text x="' + (L - 6) + '" y="' + (Y(v) + 6).toFixed(1) + '" text-anchor="end" font-size="19">' + esc(String(+v.toFixed(2))) + '</text>';
    const n = labels.length, step = pw / n, line = String(spec.type || 'bar').toLowerCase() === 'line';
    labels.forEach((l, i) => { g += '<text x="' + (L + step * (i + 0.5)).toFixed(1) + '" y="' + (H - B + 24) + '" text-anchor="middle" font-size="19">' + esc(l.slice(0, 10)) + '</text>'; });
    series.forEach((sr, k) => {
      const c = COLS[k % COLS.length];
      if (line) { g += '<polyline fill="none" stroke="' + c + '" stroke-width="3" points="' + sr.data.map((v, i) => (L + step * (i + 0.5)).toFixed(1) + ',' + Y(num(v)).toFixed(1)).join(' ') + '"/>' + sr.data.map((v, i) => '<rect x="' + (L + step * (i + 0.5) - 4).toFixed(1) + '" y="' + (Y(num(v)) - 4).toFixed(1) + '" width="8" height="8" fill="' + c + '" stroke="#171717" stroke-width="1.5"/>').join(''); }
      else { const bw = Math.min(46, step * 0.8 / series.length); sr.data.forEach((v, i) => { const x = L + step * (i + 0.5) - (bw * series.length) / 2 + bw * k, y0 = Y(0), y1 = Y(num(v)); g += '<rect x="' + x.toFixed(1) + '" y="' + Math.min(y0, y1).toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + Math.max(1, Math.abs(y0 - y1)).toFixed(1) + '" fill="' + c + '" stroke="#171717" stroke-width="2"/>'; }); }
    });
    g += '<line x1="' + L + '" x2="' + L + '" y1="' + T + '" y2="' + (T + ph) + '" stroke="#171717" stroke-width="2.5"/><line x1="' + L + '" x2="' + (W - R) + '" y1="' + Y(Math.max(bot, Math.min(0, top))).toFixed(1) + '" y2="' + Y(Math.max(bot, Math.min(0, top))).toFixed(1) + '" stroke="#171717" stroke-width="2.5"/>';
    if (series.length > 1 || series[0].name) series.forEach((sr, k) => { g += '<rect x="' + (L + k * 150) + '" y="' + (H - 22) + '" width="16" height="16" fill="' + COLS[k % COLS.length] + '" stroke="#171717" stroke-width="2"/><text x="' + (L + k * 150 + 24) + '" y="' + (H - 8) + '" font-size="19">' + esc(String(sr.name || 'Series ' + (k + 1)).slice(0, 10)) + '</text>'; });
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" role="img" aria-label="Chart: ' + esc(spec.title || '') + '" style="font-family:\'Coe L4 Upright\',\'Courier New\',monospace;max-width:' + W + 'px;display:block">' + g + '</svg>';
  }
  function drawBlock(m, n, p) {
    const st = (m.blk = m.blk || {})[n] = (m.blk && m.blk[n]) || {};
    const bk = el('div', 'bk'), title = (t) => bk.appendChild(el('div', 'bt', esc(t)));
    if (!p.closed) { title(({ mindmap: 'Mind map', quiz: 'Quiz', flashcards: 'Flash cards', chart: 'Chart', svg: 'Picture' })[p.lang] || CX.titles[p.lang] || ''); bk.appendChild(el('span', 'dots', '<i></i><i></i><i></i>')); return bk; }
    if (p.lang === 'mindmap') {
      const r = window.coeMindmap ? window.coeMindmap(p.s, { width: msgsWidth() }) : null;
      if (!r) { title('Mind map'); bk.appendChild(el('p', 'tx', 'That mind map could not be read.')); return bk; }
      title('Mind map: ' + r.title); bk.appendChild(el('div', '', r.svg));
      const a = el('div', 'act'); a.append(bkBtn('Save picture', () => saveFile('mind-map.svg', r.svg, 'image/svg+xml')), bkBtn('Copy outline', async (e) => { try { await navigator.clipboard.writeText(p.s); e.target.textContent = 'Copied'; } catch { /* no clipboard */ } })); bk.appendChild(a); return bk;
    }
    if (p.lang === 'svg') {
      const x = cleanSvg(p.s); title('Picture');
      if (!x) { bk.appendChild(el('p', 'tx', 'That picture could not be shown safely.')); return bk; }
      const im = el('img'); im.alt = 'Picture drawn by Coe'; im.style.cssText = 'width:100%;height:auto;display:block'; im.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(x); bk.appendChild(im);
      bk.appendChild(el('div', 'act')).appendChild(bkBtn('Save picture', () => saveFile('picture.svg', x, 'image/svg+xml'))); return bk;
    }
    const j = jsonOf(p.s);
    if (p.lang === 'chart') {
      const x = j && chartSvg(j); title('Chart' + (j && j.title ? ': ' + j.title : ''));
      if (!x) { bk.appendChild(el('p', 'tx', 'That chart could not be read.')); return bk; }
      bk.appendChild(el('div', 'ch2', x)); return bk;
    }
    if (p.lang === 'quiz') {
      const qs = ((j && j.questions) || []).filter((q) => q && q.q && Array.isArray(q.options) && q.options.length >= 2).slice(0, 20);
      title('Quiz' + (j && j.title ? ': ' + j.title : ''));
      if (!qs.length) { bk.appendChild(el('p', 'tx', 'That quiz could not be read.')); return bk; }
      st.i = st.i || 0; st.score = st.score || 0;
      const idx = (q) => { const a = q.answer; if (typeof a === 'number') return a; const t = String(a).trim(), L = 'abcdefghij'.indexOf(t.toLowerCase()); if (t.length === 1 && L >= 0) return L; const k = q.options.findIndex((o) => String(o).trim().toLowerCase() === t.toLowerCase()); return k; };
      if (st.i >= qs.length) { bk.appendChild(el('div', 'q', '<b class="d">Score: ' + st.score + ' of ' + qs.length + '</b>')); const a = el('div', 'act'); a.appendChild(bkBtn('Try again', () => { st.i = 0; st.score = 0; st.pick = null; renderMsgs(); })); bk.appendChild(a); return bk; }
      const q = qs[st.i], right = idx(q), box = el('div', 'qz'); box.appendChild(el('div', 'q', 'Question ' + (st.i + 1) + ' of ' + qs.length + '<br>' + mdInline(q.q)));
      const os = el('div', 'opts');
      q.options.forEach((o, k) => { const b = el('button', 'o' + (st.pick != null ? (k === right ? ' right' : k === st.pick ? ' wrong' : '') : ''), mdInline(String.fromCharCode(65 + k) + '. ' + o)); b.type = 'button'; b.disabled = st.pick != null; b.onclick = () => { st.pick = k; if (k === right) st.score++; renderMsgs(); }; os.appendChild(b); });
      box.appendChild(os); if (st.pick != null && q.why) box.appendChild(el('div', 'why', mdInline(String(q.why))));
      if (st.pick != null) { const a = el('div', 'act'); a.style.marginTop = '8px'; a.appendChild(bkBtn(st.i + 1 >= qs.length ? 'See score' : 'Next', () => { st.i++; st.pick = null; renderMsgs(); })); box.appendChild(a); }
      bk.appendChild(box); return bk;
    }
    if (p.lang === 'flashcards') {
      const cs = ((j && j.cards) || []).filter((c) => c && c.front && c.back).slice(0, 40);
      title('Flash cards' + (j && j.title ? ': ' + j.title : ''));
      if (!cs.length) { bk.appendChild(el('p', 'tx', 'Those cards could not be read.')); return bk; }
      st.i = Math.min(st.i || 0, cs.length - 1); const c = cs[st.i];
      const card = el('button', 'fl', '<span><small>' + (st.flip ? 'Answer' : 'Question') + ' · ' + (st.i + 1) + ' of ' + cs.length + '</small>' + mdInline(String(st.flip ? c.back : c.front)) + '</span>'); card.type = 'button'; card.setAttribute('aria-label', 'Turn the card over'); card.onclick = () => { st.flip = !st.flip; renderMsgs(); }; bk.appendChild(card);
      const a = el('div', 'act'); const go = (d) => { st.i = (st.i + d + cs.length) % cs.length; st.flip = false; renderMsgs(); };
      a.append(bkBtn('Back', () => go(-1)), bkBtn(st.flip ? 'Show question' : 'Show answer', () => { st.flip = !st.flip; renderMsgs(); }), bkBtn('Next', () => go(1))); if (CX.saveBtn) a.appendChild(CX.saveBtn(j && j.title, cs)); bk.appendChild(a); return bk;
    }
    if (CX.blocks[p.lang]) return CX.blocks[p.lang](m, n, p, bk, st, j);
    return bk;
  }
  const hhmm = (t) => { try { return new Date(t).toLocaleString([], { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }); } catch { return ''; } };
  const stamp = (t) => (t ? el('span', 'ts', esc(hhmm(t))) : null);
  function renderBot(m, host) {
    host.replaceChildren();
    if (!m.text) { host.appendChild(el('span', 'dots', '<i></i><i></i><i></i>')); if (S.phase && S.busy) host.appendChild(el('span', 'phase tx', esc(S.phase) + '…')); return; }
    let n = 0; const searching = /```coe-search/.test(m.text);   // a reply that goes off to search says nothing before it: the search is the message
    for (const p of parts(m.text)) {
      if (p.k === 'text') { if (searching) continue; const d = el('div', '', mdBlock(p.s)); while (d.firstChild) host.appendChild(d.firstChild); }
      else if (p.k === 'blk') host.appendChild(drawBlock(m, n++, p));
      else if (p.k === 'code') {
        const c = el('div', 'code', '<div class="ch"><span>' + esc(p.lang || 'code') + '</span></div><pre><code>' + esc(p.s) + '</code></pre>');
        const b = el('button', 'btn sm', '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.6" aria-hidden="true"><path d="M9 9h11v11H9zM5 15V4h11"/></svg>'); b.type = 'button'; b.title = 'Copy the code'; b.setAttribute('aria-label', 'Copy the code'); b.onclick = async () => { try { await navigator.clipboard.writeText(p.s); b.title = 'Copied'; b.style.background = '#337957'; setTimeout(() => { b.title = 'Copy the code'; b.style.background = ''; }, 1200); } catch { b.title = 'Could not copy'; } };
        c.querySelector('.ch').appendChild(b); host.appendChild(c);
      } else if (p.k === 'coe-edit') host.appendChild(p.j && p.closed ? editCard(m, n++, p.j) : el('span', 'dots', '<i></i><i></i><i></i>'));
      else if (p.k === 'coe-highlight') host.appendChild(p.j && p.closed ? lightCard(m, n++, p.j) : el('span', 'dots', '<i></i><i></i><i></i>'));
      else if (p.k === 'coe-open') { if (p.j && p.closed) host.appendChild(openCard(m, n++, p.j)); else host.appendChild(el('span', 'dots', '<i></i><i></i><i></i>')); }
      else if (p.k === 'coe-search') { if (m.search) host.appendChild(searchCard(m.search)); else host.appendChild(el('span', 'dots', '<i></i><i></i><i></i>')); }
    }
    if (m.cut && !m.stopped) host.appendChild(el('p', 'flag tx', 'This reply reached its length limit. Say “continue” to carry on.'));
    if (m.refunded > 0) host.appendChild(el('p', 'refund tx', '<b>' + m.refunded.toLocaleString() + '</b> tokens given back.'));
  }

  // ------------------------------------------------------------------ a reply that went wrong is paid back
  const unclosed = (t) => (String(t).match(/```/g) || []).length % 2 === 1;
  /** Gives back the tokens of one reply, once. The server only pays back what it charged. */
  async function refundMsg(m, why) {
    const rc = (m && (m.receipts && m.receipts.length ? m.receipts : m.receipt ? [m.receipt] : [])) || [];
    if (!m || !rc.length || m.refunded) return;
    m.refunded = -1;
    const r = await new Promise((ok) => chrome.runtime.sendMessage({ type: 'refund', receipts: rc }, (x) => ok(chrome.runtime.lastError ? null : x)));
    if (!r || !r.ok || !(r.refunded > 0)) { m.refunded = 0; if (r && r.ok) { m.receipt = ''; m.receipts = []; } return; }
    m.refunded = r.refunded; m.refundWhy = why;
    if (r.used != null && r.limit) setMeter({ used: r.used, limit: r.limit });
    const o = await store.get('refunds'), list = Array.isArray(o.refunds) ? o.refunds : [];
    list.unshift({ id: Math.random().toString(36).slice(2, 10), t: Date.now(), tokens: r.refunded, why: String(why).slice(0, 140), chat: 'Chrome sidebar' });
    await store.set({ refunds: list.slice(0, 50) });
    renderMsgs();
  }
  /** After a reply ends: code that was cut off in the middle, or nothing at all, did not do its job. */
  function checkReply(m) {
    if (m.stopped) return;
    if (!String(m.text || '').trim()) { S.msgs = S.msgs.filter((x) => x !== m); showErr('other', 'Coe did not write anything back. Try again.'); refundMsg(m, 'Coe sent nothing back'); return; }
    if (m.cut && unclosed(m.text)) refundMsg(m, 'the code was cut off before it finished');
  }
  const blocked = () => (S.tab && isSchool(S.tab.url)) ? 'Coe does not type into this site. It is set work or a quiz, so it explains and hints only.' : '';

  /** The card that asks first: what will change, before and after. Nothing happens until you press the button. */
  function editCard(m, n, j) {
    const st = (m.edits = m.edits || {})[n] = (m.edits && m.edits[n]) || { s: 'new' };
    const find = String(j.find || ''), text = String(j.text == null ? '' : j.text);
    const c = el('div', 'edit', '<div class="eh"><b class="d">Change this on the page?</b></div><div class="eb"></div>');
    const body = c.querySelector('.eb');
    const stop = blocked();
    if (find) body.appendChild(el('div', '', '<small>Now</small><pre class="old">' + esc(find) + '</pre>'));
    else body.appendChild(el('div', '', '<small>Now</small><pre class="old">What you have selected</pre>'));
    body.appendChild(el('div', '', '<small>New</small><pre class="new">' + esc(text) + '</pre>'));
    const acts = el('div', 'ea'); body.appendChild(acts);
    if (stop) acts.appendChild(el('span', 'no', esc(stop)));
    else if (st.s === 'new') {
      const y = el('button', 'btn sm gold', 'Change it'); y.type = 'button'; y.onclick = async () => { y.disabled = true; await applyEdit(st, { find, text }); renderMsgs(); if (st.s === 'fail' && !st.allow) refundMsg(m, 'the change could not be made on the page'); };
      const no = el('button', 'btn sm', 'Not now'); no.type = 'button'; no.onclick = () => { st.s = 'skip'; renderMsgs(); };
      acts.append(y, no);
    } else if (st.s === 'done') {
      acts.appendChild(el('span', 'ok', 'Done. Changed in ' + esc(st.where || 'the page') + '.'));
      if (st.before) { const u = el('button', 'btn sm', 'Undo'); u.type = 'button'; u.onclick = async () => { u.disabled = true; const r = await doApply({ find: text, text: st.before }); st.s = r.ok ? 'undone' : 'done'; if (!r.ok) st.why = r.why; renderMsgs(); }; acts.appendChild(u); }
    } else if (st.s === 'undone') acts.appendChild(el('span', 'ok', 'Put back the way it was.'));
    else if (st.s === 'skip') acts.appendChild(el('span', 'tx', 'Left as it was.'));
    else if (st.s === 'fail') acts.appendChild(el('span', 'no', esc(st.why || 'That did not work.')));
    if (st.why && st.s === 'done') acts.appendChild(el('span', 'no', esc(st.why)));
    return c;
  }
  async function doApply(p) {
    const t = S.tab; if (!t) return { ok: false, why: 'No page to change.' };
    try { const r = await chrome.scripting.executeScript({ target: { tabId: t.id }, world: 'MAIN', func: coeApply, args: [p] }); return (r && r[0] && r[0].result) || { ok: false, why: 'The page did not answer.' }; }
    catch { return { ok: false, why: 'Coe is not allowed to change this page yet.', allow: true }; }
  }
  async function applyEdit(st, p) {
    if (blocked()) { st.s = 'fail'; st.why = blocked(); return; }
    const r = await doApply(p);
    if (r.ok) { st.s = 'done'; st.where = r.where; st.before = r.before || ''; } else { st.s = 'fail'; st.why = r.why; st.allow = !!r.allow; }
  }
  function lightCard(m, n, j) {
    const st = (m.edits = m.edits || {})[n] = (m.edits && m.edits[n]) || { s: 'new' };
    const list = (Array.isArray(j.phrases) ? j.phrases : []).map(String).filter(Boolean).slice(0, 12);
    const c = el('div', 'edit', '<div class="eh"><b class="d">Highlight on the page?</b></div><div class="eb"></div>');
    const body = c.querySelector('.eb'); body.appendChild(el('pre', 'new', esc(list.join('\n')) || 'Nothing to mark.'));
    const acts = el('div', 'ea'); body.appendChild(acts);
    if (st.s === 'new' && list.length) {
      const y = el('button', 'btn sm gold', 'Highlight'); y.type = 'button';
      y.onclick = async () => { y.disabled = true; try { const r = await chrome.scripting.executeScript({ target: { tabId: S.tab.id }, func: coeHighlight, args: [list] }); const res = r && r[0] && r[0].result; st.s = res && res.ok ? 'done' : 'fail'; st.n = res ? res.n : 0; } catch { st.s = 'fail'; } renderMsgs(); if (st.s === 'fail') refundMsg(m, 'those words were not on the page'); };
      const no = el('button', 'btn sm', 'Not now'); no.type = 'button'; no.onclick = () => { st.s = 'skip'; renderMsgs(); }; acts.append(y, no);
    } else if (st.s === 'done') {
      acts.appendChild(el('span', 'ok', 'Marked ' + st.n + (st.n === 1 ? ' place.' : ' places.')));
      const u = el('button', 'btn sm', 'Clear'); u.type = 'button'; u.onclick = async () => { await clearMarks(); st.s = 'skip'; renderMsgs(); }; acts.appendChild(u);
    } else if (st.s === 'fail') acts.appendChild(el('span', 'no', 'Could not find those words on the page.'));
    else acts.appendChild(el('span', 'tx', 'Left as it was.'));
    return c;
  }
  async function clearMarks() { try { await chrome.scripting.executeScript({ target: { tabId: S.tab.id }, func: coeClearHighlight }); } catch { /* nothing to clear */ } }

  function addAllowCard(origin) {
    const c = el('div', 'edit', '<div class="eh"><b class="d">Let Coe read this site?</b></div><div class="eb"><p>Chrome needs your OK before Coe can read <b>' + esc(hostOf(origin.replace('*', ''))) + '</b>. You can take it back any time in Chrome’s extension settings.</p></div>');
    const acts = el('div', 'ea'), y = el('button', 'btn sm gold', 'Allow on this site'), n = el('button', 'btn sm', 'No');
    y.type = n.type = 'button';
    y.onclick = async () => { let ok = false; try { ok = await chrome.permissions.request({ origins: [origin] }); } catch { /* not allowed */ } c.remove(); if (ok && S.pending) { const f = S.pending; S.pending = null; f(); } else if (!ok) showErr('page'); };
    n.onclick = () => { S.pending = null; c.remove(); };
    acts.append(y, n); c.querySelector('.eb').appendChild(acts);
    const li = el('div', 'm bot'); li.appendChild(c); $('msgs').appendChild(li); $('msgs').scrollTop = 1e9;
  }

  function userBubble(m) {
    const d = el('div', 'm user');
    if (m.images && m.images.length) { const ph = el('div', 'pics'); m.images.forEach((u) => { const b = el('button', 'pic', '<img alt="Picture you added" src="' + u + '">'); b.type = 'button'; b.onclick = () => openImage(u); ph.appendChild(b); }); d.appendChild(ph); }
    if (m.atts) { const ph = el('div', 'pics'); m.atts.filter((a) => !a.img).forEach((a) => ph.appendChild(attCard(a))); if (ph.childNodes.length) d.appendChild(ph); }
    if (m.text) d.appendChild(document.createTextNode(m.text));
    const t = stamp(m.at); if (t) d.appendChild(t);
    const lastU = [...S.msgs].reverse().find((x) => x.role === 'user' && !x.hidden);
    if (m === lastU && !S.busy && m.text) { const e = el('button', 'edit-u', '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20h4L19 9l-4-4L4 16zM14 6l4 4"/></svg>Edit'); e.type = 'button'; e.title = 'Edit this message'; e.onclick = () => editLast(m); d.appendChild(e); }
    return d;
  }
  /** Takes the last message back into the box, with Coe's answer to it, so it can be changed and sent again. */
  function editLast(m) {
    if (S.busy) return; const i = S.msgs.indexOf(m); if (i < 0) return;
    S.msgs = S.msgs.slice(0, i); let k = S.tx.length; while (k > 0 && !(S.tx[k - 1].r === 'u')) k--; S.tx = S.tx.slice(0, Math.max(0, k - 1));
    S.atts = (m.atts || []).slice(); paintAtts(); $('ta').value = m.text || ''; grow(); renderMsgs(); $('ta').focus();
  }
  const STAR = '<svg viewBox="406 8 780 780"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M786.886 22.9033C790.107 14.1976 802.421 14.1978 805.643 22.9033L825.213 75.79C875.855 212.649 983.761 320.556 1120.62 371.198L1173.51 390.768C1182.21 393.989 1182.21 406.304 1173.51 409.525L1120.62 429.095C983.761 479.737 875.855 587.643 825.213 724.503L805.643 777.39C802.421 786.095 790.107 786.095 786.886 777.39L767.316 724.503C716.674 587.643 608.768 479.737 471.908 429.095L419.021 409.525C410.316 406.304 410.316 393.989 419.021 390.768L471.908 371.198C608.768 320.556 716.674 212.65 767.316 75.79L786.886 22.9033ZM796.265 272.595C726.494 272.595 669.934 329.155 669.934 398.926C669.934 468.696 726.494 525.257 796.265 525.257C866.035 525.257 922.595 468.696 922.596 398.926C922.596 329.155 866.035 272.595 796.265 272.595Z"/></svg>';
  /* Grab the logo and turn it. It follows your finger, keeps its speed when you let go and slows down slowly, like a wheel with a bit of friction.
     A plain tap gives it a push. Same feel as the logo on the Coe website. */
  function spinnable(box) {
    const FRICTION = 0.85, MAX = 2600;
    let ang = 0, w = 0, raf = 0, pid = -1, lastPa = 0, path = 0, lastXY = [0, 0], samples = [];
    const calm = () => matchMedia('(prefers-reduced-motion: reduce)').matches;
    const paint = () => { box.style.transform = 'rotate(' + ang + 'deg)'; };
    const angleAt = (e) => { const r = box.getBoundingClientRect(); return Math.atan2(e.clientY - (r.top + r.height / 2), e.clientX - (r.left + r.width / 2)) * 180 / Math.PI; };
    const wrap = (d) => ((((d + 180) % 360) + 360) % 360) - 180;
    const stop = () => { if (raf) cancelAnimationFrame(raf); raf = 0; };
    const coast = () => {
      stop(); let last = performance.now();
      const step = (now) => {
        if (!box.isConnected) { raf = 0; return; }
        const dt = Math.min(0.05, (now - last) / 1000); last = now;
        ang += w * dt; w *= Math.exp(-FRICTION * dt); paint();
        if (Math.abs(w) < 3) { w = 0; raf = 0; return; }
        raf = requestAnimationFrame(step);
      };
      raf = requestAnimationFrame(step);
    };
    box.addEventListener('pointerdown', (e) => {
      if (e.button !== 0 || pid !== -1) return;
      e.preventDefault(); box.setPointerCapture && box.setPointerCapture(e.pointerId); pid = e.pointerId;
      stop(); w = 0; path = 0; lastXY = [e.clientX, e.clientY]; lastPa = angleAt(e); samples = [{ t: performance.now(), a: ang }];
      box.classList.add('grabbing');
    });
    box.addEventListener('pointermove', (e) => {
      if (e.pointerId !== pid) return;
      const pa = angleAt(e); ang += wrap(pa - lastPa); lastPa = pa;
      path += Math.hypot(e.clientX - lastXY[0], e.clientY - lastXY[1]); lastXY = [e.clientX, e.clientY];
      const now = performance.now(); samples.push({ t: now, a: ang }); while (samples.length > 2 && now - samples[0].t > 110) samples.shift();
      paint();
    });
    const up = (e) => {
      if (e.pointerId !== pid) return; pid = -1; box.classList.remove('grabbing');
      const now = performance.now(), s0 = samples[0], dt = Math.max(0.016, (now - s0.t) / 1000);
      if (path < 5) w = (Math.random() < 0.5 ? -1 : 1) * 340;
      else w = Math.abs(now - samples[samples.length - 1].t) > 120 ? 0 : (ang - s0.a) / dt;
      w = Math.max(-MAX, Math.min(MAX, w));
      if (calm()) { w = 0; return; }
      coast();
    };
    box.addEventListener('pointerup', up); box.addEventListener('pointercancel', up);
  }
  function home() {
    const nm = String((S.me && S.me.name) || '').trim().split(/\s+/)[0], off = S.busy || S.errKind === 'credits';
    const h = el('div', 'hello', '<span class="logo" aria-hidden="true">' + STAR + '</span><h2 class="d">' + (S.temp ? 'Private chat' : esc(CX.greeting ? CX.greeting(nm) : nm ? 'Hi ' + nm : 'Coe Mini')) + '</h2><p class="tx">' + (S.temp ? 'Temporary. Nothing in this chat is saved.' : 'Ask anything, add a picture, or start from a block.') + '</p>'), cards = el('div', 'cards');
    spinnable(h.querySelector('.logo'));
    const HI = {
      find: '<path d="M10.5 3.5a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM15.5 15.5l5.5 5.5"/>',
      explain: '<path d="M12 4l10 5-10 5L2 9l10-5zM6 12v4.5c0 1.5 2.7 3 6 3s6-1.5 6-3V12"/>',
      sum: '<path d="M9 6h12M9 12h12M9 18h12M4 6h.1M4 12h.1M4 18h.1"/>',
      quiz: '<path d="M7 6.5h12v12H7zM4.5 4h12M4 16.5V6"/>',
      eye: '<path d="M3 8h4l2-3h6l2 3h4v11H3zM12 10a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7z"/>',
      mark: '<path d="M4 21h16M7 16l8-8 3 3-8 8H7zM13 10l3 3"/>',
      pick: '<path d="M4 6V4h16v2M12 4v16M9 20h6"/>',
    };
    for (const [t, d, k, f, ic] of [
      ['Find the questions', 'Scan this page and help with each one', 'main', () => findQuestions(), 'find'],
      ['Explain this page', 'In simple words', '', () => send('Explain this page in simple words.'), 'explain'],
      ['Summarise', 'Five short points', '', () => send('Summarise this page in five short points.'), 'sum'],
      ['Practice questions', 'Test yourself', '', () => send(QUICK[3][1], QUICK[3][2]), 'quiz'],
      ['Look at the screen', 'Say what is in the picture', '', () => send(QUICK[6][1], QUICK[6][2]), 'eye'],
      ['Highlight key points', 'Mark them on the page', '', () => send(QUICK[5][1]), 'mark'],
      ['Explain my selection', 'Select words first', '', () => send(QUICK[4][1]), 'pick'],
    ]) { const b = el('button', 'hc' + (k ? ' ' + k : ''), '<i class="hi" aria-hidden="true"><svg viewBox="0 0 24 24">' + HI[ic] + '</svg></i><b>' + esc(t) + '</b><span>' + esc(d) + '</span>'); b.type = 'button'; b.disabled = off || (k === 'main' && S.qBusy); b.onclick = f; cards.appendChild(b); }
    if (!S.temp) h.appendChild(el('h3', 'd hbs-h', 'From a page'));
    h.appendChild(cards);
    if (!S.temp && CX.homeMore) CX.homeMore(h, off);
    const tb = el('button', 'tmp', S.temp ? '<b>Leave the private chat</b>' : '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 11h12v9H6zM8.5 11V8a3.5 3.5 0 0 1 7 0v3"/></svg><b>Private chat</b><span>Temporary. Not saved.</span>'); tb.type = 'button'; tb.onclick = () => newChat(!S.temp); h.appendChild(tb);
    h.appendChild(el('p', 'fine tx', 'Coe can be wrong. Check anything important.'));
    return h;
  }
  /** The make-it-better buttons under the last reply. */
  function betterRow(m) {
    const r = el('div', 'mb'), off = S.busy || S.errKind === 'credits';
    for (const [label, f] of [
      ['Copy', async (b) => { try { await navigator.clipboard.writeText(String(m.text || '')); b.classList.add('ok'); b.title = 'Copied'; setTimeout(() => { b.classList.remove('ok'); b.title = 'Copy'; }, 1200); } catch { b.title = 'Could not copy'; } }],
      ['Try again', () => regen()],
      ['Shorter', () => send('Make that shorter.', { say: 'Shorter' })],
      ['Simpler', () => send('Say that again in simpler words.', { say: 'Simpler' })],
      ['More detail', () => send('Give me more detail on that.', { say: 'More detail' })],
    ].filter(([label]) => !['Shorter', 'Simpler', 'More detail'].includes(label) || String(m.text || '').length > 160)) { const icon = label === 'Copy' ? '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 9h11v11H9zM5 15V4h11"/></svg>' : label === 'Try again' ? '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 12a8 8 0 1 1-2.6-5.9M20 4v5h-5"/></svg>' : ''; const b = el('button', icon ? 'ico' : '', icon || esc(label)); b.type = 'button'; if (icon) { b.title = label; b.setAttribute('aria-label', label); } b.disabled = off && label !== 'Copy'; b.onclick = () => f(b); r.appendChild(b); }
    return r;
  }
  /** Throws away the last reply and asks again. */
  async function regen() {
    if (S.busy) return;
    let i = S.msgs.length; while (i > 0 && (S.msgs[i - 1].role !== 'user' || S.msgs[i - 1].hidden)) i--;
    if (!i) return; const mine = S.msgs[i - 1]; S.msgs = S.msgs.slice(0, i);
    while (S.tx.length && S.tx[S.tx.length - 1].r === 'a') S.tx.pop();
    clearErr(); await turn(mine, mine.text, {});
  }
  function renderMsgs(keep) {
    const box = $('msgs'), near = box.scrollHeight - box.scrollTop - box.clientHeight < 80, top = box.scrollTop;
    box.replaceChildren();
    if (!S.msgs.length && !S.busy && !S.qBusy) { box.appendChild(el('i', 'ht hm', '<b></b><b></b><b></b>')); box.appendChild(home()); box.scrollTop = 0; return; }
    if (S.temp) { const t = el('div', 'tempbar', '<b>Private chat</b><span class="tx">Temporary. Nothing here is saved.</span>'); const x = el('button', 'btn sm', 'Leave'); x.type = 'button'; x.onclick = () => newChat(false); t.appendChild(x); box.appendChild(t); }
    const lastBot = [...S.msgs].reverse().find((m) => !m.hidden && !m.kind);
    for (const m of S.msgs) {
      if (m.hidden) continue;
      if (m.kind === 'qs') { if (S.qs) box.appendChild(qsPanel()); continue; }
      if (m.role === 'user') box.appendChild(userBubble(m));
      else {
        const d = el('div', 'm bot'); renderBot(m, d);
        if (m === lastBot && !S.busy && !S.qBusy && m.text && !/```coe-search/.test(m.text)) d.appendChild(betterRow(m));
        const t = m.text ? stamp(m.at) : null; if (t) d.appendChild(t);
        if (d.childNodes.length) box.appendChild(d);
      }
    }
    const lastShown = lastBot;
    if (S.busy && lastShown && lastShown.role === 'user') { const d = el('div', 'm bot'); d.appendChild(el('span', 'dots', '<i></i><i></i><i></i>')); if (S.phase) d.appendChild(el('span', 'phase tx', esc(S.phase) + '…')); box.appendChild(d); }
    if (S.qBusy) { const d = el('div', 'm bot'); d.appendChild(el('span', 'dots', '<i></i><i></i><i></i>')); d.appendChild(el('span', 'phase tx', 'Looking for questions…')); box.appendChild(d); }
    if (near || keep) box.scrollTop = box.scrollHeight; else box.scrollTop = top;
    if (S.find) applyFind(false);
  }

  // ------------------------------------------------------------------ opening a tab, and a web search
  const safeUrl = (j) => { try { const u = j && j.url ? new URL(String(j.url)) : j && j.search ? new URL('https://www.google.com/search?q=' + encodeURIComponent(String(j.search).slice(0, 200))) : null; return u && /^https?:$/.test(u.protocol) ? u : null; } catch { return null; } };
  /** The card that asks first. With "Ask before opening a new tab" switched off in Settings, it opens in the background by itself. */
  function openCard(m, n, j) {
    const st = (m.edits = m.edits || {})[n] = (m.edits && m.edits[n]) || { s: 'new' };
    const u = safeUrl(j), c = el('div', 'edit', '<div class="eh"><b class="d">Open in a new tab?</b></div><div class="eb"></div>'), body = c.querySelector('.eb');
    if (!u) { c.querySelector('.eh b').textContent = 'Cannot open that'; body.appendChild(el('span', 'no', 'That is not a web link Coe can open.')); return c; }
    body.appendChild(el('pre', 'new', esc(j.search ? 'Search: ' + first(j.search, 90) : u.hostname + first(u.pathname === '/' ? '' : u.pathname, 50))));
    if (j.why) body.appendChild(el('p', 'tx', esc(first(j.why, 90))));
    const acts = el('div', 'ea'); body.appendChild(acts);
    const open = async (fg) => { try { await chrome.tabs.create({ url: u.href, active: fg }); st.s = 'done'; st.bg = !fg; } catch { st.s = 'fail'; } renderMsgs(); };
    if (st.s === 'new') {
      if (S.askTabs === 'allow' && !st.auto) { st.auto = true; setTimeout(() => open(false), 0); acts.appendChild(el('span', 'tx', 'Opening…')); }
      else { const y = el('button', 'btn sm gold', 'Open'); y.type = 'button'; y.onclick = () => { y.disabled = true; open(true); }; const no = el('button', 'btn sm', 'Not now'); no.type = 'button'; no.onclick = () => { st.s = 'skip'; renderMsgs(); }; acts.append(y, no); }
    } else if (st.s === 'done') acts.appendChild(el('span', 'ok', st.bg ? 'Opened in a new tab behind this one.' : 'Opened in a new tab.'));
    else if (st.s === 'skip') acts.appendChild(el('span', 'tx', 'Not opened.'));
    else if (st.s === 'fail') acts.appendChild(el('span', 'no', 'Chrome would not open it.'));
    return c;
  }
  /** A search that worked shows the sites. One that failed shows nothing here: the reply says so, once. */
  function searchCard(sr) {
    if (sr.state === 'bad') return document.createDocumentFragment();
    if (sr.state === 'run') return el('div', 'sc', 'Searching the web for “' + esc(first(sr.q, 60)) + '”…');
    const c = el('div', 'sc', 'Searched: “' + esc(first(sr.q, 50)) + '”');
    (sr.sources || []).slice(0, 4).forEach((x) => { const h = hostOf(x.url).replace(/^www\./, ''); if (h) { const a = el('a', '', esc(h)); a.href = x.url; a.target = '_blank'; a.rel = 'noopener noreferrer'; c.appendChild(a); } });
    return c;
  }

  // ------------------------------------------------------------------ waiting messages
  function paintQueue() {
    const host = $('queue'); if (!host) return; host.replaceChildren();
    S.queue.forEach((q, i) => {
      const d = el('div', 'queued', '<span>Next: ' + esc(first(q.text, 70)) + '</span>');
      if (i === 0 && S.busy) { const b = el('button', '', 'Send now'); b.type = 'button'; b.onclick = sendNow; d.appendChild(b); }
      const x = el('button', '', 'Remove'); x.type = 'button'; x.onclick = () => { S.queue.splice(i, 1); paintQueue(); }; d.appendChild(x); host.appendChild(d);
    });
  }

  // ------------------------------------------------------------------ everything done here is kept so the Coe website can show it
  let saveT = 0;
  function saveChat() {
    clearTimeout(saveT);
    saveT = setTimeout(async () => {
      try {
        if (!S.tx.length || S.temp) return;   // a temporary chat is never saved
        const o = await store.get('chats'), list = Array.isArray(o.chats) ? o.chats : [];
        const us = S.tx.find((x) => x.r === 'u'), where = (() => { try { const u = new URL(S.tab.url); return u.origin + u.pathname; } catch { return ''; } })();
        const old = list.find((x) => x.id === S.chatId) || {};
        const rec = { id: S.chatId, title: first((us || S.tx[0]).t, 48), arch: !!old.arch, host: hostOf(S.tab && S.tab.url), url: where, t: Date.now(), msgs: S.tx.slice(-60) };
        await store.set({ chats: [rec, ...list.filter((x) => x.id !== S.chatId)].slice(0, 60) });
      } catch { /* storage unavailable */ }
    }, 350);
  }

  // ------------------------------------------------------------------ the questions on a page
  const QKIND = { one: 'Pick one', many: 'Pick any', text: 'Short answer', long: 'Long answer', select: 'Pick from a list', open: 'Question' };
  async function findQuestions() {
    if (S.qBusy || S.busy) return;
    clearErr(); S.qBusy = true; paintQuick(); renderMsgs(true);
    let page, r = null;
    try { page = await readTab(S.scope); r = await runInTab(coeFindQuestions); }
    catch (e) {
      S.qBusy = false; paintQuick(); renderMsgs();
      if (e && e.code === 'allow') { S.pending = findQuestions; addAllowCard(e.origin); return; }
      showErr((e && e.code) || 'other'); return;
    }
    S.qBusy = false; paintQuick();
    if (!r) { renderMsgs(); showErr('other', 'Coe could not look through this page. Try again.'); return; }
    let items = r.items || [];
    if (!items.length && r.onScreen) items = [{ id: 's', text: r.onScreen, kind: 'open', options: [], fillable: false, screen: true }];
    if (!items.length) { renderMsgs(); showErr('noq'); return; }
    S.msgs = S.msgs.filter((m) => m.kind !== 'qs');
    S.qs = { url: page.url, title: r.title, school: isSchool(page.url), items: items.map((x) => ({ ...x, text: String(x.text || '').replace(/^\s*(?:Q(?:uestion)?\s*\d+\s*[.):\-]?|\d{1,2}\s*[.):])\s+(?=\S)/i, '') || x.text, res: null, busy: '', pick: [], fill: null, text0: '' })), shot: S.shot };
    S.msgs.push({ role: 'assistant', kind: 'qs' }); renderMsgs(true);
    tell('a', 'Found ' + items.length + ' question' + (items.length === 1 ? '' : 's') + ' on “' + first(r.title, 50) + '”.');
  }
  function callJson(system, user, images) {
    return new Promise((done) => {
      const port = connect(); let text = '', over = false;
      port.onMessage.addListener((m) => {
        if (over) return;
        if (m.t === 'd') text += m.s;
        else if (m.t === 'end') {
          over = true; try { port.disconnect(); } catch { /* done */ } if (m.credits) setMeter(m.credits);
          const a = text.indexOf('{'), z = text.lastIndexOf('}'); let data = null; if (a >= 0 && z > a) { try { data = JSON.parse(text.slice(a, z + 1)); } catch { /* not JSON */ } }
          done(data ? { ok: true, data, receipt: m.receipt || '' } : { ok: false, error: 'Coe’s answer came back in a form it could not use.', receipt: m.receipt || '', refundable: true });
        } else if (m.t === 'err') { over = true; try { port.disconnect(); } catch { /* done */ } done({ ok: false, code: m.code, error: m.error }); }
      });
      port.postMessage({ type: 'send', system, messages: [{ role: 'user', content: images && images.length ? [...images.map((u) => ({ type: 'image_url', image_url: { url: u } })), { type: 'text', text: user }] : user }] });
    });
  }
  const QBASE = 'You are Coe Mini, a study helper in a browser sidebar. Use plain, short words and British spelling. No greeting and no extra words. Reply with ONE JSON object and nothing else.';
  const QSHAPE = {
    answer: ['Give the answer.', '{"answer":"the answer in a few words","fill":"the exact option text copied from OPTIONS, or exactly what to type","why":"one short line, under 20 words"}'],
    explain: ['Explain how to think about it, in two to four short sentences.', '{"text":"the explanation"}'],
    hint: ['Give one nudge that helps without giving the answer.', '{"text":"the nudge"}'],
    check: ['Check what the student answered. If it is right, say so and why in one sentence. If not, give one nudge. Do not give the answer.', '{"verdict":"right or almost or not yet","text":"one or two short sentences"}'],
  };
  /** One question, one job: answer it, explain it, hint, or check what the student tried. */
  async function qAsk(it, mode, attempt) {
    if (it.busy || S.busy) return;
    const q = S.qs, school = q.school;
    if (school && mode === 'answer') return;   // set work and quizzes: explain, hint and check only
    it.busy = mode; it.res = null; if (mode === 'answer') it.fill = null; renderMsgs();
    const ex = (S.page && S.page.text ? String(S.page.text).slice(0, 3500) : '');
    const task = QSHAPE[mode][0] + (school && mode !== 'check' ? ' This is set work or a quiz, so never state the final answer.' : '');
    const user = 'PAGE: ' + q.title + ' (' + hostOf(q.url) + ')' + (ex && !it.screen ? '\nPAGE TEXT (for reading questions):\n' + ex : '') + '\n\nQUESTION: ' + it.text + (it.options.length ? '\nOPTIONS:\n- ' + it.options.join('\n- ') : '') + (attempt ? '\nTHE STUDENT ANSWERED: ' + attempt : '') + '\n\nTASK: ' + task + ' Reply with one JSON object like this: ' + QSHAPE[mode][1];
    const r = await callJson(QBASE, user, it.screen && q.shot ? [q.shot] : []);
    it.busy = '';
    if (!r.ok) {
      if (r.code) { it.res = null; renderMsgs(); showErr(r.code, r.error); return; }
      it.res = { kind: 'bad', text: 'Could not get an answer. Try again.' }; renderMsgs();
      if (r.refundable) refundMsg({ receipt: r.receipt }, 'the answer came back unreadable');
      return;
    }
    const d = r.data || {}; it.receipt = r.receipt;
    it.res = { kind: mode, answer: String(d.answer || '').slice(0, 400), fill: String(d.fill == null ? d.answer || '' : d.fill).slice(0, 600), why: String(d.why || '').slice(0, 300), text: String(d.text || '').slice(0, 900), verdict: /^(right|almost)/i.test(String(d.verdict || '')) ? (/^right/i.test(d.verdict) ? 'right' : 'almost') : 'not yet' };
    if (mode === 'answer' && !it.res.answer) { it.res = { kind: 'bad', text: 'Could not get an answer. Try again.' }; if (r.receipt) refundMsg({ receipt: r.receipt }, 'the answer came back empty'); }
    renderMsgs(); tell('u', (mode === 'check' ? 'Check my answer' : mode === 'answer' ? 'Answer' : mode === 'hint' ? 'Hint' : 'Explain') + ' (question ' + (Number(it.id) + 1 || '') + '): ' + first(it.text, 160) + (attempt ? ' / my answer: ' + attempt : ''));
    tell('a', it.res.kind === 'answer' ? it.res.answer + (it.res.why ? ' (' + it.res.why + ')' : '') : it.res.text);
  }
  /** Answers every question in one go (not on set work or quizzes). */
  async function qAll() {
    const q = S.qs; if (!q || q.school || S.busy) return;
    const list = q.items.filter((x) => !x.screen); if (!list.length) return;
    list.forEach((x) => { x.busy = 'answer'; x.res = null; x.fill = null; }); renderMsgs();
    const ex = (S.page && S.page.text ? String(S.page.text).slice(0, 3500) : '');
    const user = 'PAGE: ' + q.title + ' (' + hostOf(q.url) + ')' + (ex ? '\nPAGE TEXT (for reading questions):\n' + ex : '') + '\n\n' + list.map((x, i) => 'QUESTION ' + (i + 1) + ': ' + x.text + (x.options.length ? '\nOPTIONS:\n- ' + x.options.join('\n- ') : '')).join('\n\n') + '\n\nTASK: Answer every question. Reply with one JSON object like this: {"items":[{"n":1,"answer":"the answer in a few words","fill":"the exact option text copied from OPTIONS, or exactly what to type","why":"one short line, under 20 words"}]}. n is the question number.';
    const r = await callJson(QBASE, user, []);
    list.forEach((x) => { x.busy = ''; });
    if (!r.ok) { renderMsgs(); if (r.code) showErr(r.code, r.error); else { list.forEach((x) => { x.res = { kind: 'bad', text: 'Could not get an answer. Try again.' }; }); renderMsgs(); if (r.refundable) refundMsg({ receipt: r.receipt }, 'the answers came back unreadable'); } return; }
    const arr = Array.isArray(r.data.items) ? r.data.items : [];
    let got = 0;
    list.forEach((x, i) => { const d = arr.find((a) => Number(a.n) === i + 1) || arr[i]; if (d && (d.answer || d.fill)) { got++; x.receipt = r.receipt; x.res = { kind: 'answer', answer: String(d.answer || d.fill).slice(0, 400), fill: String(d.fill == null ? d.answer : d.fill).slice(0, 600), why: String(d.why || '').slice(0, 300) }; } else x.res = { kind: 'bad', text: 'No answer came back for this one.' }; });
    renderMsgs();
    if (!got && r.receipt) refundMsg({ receipt: r.receipt }, 'no usable answers came back');
    tell('u', 'Answer all ' + list.length + ' questions on “' + first(q.title, 40) + '”'); tell('a', list.map((x, i) => (i + 1) + '. ' + (x.res.kind === 'answer' ? x.res.answer : '(none)')).join('\n'));
    if (S.askChg === 'allow') for (const x of list) if (x.fillable && x.res.kind === 'answer') await qFill(x);
  }
  const noHash = (u) => String(u || '').split('#')[0];
  async function qFill(it) {
    if (S.qs && S.tab && noHash(S.tab.url) !== noHash(S.qs.url)) { it.fill = { s: 'fail', why: 'This is a different page now. Press Scan again.' }; renderMsgs(); return; }
    if (!S.qs || S.qs.school || isSchool(S.tab && S.tab.url)) { it.fill = { s: 'fail', why: blocked() || 'Coe does not type into this site.' }; renderMsgs(); return; }
    it.fill = { s: 'run' }; renderMsgs();
    let r;
    try { r = await runInTab(coeFillAnswer, [it.id, it.res.fill || it.res.answer]); } catch { r = { ok: false, why: 'Coe is not allowed to change this page yet.' }; }
    it.fill = r && r.ok ? { s: 'done', before: r.before || '' } : { s: 'fail', why: (r && r.why) || 'That did not work.' };
    renderMsgs();
    if (it.fill.s === 'fail' && it.receipt && !it.refundedFill && /match|gone|option/i.test(it.fill.why)) { it.refundedFill = true; refundMsg({ receipt: it.receipt }, 'the answer did not fit the page'); }
  }
  async function qUndo(it) {
    if (!it.fill || it.fill.s !== 'done') return;
    let r; try { r = await runInTab(coeFillAnswer, [it.id, it.fill.before, true]); } catch { r = null; }
    it.fill = r && r.ok ? { s: 'undone' } : { ...it.fill, why: 'Could not undo that.' }; renderMsgs();
  }
  function qCard(it, i) {
    const q = S.qs, school = q.school, c = el('div', 'qc');
    c.appendChild(el('div', 'qc-t', '<span class="qc-n d">' + (it.screen ? '•' : i + 1) + '</span><div class="qc-q">' + esc(first(it.text, 420)) + '</div>'));
    if (it.options.length) {
      const o = el('div', 'qc-o');
      it.options.forEach((t) => {
        const b = el(school && (it.kind === 'one' || it.kind === 'many') ? 'button' : 'span', 'qp' + (school ? ' pick' : '') + (it.pick.includes(t) ? ' on' : ''), esc(first(t, 70)));
        if (b.tagName === 'BUTTON') { b.type = 'button'; b.setAttribute('aria-pressed', String(it.pick.includes(t))); b.onclick = () => { it.pick = it.kind === 'many' ? (it.pick.includes(t) ? it.pick.filter((x) => x !== t) : [...it.pick, t]) : [t]; renderMsgs(); }; }
        o.appendChild(b);
      });
      c.appendChild(o);
    }
    const a = el('div', 'qc-a'), mk = (label, f, cls) => { const b = el('button', 'btn sm' + (cls ? ' ' + cls : ''), esc(label)); b.type = 'button'; b.disabled = !!it.busy || S.busy; b.onclick = f; a.appendChild(b); return b; };
    if (it.busy) a.appendChild(el('span', 'qc-w', '<span class="dots"><i></i><i></i><i></i></span>Working on it'));
    else if (school) { mk('Hint', () => qAsk(it, 'hint')); mk('Explain', () => qAsk(it, 'explain')); }
    else { mk('Answer', () => qAsk(it, 'answer'), 'gold'); mk('Explain', () => qAsk(it, 'explain')); }
    c.appendChild(a);
    if (school && !it.screen) {
      const choice = it.kind === 'one' || it.kind === 'many' || it.options.length;
      if (choice) { const b = el('button', 'btn sm', 'Check my pick'); b.type = 'button'; b.disabled = !it.pick.length || !!it.busy || S.busy; b.onclick = () => qAsk(it, 'check', it.pick.join('; ')); const w = el('div', 'qc-a'); w.appendChild(b); c.appendChild(w); }
      else { const w = el('div', 'qc-chk'), inp = el('input'); inp.type = 'text'; inp.placeholder = 'Your answer'; inp.value = it.text0 || ''; inp.setAttribute('aria-label', 'Your answer to question ' + (i + 1)); inp.oninput = () => { it.text0 = inp.value; }; const b = el('button', 'btn sm', 'Check'); b.type = 'button'; b.disabled = !!it.busy || S.busy; const go = () => { if (inp.value.trim()) qAsk(it, 'check', inp.value.trim()); }; b.onclick = go; inp.onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); go(); } }; w.append(inp, b); c.appendChild(w); }
    }
    const r = it.res;
    if (r) {
      if (r.kind === 'bad') c.appendChild(el('div', 'qc-r bad', esc(r.text)));
      else if (r.kind === 'answer') {
        const box = el('div', 'qc-r good', '<b>Answer</b><div>' + esc(r.answer) + '</div>' + (r.why ? '<div class="tx">' + esc(r.why) + '</div>' : '')); c.appendChild(box);
        if (it.fillable && !school) {
          const w = el('div', 'qc-a'); c.appendChild(w); const f = it.fill;
          if (!f || f.s === 'fail') { const b = el('button', 'btn sm gold', 'Put in page'); b.type = 'button'; b.onclick = () => qFill(it); w.appendChild(b); if (f) w.appendChild(el('span', 'no', esc(f.why))); }
          else if (f.s === 'run') w.appendChild(el('span', 'tx', 'Putting it in…'));
          else if (f.s === 'done') { w.appendChild(el('span', 'ok', 'Done. It is in the page.')); if (it.kind !== 'one') { const u = el('button', 'btn sm', 'Undo'); u.type = 'button'; u.onclick = () => qUndo(it); w.appendChild(u); } }
          else if (f.s === 'undone') w.appendChild(el('span', 'tx', 'Put back.'));
        }
      } else if (r.kind === 'check') c.appendChild(el('div', 'qc-r ' + (r.verdict === 'right' ? 'good' : r.verdict === 'almost' ? 'hmm' : 'bad'), '<b>' + (r.verdict === 'right' ? 'Right' : r.verdict === 'almost' ? 'Almost' : 'Not yet') + '</b><div>' + esc(r.text) + '</div>'));
      else c.appendChild(el('div', 'qc-r', '<b>' + (r.kind === 'hint' ? 'Hint' : 'Idea') + '</b><div>' + esc(r.text) + '</div>'));
    }
    return c;
  }
  function qsPanel() {
    const q = S.qs, box = el('div', 'qs'), h = el('div', 'qs-h', '<b class="d">' + (q.items[0] && q.items[0].screen ? 'This page' : 'Questions · ' + q.items.length) + '</b><span class="grow"></span>');
    const again = el('button', 'btn sm', 'Scan again'); again.type = 'button'; again.onclick = () => findQuestions(); h.appendChild(again);
    if (!q.school && !(q.items[0] && q.items[0].screen)) { const all = el('button', 'btn sm gold', 'Answer all'); all.type = 'button'; all.disabled = S.busy || q.items.some((x) => x.busy); all.onclick = qAll; h.appendChild(all); }
    box.appendChild(h);
    if (q.school) box.appendChild(el('div', 'qs-note', 'Set work or a quiz. Coe explains, hints and checks. It does not type for you.'));
    else if (q.items.some((x) => x.res && x.res.kind === 'answer' && x.fillable && (!x.fill || x.fill.s === 'fail'))) {
      const n = q.items.filter((x) => x.res && x.res.kind === 'answer' && x.fillable && (!x.fill || x.fill.s === 'fail')).length;
      const w = el('div', 'qs-note'); w.appendChild(document.createTextNode(q.confirmAll ? 'Put ' + n + ' answer' + (n === 1 ? '' : 's') + ' in the page? ' : ''));
      if (q.confirmAll) { const y = el('button', 'btn sm gold', 'Put them in'); y.type = 'button'; y.onclick = async () => { q.confirmAll = false; for (const x of q.items) if (x.res && x.res.kind === 'answer' && x.fillable && (!x.fill || x.fill.s === 'fail')) await qFill(x); }; const no = el('button', 'btn sm', 'Cancel'); no.type = 'button'; no.onclick = () => { q.confirmAll = false; renderMsgs(); }; w.append(y, document.createTextNode(' '), no); }
      else { const b = el('button', 'btn sm gold', 'Put all in page'); b.type = 'button'; b.onclick = () => { q.confirmAll = true; renderMsgs(); }; w.appendChild(b); }
      box.appendChild(w);
    }
    q.items.forEach((it, i) => box.appendChild(qCard(it, i)));
    return box;
  }

  // ------------------------------------------------------------------ files you add, with previews
  function attCard(a, remove) {
    const c = el('span', 'att-c'), b = el('button', 'att-b', '<span class="att-pg" aria-hidden="true"><b>' + esc((ext(a.name) || 'file').slice(0, 4)) + '</b><span>' + esc(first(a.text) || 'Nothing to read') + '</span></span><span class="att-n"><b>' + esc(a.name) + '</b><i>' + (a.cut ? 'cut short' : a.pasted ? a.text.length.toLocaleString() + ' letters' : 'text file') + '</i></span>');
    b.type = 'button'; b.title = 'Preview'; b.setAttribute('aria-label', 'Preview ' + a.name); b.onclick = () => openDlg(a.name, [el('p', 'meta', (a.text.length).toLocaleString() + ' letters' + (a.cut ? '. The file was long, so Coe reads the first part.' : '')), el('pre', 'tx', esc(a.text.slice(0, 6000)))]);
    c.appendChild(b);
    if (remove) { const x = el('button', 'x', X); x.type = 'button'; x.setAttribute('aria-label', 'Remove ' + a.name); x.onclick = remove; c.appendChild(x); }
    return c;
  }
  function paintAtts() {
    const box = $('atts'); box.replaceChildren();
    S.atts.forEach((a, i) => {
      const rm = () => { S.atts.splice(i, 1); paintAtts(); paintSend(); };
      if (a.img) { const t = el('span', 'thumb'); const im = el('img'); im.src = a.img; im.alt = a.name; im.title = 'Look closer'; im.onclick = () => openImage(a.img); const x = el('button', 'x', X); x.type = 'button'; x.setAttribute('aria-label', 'Remove ' + a.name); x.onclick = rm; t.append(im, x); box.appendChild(t); }
      else box.appendChild(attCard(a, rm));
    });
  }
  async function addFiles(list) {
    for (const f of Array.from(list).slice(0, 4)) {
      if (S.atts.length >= 4) break;
      try {
        if (f.type.startsWith('image/')) {
          const url = await new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = no; r.readAsDataURL(f); });
          const img = await new Promise((ok, no) => { const i = new Image(); i.onload = () => ok(i); i.onerror = no; i.src = url; });
          const k = Math.min(1, 1280 / Math.max(img.width, img.height)), cv = document.createElement('canvas'); cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k);
          cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height); S.atts.push({ name: f.name, img: cv.toDataURL('image/jpeg', 0.82) });
        } else {
          const t = await f.text(); S.atts.push({ name: f.name, text: t.slice(0, 20000), cut: t.length > 20000 });
        }
      } catch { showErr('other', 'Coe could not open ' + f.name + '.'); }
    }
    paintAtts(); paintSend();
  }

  // ------------------------------------------------------------------ windows
  function openDlg(title, nodes) {
    $('dt').textContent = title; $('db').replaceChildren(...nodes); $('dlg').hidden = false; $('dlg').querySelector('.modal').focus();
  }
  const closeDlg = () => { $('dlg').hidden = true; $('db').replaceChildren(); };
  function openImage(u) { const i = el('img', 'big'); i.src = u; i.alt = ''; openDlg('Picture', [i]); }
  $('dx').onclick = closeDlg; $('dlg').addEventListener('pointerdown', (e) => { if (e.target === $('dlg')) closeDlg(); });
  addEventListener('keydown', (e) => { if (e.key === 'Escape') { if (!$('dlg').hidden) closeDlg(); else closeMenu(); } });

  $('page').onclick = () => {
    const read = S.page && S.tab && S.page.url === S.tab.url, nodes = [];
    if (read) {
      if (S.shot) { const i = el('img', 'big'); i.src = S.shot; i.alt = 'The page as Coe saw it'; nodes.push(i); }
      nodes.push(el('p', 'meta', esc(S.page.url)), el('p', 'meta', 'Coe read ' + S.page.text.length.toLocaleString() + ' letters' + (S.page.docKind ? ' from this Google file' : S.page.scope === 'screen' ? ' that are on screen' : ' from the whole page') + (S.page.cut ? ' (the page was long, so it was cut short)' : '') + '.'));
      if (S.page.selection) nodes.push(el('p', 'meta', 'You had selected: “' + esc(first(S.page.selection, 160)) + '”'));
      nodes.push(el('pre', 'tx', esc(S.page.text.slice(0, 6000))));
    } else {
      nodes.push(el('p', '', 'Coe has not read this page yet. It reads when you send a message or press a button below.'));
      const b = el('button', 'btn gold', 'Read it now'); b.type = 'button';
      b.onclick = async () => { b.disabled = true; try { await readTab(S.scope); closeDlg(); $('page').click(); } catch (e) { closeDlg(); if (e && e.code === 'allow') { S.pending = null; addAllowCard(e.origin); } else showErr((e && e.code) || 'other'); } };
      nodes.push(b);
    }
    openDlg(S.tab ? (S.tab.title || 'This page') : 'This page', nodes);
  };

  // ------------------------------------------------------------------ the message box
  function grow() { const t = $('ta'); t.style.height = 'auto'; t.style.height = Math.min(t.scrollHeight, 144) + 'px'; paintSend(); }
  function paintSend() {
    const b = $('send'), out = S.errKind === 'credits', has = !!($('ta').value.trim() || S.atts.length), stopMode = S.busy && !has;
    b.classList.toggle('stop', stopMode); b.setAttribute('aria-label', stopMode ? 'Stop' : S.busy ? 'Send next' : 'Send'); b.title = stopMode ? 'Stop' : S.busy ? 'Send next, after this reply' : 'Send';
    b.disabled = !S.busy && (out || !has);
    const t = S.tab, school = !!(t && /^https?:/.test(t.url || '') && isSchool(t.url));
    $('ta').disabled = out; $('ta').placeholder = out ? 'Tokens are back at midnight (UTC)' : S.busy ? 'Add more now, or press Stop' : school ? 'Ask for a hint, or check your answer' : 'Ask about this page';
  }
  function paintQuick() {
    const q = $('quick'); q.replaceChildren();
    q.hidden = !S.msgs.length && !S.busy && !S.qBusy;   // the home cards say the same, so show the chips only once a chat has started
    const school = S.tab && isSchool(S.tab.url);
    for (const [label, text, o] of QUICK) {
      const b = el('button', o && o.act ? 'go1' : '', esc(label)); b.type = 'button'; b.disabled = S.busy || S.errKind === 'credits' || (o && o.act === 'questions' && S.qBusy);
      b.onclick = () => (o && o.act === 'questions' ? findQuestions() : send(text, o || {})); q.appendChild(b);
    }
  }
  $('ta').addEventListener('input', grow);
  $('ta').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); send($('ta').value); } });
  $('ta').addEventListener('paste', (e) => {
    const fs = Array.from((e.clipboardData && e.clipboardData.files) || []); if (fs.length) { e.preventDefault(); addFiles(fs); return; }
    const t = (e.clipboardData && e.clipboardData.getData('text/plain')) || '';
    if ((t.length > 1200 || t.split('\n').length > 14) && S.atts.length < 4) { e.preventDefault(); S.atts.push({ name: 'Pasted text', pasted: true, text: t.slice(0, 20000), cut: t.length > 20000 }); paintAtts(); paintSend(); }   // a long paste is kept as a tidy card, not a wall of words
  });
  $('send').onclick = () => { const has = !!($('ta').value.trim() || S.atts.length); if (S.busy && !has) stop(); else send($('ta').value); };
  $('attach').onclick = () => $('file').click();
  $('file').onchange = () => { addFiles($('file').files); $('file').value = ''; };
  $('scope').onclick = () => { S.scope = S.scope === 'page' ? 'screen' : 'page'; store.set({ scope: S.scope }); paintScope(); S.page = null; paintPage(); };
  const paintScope = () => { $('scope').textContent = S.scope === 'page' ? 'Whole page' : 'On screen'; $('scope').title = S.scope === 'page' ? 'Coe reads the whole page. Press to read only what is on screen.' : 'Coe reads only what is on screen. Press to read the whole page.'; };

  // ------------------------------------------------------------------ the three screens, and the buttons at the bottom
  const bg = (m) => new Promise((ok) => chrome.runtime.sendMessage(m, (r) => ok(chrome.runtime.lastError ? null : r)));
  function view(name) { for (const id of ['signin', 'setup', 'chat', 'chats']) $(id).hidden = id !== name; closeMenu(); }
  const closeMenu = () => { $('menu').hidden = true; $('more').setAttribute('aria-expanded', 'false'); };
  $('more').onclick = (e) => { e.stopPropagation(); const o = $('menu').hidden; $('menu').hidden = !o; $('more').setAttribute('aria-expanded', String(o)); };
  document.addEventListener('click', (e) => { if (!$('menu').contains(e.target)) closeMenu(); });
  function newChat(temp) {
    if (S.busy) stop();
    S.msgs = []; S.atts = []; S.tx = []; S.qs = null; S.queue = []; S.chatId = 'c' + Date.now().toString(36); S.temp = !!temp;
    S.find = ''; $('find').hidden = true; $('find-q').value = '';
    $('app').classList.toggle('temp', S.temp); $('m-temp').textContent = S.temp ? 'Leave private chat' : 'Private chat (temporary)';
    paintAtts(); paintQueue(); clearErr(); view('chat'); renderMsgs(); paintQuick(); paintSend(); setTimeout(() => $('ta').focus(), 50);
  }
  $('n-chats').onclick = () => openChats();
  $('n-new').onclick = () => newChat(false);
  $('n-set').onclick = () => showSetup();
  $('m-find').onclick = () => { closeMenu(); openFind(); };
  $('m-temp').onclick = () => { closeMenu(); newChat(!S.temp); };
  $('m-save').onclick = () => {
    closeMenu(); const rows = S.msgs.filter((m) => m.text && !m.hidden); if (!rows.length) return;
    saveFile('coe-mini-chat.md', '# ' + first((S.tx.find((x) => x.r === 'u') || { t: 'Coe Mini chat' }).t, 60) + '\n\n' + rows.map((m) => '**' + (m.role === 'user' ? 'Me' : 'Coe') + '**\n\n' + m.text).join('\n\n---\n\n'), 'text/markdown');
  };
  $('m-coe').onclick = () => { closeMenu(); chrome.runtime.sendMessage({ type: 'open-coe' }); };
  $('m-hand').onclick = () => { closeMenu(); const t = S.msgs.filter((m) => m.text).map((m) => (m.role === 'user' ? 'Me: ' : 'Coe: ') + m.text).join('\n\n'); if (t) chrome.runtime.sendMessage({ type: 'handoff', text: 'We were talking about a page. Here is the chat so far:\n\n' + t.slice(0, 5000) + '\n\nContinue from here.' }); };
  $('m-clear').onclick = () => { closeMenu(); clearMarks(); };

  // ---- find in this chat
  function openFind() { if ($('chat').hidden) return; $('find').hidden = false; $('find-q').focus(); $('find-q').select(); }
  function clearFind() { const b = $('msgs'); b.querySelectorAll('mark.f').forEach((m) => m.replaceWith(document.createTextNode(m.textContent))); b.normalize(); }
  function closeFind() { S.find = ''; $('find').hidden = true; $('find-q').value = ''; $('find-n').textContent = ''; clearFind(); $('ta').focus(); }
  function applyFind(jump) {
    clearFind(); const q = S.find.trim(), box = $('msgs');
    if (!q) { $('find-n').textContent = ''; S.fn = 0; return; }
    const rx = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), nodes = [];
    const w = document.createTreeWalker(box, NodeFilter.SHOW_TEXT, { acceptNode: (n) => (n.parentElement && !n.parentElement.closest('.ts,.mb,.katex,.mx,.tempbar,button,script') && /\S/.test(n.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT) });
    while (w.nextNode()) nodes.push(w.currentNode);
    const marks = [];
    for (const n of nodes) {
      const t = n.nodeValue; rx.lastIndex = 0; let m, at = 0, frag = null;
      while ((m = rx.exec(t))) { if (!m[0]) { rx.lastIndex++; continue; } frag = frag || document.createDocumentFragment(); if (m.index > at) frag.appendChild(document.createTextNode(t.slice(at, m.index))); const k = el('mark', 'f'); k.textContent = m[0]; frag.appendChild(k); marks.push(k); at = m.index + m[0].length; }
      if (frag) { if (at < t.length) frag.appendChild(document.createTextNode(t.slice(at))); n.replaceWith(frag); }
    }
    S.fn = marks.length; if (S.fi >= marks.length) S.fi = 0;
    $('find-n').textContent = marks.length ? (S.fi + 1) + ' of ' + marks.length : 'None';
    if (marks.length) { marks[S.fi].classList.add('cur'); if (jump) marks[S.fi].scrollIntoView({ block: 'center' }); }
  }
  $('find-q').addEventListener('input', () => { S.find = $('find-q').value; S.fi = 0; applyFind(true); });
  const stepFind = (d) => { if (!S.fn) return; S.fi = (S.fi + d + S.fn) % S.fn; applyFind(true); };
  $('find-q').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); stepFind(e.shiftKey ? -1 : 1); } });
  $('find-nx').onclick = () => stepFind(1); $('find-p').onclick = () => stepFind(-1); $('find-x').onclick = closeFind;
  addEventListener('keydown', (e) => { if ((e.ctrlKey || e.metaKey) && !e.shiftKey && e.key.toLowerCase() === 'f' && !$('chat').hidden) { e.preventDefault(); openFind(); } else if (e.key === 'Escape' && !$('find').hidden && $('dlg').hidden) closeFind(); });

  // ---- your chats: the ones made in this sidebar, and the ones on your Coe account
  const DAYMS = 86400000;
  const groupOf = (t) => { const d = new Date(); d.setHours(0, 0, 0, 0); const x = +d; return t >= x ? 'Today' : t >= x - DAYMS ? 'Yesterday' : t >= x - 6 * DAYMS ? 'Last 7 days' : 'Older'; };
  async function openChats() { S.ch.sel = false; S.ch.picked = new Set(); S.ch.q = ''; S.ch.confirm = false; $('ch-q').value = ''; view('chats'); await paintChats(); loadRemote(); }
  async function loadRemote() { S.ch.remote = null; paintChats(); const r = await bg({ type: 'chats-list' }); S.ch.remote = r && r.ok ? r.items : (r && r.code) || 'network'; paintChats(); }
  async function chatItems() {
    const o = await store.get('chats'), local = Array.isArray(o.chats) ? o.chats : [], rem = Array.isArray(S.ch.remote) ? S.ch.remote : [];
    const remById = new Map(rem.map((x) => [x.id, x])), used = new Set();
    const items = local.map((x) => { const xid = 'x' + String(x.id).slice(0, 40), r = remById.get(xid); if (r) used.add(xid); return { key: 'm:' + x.id, src: 'mini', id: x.id, xid: r ? xid : '', title: x.title || 'Chat', t: x.t || 0, arch: !!x.arch, host: x.host, rec: x }; });
    for (const r of rem) if (!used.has(r.id)) items.push({ key: 'c:' + r.id, src: 'coe', id: r.id, title: r.title, t: r.t, arch: r.arch });
    return items;
  }
  async function paintChats() {
    if ($('chats').hidden) return;
    const all = await chatItems(), q = S.ch.q.trim().toLowerCase(), host = $('ch-list');
    const list = all.filter((x) => !!x.arch === S.ch.arch && (!q || x.title.toLowerCase().includes(q) || (x.rec && (x.rec.msgs || []).some((m) => String(m.t).toLowerCase().includes(q))))).sort((a, b) => b.t - a.t);
    host.replaceChildren();
    const rem = S.ch.remote;
    if (rem === null) host.appendChild(el('p', 'tx note', 'Looking for your Coe chats…'));
    else if (rem === 'signin' || rem === 'setup') { const n = el('div', 'note tx', 'Sign in to see the chats from your account here. '); const b = el('button', 'btn sm gold', 'Sign in'); b.type = 'button'; b.onclick = () => showSignin('a'); n.appendChild(b); host.appendChild(n); }
    else if (typeof rem === 'string') { const n = el('div', 'note tx', 'Could not reach your account. '); const b = el('button', 'btn sm', 'Try again'); b.type = 'button'; b.onclick = loadRemote; n.appendChild(b); host.appendChild(n); }
    if (S.ch.note) host.appendChild(el('p', 'note tx', esc(S.ch.note)));
    let last = '';
    for (const it of list) {
      const g = groupOf(it.t); if (g !== last) { host.appendChild(el('h3', '', esc(g))); last = g; }
      const on = S.ch.picked.has(it.key);
      const b = el('button', 'ci' + (on ? ' on' : ''), (S.ch.sel ? '<span class="ck" aria-hidden="true"></span>' : '') + '<span class="tt"><b>' + esc(it.title) + '</b><span>' + esc((it.host ? it.host + ' · ' : '') + (it.t ? hhmm(it.t) : '')) + '</span></span><span class="tag">' + (it.src === 'mini' ? 'Mini' : 'Coe') + '</span>');
      b.type = 'button'; b.setAttribute('role', 'listitem'); if (S.ch.sel) b.setAttribute('aria-pressed', String(on));
      b.onclick = () => { if (S.ch.sel) { on ? S.ch.picked.delete(it.key) : S.ch.picked.add(it.key); S.ch.confirm = false; paintChats(); } else openItem(it); };
      host.appendChild(b);
    }
    if (!list.length && rem !== null) host.appendChild(el('div', 'pempty', '<span class="logo" aria-hidden="true">' + STAR + '</span><span>' + (q ? 'No chats match.' : S.ch.arch ? 'Nothing archived.' : 'No chats yet. Ask Coe about a page and it shows up here.') + '</span>'));
    $('ch-sel').setAttribute('aria-pressed', String(S.ch.sel)); $('ch-sel').textContent = S.ch.sel ? 'Done' : 'Pick'; $('ch-arch').setAttribute('aria-pressed', String(S.ch.arch));
    const n = S.ch.picked.size; $('ch-bar').hidden = !S.ch.sel || !n; $('ch-n').textContent = n + ' picked'; $('ch-a').textContent = S.ch.arch ? 'Unarchive' : 'Archive'; $('ch-d').textContent = S.ch.confirm ? 'Sure? Delete' : 'Delete';
  }
  async function openItem(it) {
    S.ch.note = '';
    let rows;
    if (it.src === 'mini') { rows = it.rec.msgs || []; S.chatId = it.rec.id; }
    else {
      const r = await bg({ type: 'chat-get', id: it.id });
      if (!r || !r.ok) { S.ch.note = 'Could not open that chat. Try again.'; paintChats(); return; }
      rows = r.msgs; S.chatId = 'c' + Date.now().toString(36);   // carried on here as a new chat, so the one on your account is left as it was
    }
    S.msgs = rows.map((x) => ({ role: x.r === 'u' ? 'user' : 'assistant', text: x.t, at: x.at })); S.tx = rows.map((x) => ({ ...x }));
    S.temp = false; $('app').classList.remove('temp'); S.qs = null; S.atts = []; S.queue = []; S.find = ''; $('find').hidden = true; paintAtts(); paintQueue(); clearErr(); showChat();
    setTimeout(() => { const b = $('msgs'); b.scrollTop = b.scrollHeight; }, 30);
  }
  $('ch-q').addEventListener('input', () => { S.ch.q = $('ch-q').value; paintChats(); });
  $('ch-x').onclick = () => showChat();
  $('ch-new').onclick = () => newChat(false);
  $('ch-priv').onclick = () => newChat(true);
  $('ch-sel').onclick = () => { S.ch.sel = !S.ch.sel; S.ch.picked = new Set(); S.ch.confirm = false; paintChats(); };
  $('ch-arch').onclick = () => { S.ch.arch = !S.ch.arch; S.ch.picked = new Set(); paintChats(); };
  async function bulk(op) {
    const all = await chatItems(), picked = all.filter((x) => S.ch.picked.has(x.key)); if (!picked.length) return;
    const mini = new Set(picked.filter((x) => x.src === 'mini').map((x) => x.id)), coe = picked.flatMap((x) => (x.src === 'coe' ? [x.id] : x.xid ? [x.xid] : []));
    const o = await store.get('chats'); let list = Array.isArray(o.chats) ? o.chats : [];
    list = op === 'delete' ? list.filter((x) => !mini.has(x.id)) : list.map((x) => (mini.has(x.id) ? { ...x, arch: op === 'archive' } : x));
    await store.set({ chats: list }); S.ch.note = '';
    if (coe.length) { const r = await bg({ type: 'chat-op', op, ids: coe }); if (!r || !r.ok) S.ch.note = 'Your Coe account could not be changed just now. The chats saved here were.'; }
    S.ch.picked = new Set(); S.ch.confirm = false; S.ch.sel = false; await paintChats(); if (coe.length) loadRemote();
  }
  $('ch-a').onclick = () => bulk(S.ch.arch ? 'unarchive' : 'archive');
  $('ch-d').onclick = () => { if (!S.ch.confirm) { S.ch.confirm = true; paintChats(); setTimeout(() => { if (S.ch.confirm) { S.ch.confirm = false; paintChats(); } }, 4000); return; } bulk('delete'); };

  // ---- a reply is ready: a short beep and a tick on the toolbar button, but only when you are looking at another tab
  let actx = null;
  function tone() {
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)(); const t = actx.currentTime;
      [[660, 0], [880, 0.12]].forEach(([f, d]) => { const o = actx.createOscillator(), g = actx.createGain(); o.type = 'square'; o.frequency.value = f; g.gain.setValueAtTime(0.0001, t + d); g.gain.exponentialRampToValueAtTime(0.06, t + d + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.11); o.connect(g); g.connect(actx.destination); o.start(t + d); o.stop(t + d + 0.12); });
    } catch { /* no sound here */ }
  }
  function replyReady() {
    if (!S.beep || (document.hasFocus() && !document.hidden)) return;
    tone(); try { chrome.action.setBadgeText({ text: '✓' }); chrome.action.setBadgeBackgroundColor({ color: '#337957' }); } catch { /* no badge here */ }
  }
  addEventListener('focus', () => { try { chrome.action.setBadgeText({ text: '' }); } catch { /* no badge */ } });

  // ---- voice typing: speak and it types (where the browser can listen)
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  let rec = null;
  if (SR && !FF) $('mic').hidden = false;
  $('mic').onclick = () => {
    if (rec) { try { rec.stop(); } catch { /* done */ } return; }
    const r = new SR(), base = $('ta').value; rec = r; r.lang = navigator.language || 'en-GB'; r.interimResults = true; r.continuous = false; $('mic').classList.add('on'); $('mic').setAttribute('aria-pressed', 'true');
    r.onresult = (e) => { let t = ''; for (let i = 0; i < e.results.length; i++) t += e.results[i][0].transcript; $('ta').value = (base && !/\s$/.test(base) ? base + ' ' : base) + t; grow(); };
    r.onerror = (e) => { if (e.error === 'not-allowed' || e.error === 'service-not-allowed') showErr('other', 'The microphone is blocked. Allow it for Coe Mini in the browser settings, then try again.'); else if (e.error !== 'no-speech' && e.error !== 'aborted') showErr('other', 'Voice typing did not work here. You can type instead.'); };
    r.onend = () => { rec = null; $('mic').classList.remove('on'); $('mic').setAttribute('aria-pressed', 'false'); $('ta').focus(); };
    try { r.start(); } catch { rec = null; $('mic').classList.remove('on'); }
  };

  // ---- the sidebar can be dragged to any width or height: keep the bottom in view, redraw what depends on the width, never break
  let stuck = true, rzT = 0, lastW = 0, lastH = 0;
  $('msgs').addEventListener('scroll', () => { const b = $('msgs'); stuck = b.scrollHeight - b.scrollTop - b.clientHeight < 40; }, { passive: true });
  new ResizeObserver(() => {
    const w = document.documentElement.clientWidth, h = document.documentElement.clientHeight;
    document.documentElement.style.setProperty('--pw', w + 'px'); document.documentElement.style.setProperty('--ph', h + 'px');
    if (Math.abs(w - lastW) < 16 && Math.abs(h - lastH) < 16) return;
    const wider = Math.abs(w - lastW) >= 16; lastW = w; lastH = h; clearTimeout(rzT);
    rzT = setTimeout(() => {
      if (!$('chat').hidden) { grow(); if (wider && S.msgs.some((m) => /```(mindmap|chart)/.test(m.text || ''))) renderMsgs(); if (stuck) { const b = $('msgs'); b.scrollTop = b.scrollHeight; } }
    }, 100);
  }).observe(document.documentElement);

  // ------------------------------------------------------------------ you and your tokens
  function setMeter(c) {
    const m = $('meter'); if (!c || !c.limit) { m.hidden = true; return; }
    const pct = Math.min(100, Math.round((c.used / c.limit) * 100)); m.hidden = pct < 80; m.firstElementChild.style.width = pct + '%';
    m.classList.toggle('hot', pct >= 90 && pct < 100); m.classList.toggle('out', pct >= 100);
    m.title = Math.max(0, Math.round((c.limit - c.used) / 1000)) + 'k of ' + Math.round(c.limit / 1000) + 'k tokens left today';
    if (pct >= 100) { if (S.errKind !== 'credits') showErr('credits'); } else if (S.errKind === 'credits') clearErr();
    paintSend(); paintQuick();
  }
  async function refreshStatus() {
    const r = await new Promise((ok) => chrome.runtime.sendMessage({ type: 'status' }, (x) => ok(chrome.runtime.lastError ? null : x)));
    S.status = r; if (r && r.ok && r.limit != null) setMeter({ used: r.used, limit: r.limit });
    const e = await store.get('site'); if (e.site) site = e.site;
    return r;
  }
  chrome.storage.onChanged.addListener((c) => { if (c.speed && c.speed.newValue && c.speed.newValue !== S.speed) { S.speed = c.speed.newValue; paintSetup(); } if (c.chats && !$('chats').hidden) paintChats(); if (c.session || c.ext || c.serverUrl) refreshStatus().then(paintSetup); if (c.connected) { if (c.connected.newValue) justConnected(); else if (!$('setup').hidden) paintConnect(); } if (c.session && !c.session.newValue && c.session.oldValue && !S.guest && $('signin').hidden && !$('chat').hidden) showSignin('a'); if (c.askTabs) { S.askTabs = c.askTabs.newValue === 'allow' ? 'allow' : 'ask'; paintSwitches(); } if (c.askChg) { S.askChg = c.askChg.newValue === 'allow' ? 'allow' : 'ask'; paintSwitches(); } if (c.me && !$('setup').hidden) loadProfile(); if (c.scope && c.scope.newValue && c.scope.newValue !== S.scope) { S.scope = c.scope.newValue; paintScope(); S.page = null; paintPage(); paintSetup(); } });

  // ------------------------------------------------------------------ the setup screen
  /** Settings. It is only opened from the menu: the very first screen is the sign-in one. */
  function showSetup() {
    view('setup');
    loadProfile(); paintSwitches(); refreshStatus().then(paintSetup); paintSiteBtn($('s1site'));
  }
  // ---- the first screen: sign in or sign up (an emailed code, to the same account as Coe), then an optional "Connect with Coe?".
  // Everything else (name, choices) comes with the account or lives in Settings, so nothing is set up twice.
  const CODE_LETTERS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';   // no 0, O, 1 or I: they look alike
  const newCode = () => { const a = new Uint32Array(6); crypto.getRandomValues(a); return Array.from(a, (x) => CODE_LETTERS[x % CODE_LETTERS.length]).join(''); };
  const CODE_LIFE = 15 * 60 * 1000;
  const STAGES = { a: '.si-a', code: '.si-code', link: '.si-link', b: '.si-b', c: '.si-c' };
  let doneT = 0, resendT = 0, mailTo = '';
  const msg = (m) => new Promise((ok) => chrome.runtime.sendMessage(m, (x) => ok(chrome.runtime.lastError ? null : x)));
  function stage(n) {
    $('signin').dataset.stage = n;
    for (const [k, sel] of Object.entries(STAGES)) document.querySelector(sel).hidden = k !== n;
    document.querySelector('#signin .logo').hidden = n === 'c';
    if (n === 'a') setTimeout(() => $('si-email').focus(), 60); if (n === 'code') setTimeout(() => $('si-code-in').focus(), 60);
  }
  const nice = (e) => (/expired|invalid|incorrect/i.test(e || '') ? 'That code is not right, or it ran out. Check it, or press Send again.' : e || 'That did not work. Try again.');
  function paintCode(p) { $('si-c1').textContent = p.code.slice(0, 3); $('si-c2').textContent = p.code.slice(3); }
  async function pairNow(renew) {
    let { pair } = await store.get('pair');
    if (renew || !pair || !pair.code || Date.now() - pair.at > CODE_LIFE - 60000) { pair = { code: newCode(), at: Date.now() }; await store.set({ pair }); }
    paintCode(pair); return pair;
  }
  function openConnect(p) { chrome.runtime.sendMessage({ type: 'open-coe', page: 'connect=' + p.code }); }
  async function showSignin(first) {
    view('signin'); clearTimeout(doneT); paintSiteBtn($('si-site'));
    $('si-err').textContent = ''; $('si-cerr').textContent = '';
    if (first === 'b') { await pairNow(false); stage('b'); return; }
    stage(first === 'link' ? 'link' : 'a');
  }
  function startResend() {
    const b = $('si-resend'); let left = 30; clearInterval(resendT); b.disabled = true; b.textContent = 'Send again in ' + left + 's';
    resendT = setInterval(() => { left--; if (left <= 0) { clearInterval(resendT); b.disabled = false; b.textContent = 'Send again'; } else b.textContent = 'Send again in ' + left + 's'; }, 1000);
  }
  async function sendMail(to) {
    const r = await msg({ type: 'auth-send', email: to });
    if (r && r.ok) { mailTo = to; $('si-to').textContent = to; $('si-code-in').value = ''; stage('code'); startResend(); return true; }
    return r ? r.error : 'Could not reach Coe. Try again.';
  }
  $('si-form').onsubmit = async (e) => {
    e.preventDefault(); const to = $('si-email').value.trim(), er = $('si-err');
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(to)) { er.textContent = 'Type your email, like you@example.com.'; return; }
    er.textContent = ''; $('si-mail').disabled = true; $('si-mail').textContent = 'Sending';
    const r = await sendMail(to); $('si-mail').disabled = false; $('si-mail').textContent = 'Email me a code';
    if (r !== true) { er.textContent = r; paintSiteBtn($('si-site')); }
  };
  $('si-cform').onsubmit = async (e) => {
    e.preventDefault(); const code = $('si-code-in').value.replace(/\D/g, ''), er = $('si-cerr');
    if (code.length < 6) { er.textContent = 'The code has six numbers.'; return; }
    er.textContent = ''; $('si-verify').disabled = true; $('si-verify').textContent = 'Checking';
    const r = await msg({ type: 'auth-verify', email: mailTo, code });
    $('si-verify').disabled = false; $('si-verify').textContent = 'Sign in';
    if (r && r.ok) { clearInterval(resendT); afterSignIn(); } else er.textContent = nice(r && r.error);
  };
  $('si-wrong').onclick = () => { clearInterval(resendT); stage('a'); };
  $('si-resend').onclick = async () => { const r = await sendMail(mailTo); if (r !== true) $('si-cerr').textContent = r; };
  async function afterSignIn() {
    // Signed in. About you comes with the account, so there is nothing to set up.
    S.setupDone = true; S.guest = false; await store.set({ setupDone: true, guest: false });
    await msg({ type: 'about-pull' }); const o = await store.get('me'); S.me = o.me || {}; await refreshStatus();
    stage('link');
  }
  function finishSignin(connected) {
    S.setupDone = true; S.guest = false; store.set({ setupDone: true, guest: false, pair: null, linkAsked: true });
    const nm = String(S.me.name || '').trim();
    $('si-ch').textContent = nm ? 'Hi ' + nm : 'You are in';
    $('si-cl').textContent = connected ? 'Coe Mini and Coe are connected. You can turn that off any time in Settings.' : 'You are signed in. Coe Mini and Coe stay separate, with the same account.';
    stage('c'); clearTimeout(doneT); doneT = setTimeout(showChat, 1500);
  }
  $('si-conn').onclick = async () => { const p = await pairNow(false); stage('b'); openConnect(p); };
  $('si-apart').onclick = () => finishSignin(false);
  $('si-again').onclick = async () => { const p = await pairNow(false); $('si-s').className = 'state wait tx'; $('si-s').textContent = 'Waiting for you'; openConnect(p); };
  $('si-new').onclick = async () => { const p = await pairNow(true); $('si-s').className = 'state wait tx'; $('si-s').textContent = 'Waiting for you'; openConnect(p); };
  $('si-back').onclick = async () => { await store.set({ pair: null }); if (S.setupDone && !(await store.get('linkAsked')).linkAsked) stage('link'); else { S.me = (await store.get('me')).me || {}; showChat(); } };
  $('si-skip').onclick = () => { S.guest = true; store.set({ guest: true }); showChat(); };
  /** Coe Mini and Coe were just connected (the person pressed Connect on Coe, and the code matched). */
  function justConnected() { if ($('signin').hidden || $('signin').dataset.stage !== 'b') { if (!$('setup').hidden) paintConnect(); return; } finishSignin(true); }
  function showChat() { view('chat'); refreshTab(); renderMsgs(); paintQuick(); paintSend(); paintQueue(); setTimeout(() => $('ta').focus(), 50); }
  function paintSetup() {
    const r = S.status, ok = r && r.ok && r.signedIn;
    $('s1').classList.toggle('ok', !!ok);
    const s = $('s1s'); s.className = 'state tx' + (ok ? '' : r && !r.ok && r.code === 'network' ? ' bad' : '');
    $('s1b').textContent = ok ? 'Open Coe' : 'Sign in'; $('s1o').hidden = !ok;
    s.textContent = ok ? 'Signed in' + (r.email ? ' as ' + r.email : '') : !r ? 'Checking' : r.ok ? 'Not signed in.' : r.code === 'setup' ? 'Press Sign in.' : r.error || '';
    paintConnect();
    document.querySelectorAll('.opt[data-scope]').forEach((o) => o.setAttribute('aria-checked', String(o.dataset.scope === S.scope)));
    document.querySelectorAll('.opt[data-speed]').forEach((o) => o.setAttribute('aria-checked', String(o.dataset.speed === S.speed)));
  }
  async function paintConnect() {
    const on = !!(await store.get('connected')).connected, b = $('conn');
    b.setAttribute('aria-checked', String(on)); $('s1c').classList.toggle('ok', on);
    $('conn-p').textContent = on ? 'Connected. About you, settings and Coe Mini chats show in both.' : 'Not connected. Coe Mini and Coe stay separate. They still use the same account.';
  }
  $('conn').onclick = async () => {
    const on = !!(await store.get('connected')).connected;
    if (on) { await store.set({ connected: false, pair: null }); paintConnect(); return; }
    if (!(S.status && S.status.ok && S.status.signedIn)) { showSignin('a'); return; }
    await showSignin('b'); const { pair } = await store.get('pair'); if (pair) openConnect(pair);
  };
  /** Firefox only lets an add-on see a website after you say yes. Coe Mini needs to see the Coe site to find your sign-in. */
  async function paintSiteBtn(b) {
    if (!FF) { b.hidden = true; return; }
    let has = false; try { has = await chrome.permissions.contains({ origins: [siteBase() + '*'] }); } catch { /* unknown */ }
    b.hidden = has; b.onclick = async () => { let ok = false; try { ok = await chrome.permissions.request({ origins: [siteBase() + '*'] }); } catch { /* not allowed */ } if (ok) { b.hidden = true; chrome.runtime.sendMessage({ type: 'open-coe', page: 'signin' }); } };
  }

  // ---- about you
  const PF = { name: 'pf-name', ageBand: 'pf-age', role: 'pf-role', yearOrJob: 'pf-level', subjects: 'pf-subj', length: 'pf-len', aboutText: 'pf-about', system: 'pf-sys', maxWords: 'pf-max', tone: 'pf-tone' };
  const PFDEF = { length: 'balanced', maxWords: '0', tone: 'friendly' };
  const PFMAX = { subjects: 100, aboutText: 700, system: 1500 };
  const LVL = { student: ['Year or course', 'Year 10, A level'], teacher: ['What you teach', 'Maths, KS3 science'], parent: ['Your child’s year (if you like)', 'Year 7'], working: ['Your job', 'Nurse, builder'], other: ['What you do', 'Hobbies, a project'], '': ['Year, course or job', 'Year 10, A level, nurse'] };
  async function loadProfile() {
    const o = await store.get('me'); S.me = o.me || {};
    for (const [k, id] of Object.entries(PF)) { const e = $(id); if (e) e.value = S.me[k] != null && S.me[k] !== '' ? S.me[k] : (PFDEF[k] || ''); }
    paintLvl(); paintProfileState(); CX.paintCounts && CX.paintCounts();
  }
  function paintLvl() { const l = LVL[$('pf-role').value] || LVL['']; $('pf-lvl-l').textContent = l[0]; $('pf-level').placeholder = l[1]; }
  function paintProfileState() { const any = ['name', 'ageBand', 'role', 'yearOrJob', 'subjects'].some((k) => S.me[k]); $('s2').classList.toggle('ok', any); $('s2s').textContent = any ? 'Saved. Coe will use this, and so will the Coe website.' : ''; $('s2s').className = 'state tx'; }
  let pfT = 0;
  function saveProfile() {
    const me = { ...S.me }; for (const [k, id] of Object.entries(PF)) me[k] = String($(id).value || '').trim().slice(0, PFMAX[k] || 60);
    me.maxWords = Number(me.maxWords) || 0; me.at = Date.now(); S.me = me; paintLvl();
    clearTimeout(pfT); pfT = setTimeout(async () => { await store.set({ me }); paintProfileState(); chrome.runtime.sendMessage({ type: 'about-push' }); }, 250);
  }
  for (const id of Object.values(PF)) { const e = $(id); e.addEventListener('input', saveProfile); e.addEventListener('change', saveProfile); }

  // ---- what Coe may do
  function paintSwitches() { $('beep').setAttribute('aria-checked', String(S.beep)); $('ask-tabs').setAttribute('aria-checked', String(S.askTabs !== 'allow')); $('ask-chg').setAttribute('aria-checked', String(S.askChg !== 'allow')); }
  $('ask-tabs').onclick = () => { S.askTabs = S.askTabs === 'allow' ? 'ask' : 'allow'; store.set({ askTabs: S.askTabs }); paintSwitches(); };
  $('ask-chg').onclick = () => { S.askChg = S.askChg === 'allow' ? 'ask' : 'allow'; store.set({ askChg: S.askChg }); paintSwitches(); };
  document.querySelectorAll('.opt[data-scope]').forEach((o) => { o.onclick = () => { S.scope = o.dataset.scope; store.set({ scope: S.scope }); paintScope(); paintSetup(); $('s3').classList.add('ok'); }; });
  document.querySelectorAll('.opt[data-speed]').forEach((o) => { o.onclick = () => { S.speed = o.dataset.speed; store.set({ speed: S.speed }); paintSetup(); }; });
  $('beep').onclick = () => { S.beep = !S.beep; store.set({ beep: S.beep }); $('beep').setAttribute('aria-checked', String(S.beep)); if (S.beep) tone(); };
  $('s2all').onclick = async () => {
    const st = $('s3s'); let ok = false;
    try { ok = await chrome.permissions.request({ origins: ['http://*/*', 'https://*/*'] }); } catch { /* not allowed */ }
    st.className = 'state tx' + (ok ? '' : ' bad'); st.textContent = ok ? 'Done. Coe will not ask for each site. It still reads only when you ask.' : 'The browser did not allow that. Coe will ask for each site instead.';
  };
  $('s1b').onclick = () => { if (S.status && S.status.ok && S.status.signedIn) chrome.runtime.sendMessage({ type: 'open-coe' }); else showSignin('a'); };
  $('s1o').onclick = async () => { await msg({ type: 'sign-out' }); S.guest = false; S.status = null; await store.set({ guest: false, linkAsked: false }); showSignin('a'); };
  $('s3b').onclick = async () => {
    const st = $('s4s'); st.className = 'state tx'; st.textContent = 'Reading';
    await refreshTab();
    try { const p = await readTab(S.scope); st.textContent = 'Read ' + p.text.length.toLocaleString() + ' letters from “' + first(p.title, 40) + '”.'; $('s4').classList.add('ok'); }
    catch (e) {
      if (e && e.code === 'allow') { st.textContent = 'Press the button again after you allow this site.'; try { const ok = await chrome.permissions.request({ origins: [e.origin] }); if (ok) { $('s3b').click(); } else { st.className = 'state tx bad'; st.textContent = 'The browser did not allow that site.'; } } catch { st.className = 'state tx bad'; st.textContent = 'Open a website first, then try again.'; } }
      else { st.className = 'state tx bad'; st.textContent = 'Open a website first, then try again.'; }
    }
  };
  $('done').onclick = showChat;
  // While Coe is waiting for the code to be matched, look for it, and say when the code has run out.
  setInterval(() => { if (!$('signin').hidden && $('signin').dataset.stage === 'b') store.get(['connected', 'pair']).then((o) => { if (o.connected) justConnected(); else if (!o.pair || Date.now() - o.pair.at > CODE_LIFE) { $('si-s').className = 'state bad tx'; $('si-s').textContent = 'That code ran out. Press New code.'; } }); else if (!$('setup').hidden && !(S.status && S.status.ok && S.status.signedIn)) refreshStatus().then(paintSetup); }, 1500);

  // ------------------------------------------------------------------ start
  (async () => {
    const o = await store.get(['scope', 'setupDone', 'site', 'askTabs', 'askChg', 'me', 'speed', 'beep', 'session', 'guest']);
    S.speed = ['swift', 'core', 'deep'].includes(o.speed) ? o.speed : 'core'; S.beep = o.beep !== false;
    if (o.scope === 'screen') S.scope = 'screen'; if (o.site) site = o.site; paintScope();
    S.askTabs = o.askTabs === 'allow' ? 'allow' : 'ask'; S.askChg = o.askChg === 'allow' ? 'allow' : 'ask'; S.me = o.me || {};
    S.guest = !!o.guest; const has = !!(o.session && o.session.access);
    S.setupDone = has || !!o.setupDone; await refreshTab();
    // The first thing anyone sees is sign in or sign up. Someone who is signed in goes straight to the chat, with nothing to set up.
    if (!has && !S.guest) { showSignin('a'); return; }
    if (has && !o.setupDone) store.set({ setupDone: true });
    showChat();
    refreshStatus().then((r) => { if (r && r.ok && !r.signedIn && !S.guest) showSignin('a'); else if (r && r.ok && r.signedIn) chrome.runtime.sendMessage({ type: 'about-pull' }); });   // the sign-in ran out, or the account may know more about you
  })();
  Object.assign(CX, { connect, setMeter, callJson, findQuestions, S, $, el, esc, send, bg, openDlg, closeDlg, renderMsgs, mdInline, mdBlock, saveFile, showErr, clearErr, newChat, showSetup, view, closeMenu, jsonOf, bkBtn, msgsWidth, siteBase: () => siteBase(), first, icon, X, store, tell, paintQuick, showChat, openChats: () => openChats(), openFind, paintSend, grow, setMeter, hhmm, readTab });
  CX.ready.forEach((f) => { try { f(CX); } catch (e) { console.error(e); } });
  window.__coe = { S, send, readTab, CX };   // for testing
})();
