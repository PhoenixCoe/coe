// Runs on coe.pmcstudios.uk only. It does these jobs:
// 1. hands the extension your Coe sign-in, server address and About you answers, so you never type them twice;
// 2. lets the Coe site read and change the extension's settings (the Chrome tab in Coe's Settings);
// 3. sends back what you changed in the sidebar (About you, chats, tokens given back), so the Coe site shows it too;
// 4. delivers "Continue this chat in Coe" from the sidebar into a new Coe chat.
(() => {
  const api = typeof browser !== 'undefined' && browser.runtime ? browser : chrome;
  const read = (k) => { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch { return null; } };
  const send = () => {
    try {
      const s = read('pmc:coe:settings') || {};
      const me = { name: String(s.name || '').slice(0, 30), ageBand: s.ageBand || '', role: s.role || '', yearOrJob: String(s.yearOrJob || '').slice(0, 60), subjects: String(s.subjects || '').slice(0, 100), length: s.length || '', easy: !!s.easy, tone: s.tone || '', replyLang: String(s.replyLang || '').slice(0, 30), about: String(s.about || '').slice(0, 400), system: String(s.system || '').slice(0, 300), at: Number(s.profileAt) || 0 };
      api.runtime.sendMessage({ type: 'sync', session: read('pmc:coe:session'), ext: read('pmc:coe:ext'), code: s.code || '', serverUrl: s.serverUrl || '', site: location.origin, me }, (r) => {
        try { void api.runtime.lastError; } catch { /* none */ }
        if (r && r.profile && ready) post({ type: 'profile', me: r.profile });   // the sidebar has newer About you answers than this site
      });
    } catch { /* the extension was reloaded; this page will be refreshed next time */ }
  };
  const prefs = async () => { const o = await api.storage.local.get(['scope', 'speed', 'askTabs', 'askChg']); return { scope: o.scope === 'screen' ? 'screen' : 'page', speed: ['swift', 'core', 'deep'].includes(o.speed) ? o.speed : 'core', askTabs: o.askTabs === 'allow' ? 'allow' : 'ask', askChg: o.askChg === 'allow' ? 'allow' : 'ask' }; };
  const post = (m) => postMessage({ coe: 'from-ext', ...m }, location.origin);
  let ready = false;
  const deliver = async () => {
    if (!ready) return;
    try {
      const { handoff } = await api.storage.local.get('handoff');
      if (handoff && handoff.text && Date.now() - handoff.ts < 600000) { post({ type: 'handoff', text: String(handoff.text).slice(0, 6000) }); }
      if (handoff) await api.storage.local.remove('handoff');
      const { refunds, chats, me } = await api.storage.local.get(['refunds', 'chats', 'me']);   // what the sidebar did: Coe shows it in its history and in Settings > Usage > Refunds
      if (Array.isArray(refunds) && refunds.length) post({ type: 'refunds', items: refunds.slice(0, 50) });
      if (Array.isArray(chats) && chats.length) post({ type: 'chats', items: chats.slice(0, 30) });
      if (me && me.at) { if (Number((read('pmc:coe:settings') || {}).profileAt) > me.at) send(); else post({ type: 'profile', me }); }   // the older copy gets put right, never the newer one
    } catch { /* reloaded */ }
  };
  addEventListener('message', async (e) => {
    const d = e.data;
    if (e.source !== window || !d || d.coe !== 'to-ext') return;
    try {
      if (d.type === 'hello') { ready = true; post({ type: 'hello', version: api.runtime.getManifest().version, browser: /Firefox\//.test(navigator.userAgent) ? 'firefox' : 'chrome', prefs: await prefs() }); send(); deliver(); }
      if (d.type === 'refunds-ack' && Array.isArray(d.ids)) {
        const { refunds } = await api.storage.local.get('refunds');
        await api.storage.local.set({ refunds: (Array.isArray(refunds) ? refunds : []).filter((x) => !d.ids.includes(x.id)) });
      }
      if (d.type === 'set' && d.prefs) {
        const p = d.prefs, o = {};
        if (p.scope === 'page' || p.scope === 'screen') o.scope = p.scope;
        if (['swift', 'core', 'deep'].includes(p.speed)) o.speed = p.speed;
        if (p.askTabs === 'ask' || p.askTabs === 'allow') o.askTabs = p.askTabs;
        if (p.askChg === 'ask' || p.askChg === 'allow') o.askChg = p.askChg;
        await api.storage.local.set(o); post({ type: 'prefs', prefs: await prefs() });
      }
    } catch { /* the extension was reloaded */ }
  });
  try { api.storage.onChanged.addListener((c) => { if (c.scope || c.speed || c.askTabs || c.askChg) prefs().then((p) => ready && post({ type: 'prefs', prefs: p })); if (c.handoff || c.refunds || c.chats || c.me) deliver(); }); } catch { /* reloaded */ }
  send(); setTimeout(send, 2500); setTimeout(send, 7000);
  setInterval(send, 60000);
  addEventListener('storage', send);
  let sendT = 0; addEventListener('pmc:coe-settings', () => { clearTimeout(sendT); sendT = setTimeout(send, 400); });   // changed on this page: pass it on at once
  document.addEventListener('visibilitychange', () => { if (!document.hidden) send(); });
})();
