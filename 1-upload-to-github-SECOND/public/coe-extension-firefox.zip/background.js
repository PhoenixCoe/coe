// The extension's brain. It holds your Coe sign-in, talks to your Coe server (the page itself never does), and keeps the answers in a fixed shape.
const store = {
  get: (k) => chrome.storage.local.get(k),
  set: (o) => chrome.storage.local.set(o),
};

const cfg = async () => {
  const s = await store.get(['session', 'ext', 'code', 'serverUrl', 'me', 'speed']);
  const server = String((s.ext && s.ext.server) || s.serverUrl || '').trim().replace(/\/+$/, '');
  return { ...s, server };
};

let waiting = null;
// Coe's own tab refreshes the sign-in when it opens. So when it has run out, open Coe quietly, wait for it, and close it again.
function refreshViaSite() {
  if (waiting) return waiting;
  waiting = new Promise((resolve) => {
    let tabId = null, done = false;
    const finish = (ok) => { if (done) return; done = true; waiting = null; chrome.runtime.onMessage.removeListener(on); if (tabId != null) chrome.tabs.remove(tabId).catch(() => {}); resolve(ok); };
    const on = (m, sender) => { if (m && m.type === 'sync' && sender.tab && sender.tab.id === tabId && m.session && m.session.exp - Date.now() > 60000) setTimeout(() => finish(true), 300); };
    chrome.runtime.onMessage.addListener(on);
    chrome.tabs.create({ url: 'https://coe.pmcstudios.uk/', active: false }).then((t) => { tabId = t.id; }).catch(() => finish(false));
    setTimeout(() => finish(false), 14000);
  });
  return waiting;
}
async function token() {
  let { session } = await store.get('session');
  if (!session || !session.access) return null;
  if (session.exp - Date.now() > 60000) return session.access;
  await refreshViaSite();
  ({ session } = await store.get('session'));
  return session && session.exp > Date.now() ? session.access : null;
}

async function call(path, init, c) {
  const h = { 'content-type': 'application/json', ...(init.headers || {}) };
  const t = await token(); if (t) h.authorization = 'Bearer ' + t;
  if (c.code) h['x-coe-code'] = c.code;
  h['x-coe-ext'] = chrome.runtime.id;   // Chrome may send no Origin for a sidebar with site access, so the server also looks at this
  return fetch(c.server + path, { ...init, headers: h });
}
const why = async (res) => { let m = '', code = ''; try { const j = await res.json(); m = j.error?.message || ''; code = j.error?.code || ''; } catch { /* no body */ } return { ok: false, error: m || `The server said ${res.status}.`, code: code || (res.status === 401 ? 'signin' : res.status === 402 ? 'limit' : '') }; };

async function status() {
  const c = await cfg();
  const { session } = await store.get('session');
  if (!c.server) return { ok: false, code: 'setup', error: 'Open Coe once and sign in, so this extension can find your Coe server.' };
  try {
    const res = await call('/me', { method: 'GET' }, c);
    if (!res.ok) return { ...(await why(res)), signedIn: !!session };
    const j = await res.json();
    return { ok: true, signedIn: !!j.signedIn, email: j.email || (session && session.email) || '', plan: j.plan, used: j.used, limit: j.limit };
  } catch { return { ok: false, code: 'network', error: 'Could not reach the Coe server.' }; }
}

const AGE = { under11: 'under 11', '11-13': '11 to 13', '14-16': '14 to 16', '17-18': '17 to 18', '19-24': '19 to 24', '25+': '25 or over' };
const ROLE = { student: 'a student', teacher: 'a teacher', parent: 'a parent or carer', working: 'working', other: '' };
/** Who Coe is talking to, from the About you answers (set here or on the Coe website). */
const mineOf = (c) => {
  const m = c.me; if (!m) return '';
  const who = [m.name && `Their name is ${m.name} (use it rarely).`, m.ageBand && AGE[m.ageBand] && `Age group: ${AGE[m.ageBand]}.`, m.role && ROLE[m.role] && `They are ${ROLE[m.role]}.`, m.yearOrJob && `Year, course or job: ${m.yearOrJob}.`, m.subjects && `They study or work on: ${m.subjects}.`].filter(Boolean).join(' ');
  const young = m.ageBand === 'under11' || m.ageBand === '11-13' ? ' They are young: use very simple words and short sentences, and keep everything suitable for children.' : '';
  const how = [m.length && `Answer length: ${m.length}.`, m.easy && 'Use simple words and short sentences.', m.tone && `Tone: ${m.tone}.`, m.replyLang && `Reply in ${m.replyLang}.`, m.about && `About them: ${String(m.about).slice(0, 400)}`, m.system && `Their standing instructions: ${String(m.system).slice(0, 400)}`].filter(Boolean).join(' ');
  return [who && 'WHO YOU ARE TALKING TO: ' + who + young + ' Pitch your words, examples and depth to them.', how].filter(Boolean).join('\n');
};

chrome.runtime.onMessage.addListener((m, sender, reply) => {
  if (!m || !m.type) return;
  if (m.type === 'sync') {
    // The newest About you answers win, whether they were typed here or on the Coe website.
    store.get('me').then(({ me }) => {
      const site = m.me || null, mine = me || null, keepMine = mine && mine.at && (!site || !site.at || mine.at > site.at);
      const merged = keepMine ? { ...(site || {}), ...mine } : site ? { ...(mine || {}), ...site } : mine;
      store.set({ session: m.session && m.session.access ? m.session : null, ext: m.ext || null, code: m.code || '', serverUrl: m.serverUrl || '', me: merged, site: m.site || '', coeTab: sender.tab ? sender.tab.id : null });
      reply({ profile: keepMine ? mine : null });
    });
    return true;
  }
  if (m.type === 'search') { search(m.q).then(reply); return true; }
  if (m.type === 'status') { status().then(reply); return true; }
  if (m.type === 'ask') { ask(m.body || {}).then(reply); return true; }
  if (m.type === 'refund') { refund(m.receipts).then(reply); return true; }
  if (m.type === 'open-coe') { openCoe(m.page ? '#' + m.page : '', false); return; }
  if (m.type === 'handoff') { store.set({ handoff: { text: String(m.text || ''), ts: Date.now() } }).then(() => openCoe('', true)); return; }
});

// Brings the open Coe tab to the front, or opens one.
async function openCoe(hash, reuse) {
  const { site, coeTab } = await store.get(['site', 'coeTab']);
  const base = (site || 'https://coe.pmcstudios.uk').replace(/\/+$/, '') + '/';
  if (reuse && coeTab != null) {
    try { const t = await chrome.tabs.get(coeTab); await chrome.tabs.update(t.id, { active: true }); await chrome.windows.update(t.windowId, { focused: true }); return; } catch { /* that tab is gone */ }
  }
  chrome.tabs.create({ url: base + hash });
}

// The sidebar talks to us over a port so the reply can arrive word by word. Closing the port stops the reply.
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'chat') return;
  const ctl = new AbortController();
  port.onDisconnect.addListener(() => ctl.abort());
  port.onMessage.addListener((m) => { if (m && m.type === 'stop') ctl.abort(); else if (m && m.type === 'send') chatStream(m, port, ctl); });
});

async function chatStream(m, port, ctl) {
  const out = (o) => { try { port.postMessage(o); } catch { /* the sidebar closed */ } };
  const c = await cfg();
  if (!c.server) { out({ t: 'err', code: 'setup', error: 'Open Coe once and sign in, so this extension can find your Coe server.' }); return; }
  const mine = mineOf(c);
  const body = { model: m.model || (['swift', 'core', 'deep'].includes(c.speed) ? c.speed : 'core'), stream: true, stream_options: { include_usage: true }, max_completion_tokens: 1800, messages: [{ role: 'system', content: mine ? String(m.system || '') + '\n' + mine : String(m.system || '') }, ...(Array.isArray(m.messages) ? m.messages : [])] };
  let res;
  try { res = await call('/', { method: 'POST', body: JSON.stringify(body), signal: ctl.signal }, c); }
  catch { if (ctl.signal.aborted) { out({ t: 'end', stopped: true }); return; } out({ t: 'err', code: 'network', error: 'Could not reach the Coe server.' }); return; }
  if (!res.ok) { const w = await why(res); out({ t: 'err', code: w.code, error: w.error }); return; }
  let used = res.headers.get('x-coe-used'), limit = res.headers.get('x-coe-limit'), plan = res.headers.get('x-coe-plan');
  let receipt = '', tokens = 0, cut = false, any = false, done = false;
  try {
    const rd = res.body.getReader(), dec = new TextDecoder(); let buf = '';
    for (;;) {
      const { done: end, value } = await rd.read(); if (end) break;
      buf += dec.decode(value, { stream: true });
      let i; while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
        if (!line.startsWith('data:')) continue;
        const d = line.slice(5).trim(); if (d === '[DONE]') { done = true; continue; }
        try {
          const j = JSON.parse(d);
          if (j.coe_usage) { used = j.coe_usage.used; limit = j.coe_usage.limit; plan = j.coe_usage.plan; receipt = j.coe_usage.receipt || ''; tokens = Number(j.coe_usage.tokens) || 0; }
          if (j.error) { out({ t: 'err', code: 'server', error: String(j.error.message || 'The model stopped with an error.') }); return; }
          if (j.choices?.[0]?.finish_reason === 'length') cut = true;
          const s = j.choices?.[0]?.delta?.content; if (s) { any = true; out({ t: 'd', s }); }
        } catch { /* partial line */ }
      }
    }
  } catch { if (ctl.signal.aborted) { out({ t: 'end', stopped: true }); return; } out({ t: 'err', code: 'network', error: 'The reply was cut off. Try again.' }); return; }
  if (!done && !any) { out({ t: 'err', code: 'server', error: 'Coe did not get an answer back. Try again.' }); return; }
  out({ t: 'end', cut, receipt, tokens, credits: used != null && limit != null ? { used: Number(used), limit: Number(limit), plan } : null });
}

// A reply that went wrong is paid back by the server (it only pays back what it charged, once). The sidebar asks for it here.
async function refund(receipts) {
  const c = await cfg(); if (!c.server) return { ok: false };
  try {
    const res = await call('/refund', { method: 'POST', body: JSON.stringify({ receipts: (Array.isArray(receipts) ? receipts : []).filter((x) => typeof x === 'string').slice(0, 10) }) }, c);
    if (!res.ok) return { ok: false };
    const j = await res.json();
    return { ok: true, refunded: Number(j.refunded) || 0, used: j.used, limit: j.limit, plan: j.plan };
  } catch { return { ok: false }; }
}

// A web search for the sidebar: Coe's own server does it (it counts against the same daily searches as the Coe website).
async function search(q) {
  const c = await cfg(); if (!c.server) return { ok: false, error: 'Open Coe once and sign in, so this can find your Coe server.' };
  const query = String(q || '').slice(0, 300).trim(); if (!query) return { ok: false, error: 'There was nothing to search for.' };
  try {
    const res = await call('/search', { method: 'POST', body: JSON.stringify({ q: query }) }, c);
    if (!res.ok) { const w = await why(res); return { ok: false, error: w.code === 'limit' ? 'Today’s web searches are used up.' : w.code === 'signin' ? 'Sign in to Coe to search the web.' : w.error }; }
    const j = await res.json();
    return { ok: true, text: String(j.text || '').slice(0, 6000), sources: (Array.isArray(j.sources) ? j.sources : []).filter((x) => x && /^https?:/.test(x.url)).slice(0, 8).map((x) => ({ title: String(x.title || x.url).slice(0, 120), url: x.url })) };
  } catch { return { ok: false, error: 'Could not reach the Coe server.' }; }
}

// ---- where the panel lives. Chrome, Edge and Brave have a real side panel. Firefox has a sidebar. Any other browser gets the same panel in a small window on the right.
// Opera and Vivaldi may define the side panel API without showing a panel, so they get the small window on the right instead.
const NO_PANEL_UI = (() => { try { return /OPR\//.test(navigator.userAgent) || (navigator.userAgentData && navigator.userAgentData.brands || []).some((b) => /vivaldi|opera/i.test(b.brand)); } catch { return false; } })();
const HAS_PANEL = !!(chrome.sidePanel && chrome.sidePanel.setPanelBehavior) && !NO_PANEL_UI;
const FIREFOX = typeof browser !== 'undefined' && !!(browser.sidebarAction && browser.sidebarAction.toggle);
if (HAS_PANEL) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  chrome.runtime.onInstalled.addListener(() => { chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {}); });
  chrome.commands.onCommand.addListener((c, tab) => { if (c === 'toggle-coe' && tab && tab.id != null) chrome.sidePanel.open({ tabId: tab.id }).catch(() => {}); });
} else if (FIREFOX) {
  chrome.action.onClicked.addListener(() => { browser.sidebarAction.toggle().catch(() => {}); });   // Firefox also has its own shortcut, set in the manifest
} else {
  const popout = async (tab) => {
    try {
      const wins = await chrome.windows.getAll({ populate: true, windowTypes: ['popup'] });
      const mine = wins.find((w) => (w.tabs || []).some((t) => (t.url || '').startsWith(chrome.runtime.getURL('sidepanel.html'))));
      if (mine) { await chrome.windows.update(mine.id, { focused: true }); return; }
      const w = await chrome.windows.get(tab && tab.windowId != null ? tab.windowId : chrome.windows.WINDOW_ID_CURRENT);
      const width = 430, left = Math.max(0, (w.left || 0) + (w.width || 1200) - width);
      await chrome.windows.create({ url: chrome.runtime.getURL('sidepanel.html') + '?win=' + w.id, type: 'popup', width, height: w.height || 800, left, top: w.top || 0 });
    } catch { /* the browser would not open it */ }
  };
  chrome.action.onClicked.addListener((tab) => popout(tab));
  chrome.commands.onCommand.addListener((c, tab) => { if (c === 'toggle-coe') popout(tab); });
}
