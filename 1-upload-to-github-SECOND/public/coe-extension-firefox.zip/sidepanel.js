// The Coe sidebar. It sits next to the page you are on, reads it only when you ask, and answers in the Coe look.
// It changes a page only after you press a button on a card that shows exactly what will change.
(() => {
  const $ = (id) => document.getElementById(id);
  const store = chrome.storage.local;
  const FORCE_TAB = Number(new URLSearchParams(location.search).get('tab')) || null;   // used for testing: look at one particular tab
  const WIN = Number(new URLSearchParams(location.search).get('win')) || null;   // when this opens as a small window, the browser window it belongs to
  const FF = /firefox/i.test(navigator.userAgent);
  // Pages where a teacher set the work, or where a quiz or game is live. Coe explains, hints and checks there. It never types into them.
  const SCHOOLWORK = /sparx|seneca|smart-?revise|go-?code|blooket|kahoot|gimkit|quizizz|wayground|edpuzzle|educake|hegarty|tassomai|century\.tech|mathswatch|drfrost|kerboodle|socrative|nearpod|classroom\.google|forms\.(gle|office|microsoft)|instructure/i;
  const hostOf = (u) => { try { return new URL(u).hostname; } catch { return ''; } };
  const isSchool = (u) => { try { const x = new URL(u); return SCHOOLWORK.test(x.hostname) || (/(^|\.)google\.com$/.test(x.hostname) && /^\/forms\//.test(x.pathname)) || /\/mod\/quiz\//.test(x.pathname) || (/docs\.google\.com/.test(x.hostname) && /^\/forms\//.test(x.pathname)); } catch { return false; } };
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const S = { tab: null, page: null, scope: 'page', msgs: [], atts: [], busy: false, port: null, status: null, shot: null, pending: null, setupDone: false, queue: [], tx: [], chatId: 'c' + Date.now().toString(36), askTabs: 'ask', askChg: 'ask', qs: null, me: {} };
  const QUICK = [
    ['Find the questions', '', { act: 'questions' }],
    ['Explain this page', 'Explain this page in simple words.'],
    ['Summarise', 'Summarise this page in five short points.'],
    ['Practice questions', 'Make five practice questions from this page. Put the answers at the end under a heading called Answers.', { say: 'Make practice questions from this page.' }],
    ['Explain my selection', 'Explain the part I selected in simple words.'],
    ['Highlight key points', 'Highlight the most important points on this page.'],
    ['Look at the screen', 'Look at the screen. Say what you see in one or two lines, then what to do next.', { shot: true, say: 'Look at the screen.' }],
  ];
  const SYS = [
    'You are Coe Mini, the Coe study helper in the browser sidebar, made by PMC Studios. You sit next to the web page the person is on. Be accurate, quick and kind.',
    'WHAT YOU CAN SEE: only what is written under "THE PAGE THE STUDENT IS ON" below. Coe read it just now, when the message was sent. It has the page title and address, the page text (all of it, or only what was on screen: it says which), any words they selected, the boxes on the page and what is in them, and code in a code editor. If a picture is attached, it shows what was on screen. You cannot see other tabs, videos, sound, or pictures on the page unless a screenshot is attached.',
    'WHAT YOU CAN DO: explain, summarise, make practice questions, check work, translate, find mistakes, rewrite words or code, and say what is in a screenshot (a record, a plant, a product, a diagram). The student can press Find the questions to list the questions on a page. You can search the web (see SEARCHING). With their OK you can change text on the page, highlight words and open a new tab. You cannot click, scroll, type, submit anything or use other tabs yourself. If asked, say so in one sentence and say what to click instead.',
    'HOW TO ANSWER: put the answer first, in short plain words. British spelling. No greeting, no "Great question", no closing offer, no repeating yourself. Say where an answer comes from when it matters ("The page says..."). If the page does not have what is needed, say so once, then what to try (select the words, switch between Whole page and On screen, or press Look at the screen). Never make up what the page says or what is on it. If you are not sure, say so.',
    'WHEN SOMETHING DID NOT WORK: say so once, in one plain sentence that includes the reason, then one thing to try. Never say you changed, marked, opened or saw something unless that is true.',
    'CHANGING THE PAGE: only when asked (rewrite a sentence, fix code, edit a slide). Give one or two lines, then exactly one block:\n```coe-edit\n{"find":"the exact words on the page to replace, copied exactly from the page text, or an empty string to replace what they selected","text":"the new words"}\n```\nIf you cannot copy the exact words, ask them to select the words first and use an empty find. The student presses a button to put it in. Never say you changed the page.',
    'HIGHLIGHTING: when asked to highlight, give one block with short exact phrases from the page (at most 12):\n```coe-highlight\n{"phrases":["exact words"]}\n```',
    'OPENING A TAB: only when it really helps (a shop, a source, a video). One block:\n```coe-open\n{"url":"https://example.com/page","why":"five words"}\n```\nor, to search: {"search":"words to search","why":"five words"}. The student is asked first. Never say you opened it.',
    'SEARCHING: when you need current facts, or to find where to buy or read something, give one block and stop writing:\n```coe-search\n{"q":"search words"}\n```\nCoe runs it and sends the results back to you. At most twice per question. Name the sites you use.',
    'PICTURES: when a screenshot is attached you can identify what is in it. Say what it is and how sure you are in one line. For a product (a record, a game, a gadget), say what it is, then search for where to buy it.',
  ].join('\n\n');
  const SCHOOL = '\n\nTHIS PAGE IS SET WORK OR A QUIZ. Help the student learn it: explain the idea, give a hint first, and check the answer they tried. Do not hand over the final answer to a set question. Never give coe-edit blocks on this page, and never type into it.';

  // ------------------------------------------------------------------ small helpers
  const icon = (d) => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '"/></svg>';
  const X = icon('M6 6l12 12M18 6L6 18');
  function el(tag, cls, html) { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  const ext = (n) => (/\.([a-z0-9]{1,5})$/i.exec(n) || [])[1] || '';
  const first = (t, n) => String(t).replace(/\s+/g, ' ').trim().slice(0, n || 110);

  // ------------------------------------------------------------------ one problem box, never two
  const ERR = {
    credits: { t: 'Out of tokens', x: 'Today’s tokens are used up. They come back at midnight (UTC).', a: ['See plans', () => chrome.tabs.create({ url: siteBase() + 'plans/' })], lvl: 'warn' },
    signin: { t: 'Sign in to continue', x: 'Open Coe and sign in. This sidebar finds your sign-in by itself.', a: ['Open Coe', () => chrome.runtime.sendMessage({ type: 'open-coe' })], lvl: 'warn' },
    setup: { t: 'Not set up yet', x: 'Open Coe once and sign in. Then this sidebar is ready.', a: ['Set up', () => showSetup()], lvl: 'warn' },
    network: { t: 'Cannot reach Coe', x: 'Check your internet, then try again.', a: ['Try again', () => retry()], lvl: 'warn' },
    noq: { t: 'No questions found', x: 'Open a page that has questions, or press Look at the screen.', lvl: 'warn' },
    page: { t: 'Cannot read this page', x: 'Open a website, then try again. Chrome keeps its own pages private.', lvl: 'warn' },
    other: { t: 'Something went wrong', x: 'Try again in a moment.', a: ['Try again', () => retry()], lvl: 'red' },
  };
  let site = 'https://coe.pmcstudios.uk/';
  const siteBase = () => site.replace(/\/+$/, '') + '/';
  function showErr(code, text) {
    const k = code === 'limit' || code === 'credits' ? 'credits' : ERR[code] ? code : 'other';
    const e = ERR[k], box = el('div', 'cx-err ' + (e.lvl === 'red' ? 'red' : ''), '<span class="i" aria-hidden="true">!</span><h3 class="d">' + esc(e.t) + '</h3><p class="tx" title="">' + esc(k === 'other' && text ? text : e.x) + '</p>');
    box.setAttribute('role', 'alert');
    box.querySelector('p').onclick = () => box.classList.toggle('open');
    if (e.a) { const b = el('button', 'btn sm' + (e.lvl === 'warn' ? ' gold' : ''), esc(e.a[0])); b.type = 'button'; b.onclick = e.a[1]; box.appendChild(b); }
    $('err').replaceChildren(box);   // replaces whatever was there
    S.errKind = k; paintSend(); paintQuick();
  }
  const clearErr = () => { $('err').replaceChildren(); S.errKind = ''; paintSend(); paintQuick(); };

  // ------------------------------------------------------------------ the page we are next to
  async function activeTab() {
    if (FORCE_TAB) return chrome.tabs.get(FORCE_TAB).catch(() => null);
    const [t] = await chrome.tabs.query(WIN ? { active: true, windowId: WIN } : { active: true, lastFocusedWindow: true });
    if (t) return t;
    const [u] = await chrome.tabs.query({ active: true, currentWindow: true }); return u || null;
  }
  async function refreshTab() { const old = S.tab && S.tab.url; S.tab = await activeTab(); if (!S.tab || S.tab.url !== old) S.page = null; paintPage(); }
  chrome.tabs.onActivated.addListener(refreshTab);
  chrome.tabs.onUpdated.addListener((id, ch) => { if (S.tab && id === S.tab.id && (ch.title || ch.url || ch.status === 'complete')) refreshTab(); });
  chrome.windows.onFocusChanged.addListener(refreshTab);

  function paintPage() {
    const t = S.tab, ok = t && /^https?:/.test(t.url || '');
    $('pt1').textContent = t ? (t.title || hostOf(t.url) || 'This page') : 'No page';
    $('pt2').textContent = ok ? hostOf(t.url) : 'Coe reads websites';
    const read = S.page && t && S.page.url === t.url;
    $('pst').textContent = !ok ? 'Cannot read' : read ? 'Read' : 'Not read yet'; $('pst').className = 'pst tx' + (read ? ' on' : '');
    const th = $('pth'); if (S.shot && read) { th.style.backgroundImage = 'url(' + S.shot + ')'; th.classList.add('has'); } else { th.style.backgroundImage = ''; th.classList.remove('has'); }
    const school = ok && isSchool(t.url);
    paintSend();
    paintQuick();
  }

  async function capture() {
    try { return await chrome.tabs.captureVisibleTab(S.tab ? S.tab.windowId : undefined, { format: 'jpeg', quality: 60 }); } catch { return null; }
  }
  async function noAccess(t) {
    const o = new URL(t.url).origin + '/*';
    return { code: 'allow', origin: o };
  }
  async function runInTab(func, args, world) {
    const t = S.tab; if (!t) throw { code: 'page' };
    const r = await chrome.scripting.executeScript({ target: { tabId: t.id }, func, args: args || [], ...(world ? { world } : {}) });
    return r && r[0] && r[0].result;
  }
  /** Reads the page you are on. This is the only place the sidebar looks at a page. */
  async function readTab(scope) {
    const t = S.tab;
    if (!t || !/^https?:/.test(t.url || '')) throw { code: 'page' };
    const run = async (func, args, world) => { const r = await chrome.scripting.executeScript({ target: { tabId: t.id }, func, args: args || [], ...(world ? { world } : {}) }); return r && r[0] && r[0].result; };
    let page;
    try { page = await run(coeReadPage, [scope]); } catch { throw await noAccess(t); }
    if (!page) throw { code: 'page' };
    if (hostOf(t.url) === 'docs.google.com') { const d = await run(coeReadDoc).catch(() => null); if (d && d.text) { page.docKind = d.kind; page.text = d.text; } }
    try { const ed = await run(coeReadEditor, [], 'MAIN'); if (ed) page.editor = ed; } catch { /* no editor */ }
    page.scope = scope; S.page = page;
    S.shot = await capture();   // null when Chrome will not let us, so an old picture is never shown for a new page
    paintPage(); return page;
  }
  function contextOf(p) {
    const b = ['PAGE TITLE: ' + p.title, 'ADDRESS: ' + p.url, 'WHAT WAS READ: ' + (p.docKind ? 'the words in a Google file' : p.scope === 'screen' ? 'only the text on screen' : 'the whole page') + (p.cut ? ', cut short because the page is long' : '') + ' (' + String((p.text || '').length) + ' letters)'];
    if (p.selection) b.push('THE STUDENT HAS SELECTED THIS TEXT:\n' + p.selection);
    if (p.editor) b.push('CODE IN THE ' + p.editor.editor.toUpperCase() + ' EDITOR' + (p.editor.lang ? ' (' + p.editor.lang + ')' : '') + ':\n' + p.editor.code + (p.editor.selection ? '\n\nSELECTED IN THE EDITOR:\n' + p.editor.selection : ''));
    b.push((p.docKind ? 'THE WORDS IN THIS GOOGLE ' + ({ document: 'DOC', presentation: 'SLIDES FILE', spreadsheets: 'SHEET' }[p.docKind] || 'FILE') : p.scope === 'screen' ? 'TEXT ON THE PAGE (only what is on screen)' : 'TEXT ON THE PAGE') + ':\n' + p.text + (p.cut ? '\n[The page was cut short.]' : '') + (!(p.text || '').trim() ? '\n[No text could be read from this page.]' : ''));
    if (p.fields && p.fields.length) b.push('BOXES ON THE PAGE:\n' + p.fields.map((f) => '- ' + (f.label || 'box') + ': ' + (f.value || '(empty)')).join('\n'));
    return b.join('\n\n');
  }

  // ------------------------------------------------------------------ talking to the Coe server
  let rafId = 0;
  function connect() {
    const port = chrome.runtime.connect({ name: 'chat' }); S.port = port;
    port.onDisconnect.addListener(() => { if (S.port === port) S.port = null; });
    return port;
  }
  function modelMessages() {
    const lastUsers = S.msgs.filter((m) => m.role === 'user' && !m.hidden).slice(-2);   // old pictures are not sent again
    return S.msgs.filter((m) => !m.skip && !m.kind).map((m) => {
      if (m.role === 'assistant') return { role: 'assistant', content: m.text };
      const parts = (lastUsers.includes(m) ? m.images || [] : []).map((u) => ({ type: 'image_url', image_url: { url: u } }));
      return { role: 'user', content: parts.length ? [...parts, { type: 'text', text: m.send || m.text }] : (m.send || m.text) };
    }).filter((m) => !(m.role === 'assistant' && !m.content));
  }
  let lastSend = null;
  const retry = () => { if (lastSend) { clearErr(); send(lastSend.text, lastSend.opts, true); } };
  const tell = (role, text) => { const t = String(text || '').trim(); if (t) { S.tx.push({ r: role, t: t.slice(0, 6000), at: Date.now() }); saveChat(); } };

  /** Sends what the person typed. While Coe is still working, it waits its turn (or goes first if they press Send now). */
  async function send(text, opts, again) {
    text = String(text || '').trim(); opts = opts || {};
    if (S.busy) {
      if (!text || again) return;
      if (S.queue.length >= 3) { showErr('other', 'Wait for Coe to catch up, then send that again.'); return; }
      S.queue.push({ text, opts, atts: S.atts.slice() }); S.atts = []; paintAtts(); $('ta').value = ''; grow(); paintQueue(); return;
    }
    if (!text && !S.atts.length) return;
    if (S.errKind === 'credits') return;   // the one box above already says so
    clearErr(); lastSend = { text, opts };
    let mine;
    if (again) { mine = [...S.msgs].reverse().find((m) => m.role === 'user' && !m.hidden); S.msgs = S.msgs.filter((m) => m.role === 'user' || m.text); }
    else {
      const docs = S.atts.filter((x) => !x.img);
      mine = { role: 'user', text: opts.say || text, send: docs.map((d) => '[File: ' + d.name + ']\n' + d.text).join('\n\n') + (docs.length ? '\n\n' : '') + text, images: S.atts.filter((x) => x.img).map((x) => x.img), atts: S.atts.slice() };
      S.msgs.push(mine); S.atts = []; paintAtts(); $('ta').value = ''; grow(); tell('u', mine.text);
    }
    if (!mine) return;
    await turn(mine, text, opts);
  }

  /** One question from the person, and Coe's answer to it (which may include a web search along the way). */
  async function turn(mine, text, opts) {
    S.busy = true; S.phase = 'Reading the page'; S.stopped = false; S.searches = 0; paintSend(); renderMsgs(true); paintQueue();
    let page = null;
    try { page = await readTab(S.scope); }
    catch (e) {
      S.busy = false; S.phase = ''; paintSend();
      if (e && e.code === 'allow') { S.pending = () => send(text, opts, true); renderMsgs(); addAllowCard(e.origin); return; }
      S.msgs.pop(); $('ta').value = opts.say || opts.act ? '' : text; grow(); renderMsgs(); showErr((e && e.code) || 'other'); return;
    }
    if (opts.shot && S.shot) mine.images = [S.shot];
    const school = isSchool(page.url);
    const system = SYS + (school ? SCHOOL : '') + '\n\nTHE PAGE THE STUDENT IS ON\n' + contextOf(page);
    let bot = { role: 'assistant', text: '' };
    S.msgs.push(bot); S.phase = opts.shot ? 'Looking at the screen' : 'Thinking'; renderMsgs();
    for (let n = 0; ; n++) {
      const ok = await streamReply(bot, system);
      if (!ok) break;
      const q = n < 2 && firstBlock(bot.text, 'coe-search');
      if (!q || !q.q) break;
      S.searches++; bot.search = { q: String(q.q).slice(0, 160), state: 'run' }; S.phase = 'Searching the web'; renderMsgs();
      const r = await webSearch(bot.search.q);
      bot.search = r.ok ? { q: bot.search.q, state: 'ok', sources: r.sources } : { q: bot.search.q, state: 'bad', why: r.error };
      S.msgs.push({ role: 'user', hidden: true, text: '', send: r.ok ? '[Result of the web search for "' + bot.search.q + '"]\n' + r.text + '\n\nSources:\n' + r.sources.map((x) => '- ' + x.title + ': ' + x.url).join('\n') + '\n\nAnswer from this. Name the sites you use. If it does not settle the question, say so.' : '[The web search FAILED: ' + r.error + ' Nothing was found. Say once, in one short sentence, that you could not search and why. Then answer from what you can see or know, and say it may be out of date.]' });
      bot = { role: 'assistant', text: '' }; S.msgs.push(bot); S.phase = 'Thinking'; renderMsgs();
    }
    S.busy = false; S.phase = ''; paintSend(); renderMsgs(); paintQuick(); paintQueue();
    const intr = S.interrupt; S.interrupt = null;
    if (intr && intr.length) { S.queue = intr.slice(1); S.stopped = false; const nx = intr[0]; S.atts = nx.atts || []; paintAtts(); paintQueue(); send(nx.text, nx.opts); }
    else if (!S.stopped && S.queue.length) { const nx = S.queue.shift(); S.atts = nx.atts || []; paintAtts(); paintQueue(); send(nx.text, nx.opts); }
    else if (S.stopped) { S.queue = []; paintQueue(); }
  }

  /** Streams one reply from the Coe server into `bot`. Resolves true when it finished well, false when it was stopped or went wrong. */
  function streamReply(bot, system) {
    return new Promise((done) => {
      const port = connect(); let over = false;
      port.onMessage.addListener((m) => {
        if (over) return;
        if (m.t === 'd') { if (S.phase) S.phase = ''; bot.text += m.s; if (!rafId) rafId = requestAnimationFrame(() => { rafId = 0; renderMsgs(); }); }
        else if (m.t === 'end') {
          over = true; bot.receipts = [...(bot.receipts || []), ...(m.receipt ? [m.receipt] : [])]; bot.receipt = m.receipt || ''; bot.tokens = (bot.tokens || 0) + (m.tokens || 0); bot.cut = !!m.cut; bot.stopped = !!m.stopped;
          try { port.disconnect(); } catch { /* done */ } if (m.credits) setMeter(m.credits);
          if (m.stopped) S.stopped = true;
          renderMsgs(); checkReply(bot); if (!m.stopped && String(bot.text || '').trim()) tell('a', bot.text);
          done(!m.stopped && !!String(bot.text || '').trim());
        } else if (m.t === 'err') {
          over = true; try { port.disconnect(); } catch { /* done */ } S.msgs = S.msgs.filter((x) => x !== bot); S.busy = false; S.phase = ''; if (m.credits) setMeter(m.credits);
          S.stopped = true; showErr(m.code, m.error); paintSend(); renderMsgs(); done(false);
        }
      });
      port.postMessage({ type: 'send', system, messages: modelMessages() });
    });
  }
  function stop() { S.queue = []; paintQueue(); if (S.port) { try { S.port.postMessage({ type: 'stop' }); } catch { /* gone */ } } }
  /** Stops what Coe is doing and sends the waiting message straight away. */
  function sendNow() { if (!S.busy || !S.queue.length) return; S.stopped = false; const q = S.queue; S.queue = []; S.interrupt = q; if (S.port) { try { S.port.postMessage({ type: 'stop' }); } catch { /* gone */ } } }
  const firstBlock = (t, tag) => { const m = new RegExp('```' + tag + '[ \\t]*\\n([\\s\\S]*?)```').exec(String(t || '')); if (!m) return null; try { return JSON.parse(m[1]); } catch { return null; } };
  function webSearch(q) { return new Promise((ok) => chrome.runtime.sendMessage({ type: 'search', q }, (r) => ok(chrome.runtime.lastError || !r ? { ok: false, error: 'Could not reach Coe.' } : r))); }

  // ------------------------------------------------------------------ what the chat shows
  function mdInline(s) {
    return esc(s).replace(/`([^`\n]+)`/g, '<code>$1</code>').replace(/\*\*([^*\n]+)\*\*/g, '<b>$1</b>').replace(/(^|[\s(])\*([^*\n]+)\*(?=[\s).,!?:;]|$)/g, '$1<i>$2</i>')
      .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  }
  function mdBlock(text) {
    const out = []; let list = null, para = [];
    const flushP = () => { if (para.length) { out.push('<p>' + para.map(mdInline).join('<br>') + '</p>'); para = []; } };
    const flushL = () => { if (list) { out.push('<' + list.t + '>' + list.items.map((i) => '<li>' + mdInline(i) + '</li>').join('') + '</' + list.t + '>'); list = null; } };
    const lines = text.split('\n');
    for (let li = 0; li < lines.length; li++) {
      const line = lines[li]; let m;
      if (/^\s*\|.*\|\s*$/.test(line) && /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(lines[li + 1] || '')) {
        flushP(); flushL();
        const cells = (x) => x.trim().replace(/^\||\|$/g, '').split('|').map((c) => c.trim());
        const head = cells(line); const rows = []; li += 2;
        while (li < lines.length && /^\s*\|.*\|\s*$/.test(lines[li])) { rows.push(cells(lines[li])); li++; }
        li--; out.push('<table><thead><tr>' + head.map((c) => '<th>' + mdInline(c) + '</th>').join('') + '</tr></thead><tbody>' + rows.map((r) => '<tr>' + r.map((c) => '<td>' + mdInline(c) + '</td>').join('') + '</tr>').join('') + '</tbody></table>');
        continue;
      }
      if ((m = /^\s{0,3}(#{1,4})\s+(.*)$/.exec(line))) { flushP(); flushL(); out.push('<h4>' + mdInline(m[2]) + '</h4>'); }
      else if ((m = /^\s*[-*]\s+(.*)$/.exec(line))) { flushP(); if (!list || list.t !== 'ul') { flushL(); list = { t: 'ul', items: [] }; } list.items.push(m[1]); }
      else if ((m = /^\s*\d+[.)]\s+(.*)$/.exec(line))) { flushP(); if (!list || list.t !== 'ol') { flushL(); list = { t: 'ol', items: [] }; } list.items.push(m[1]); }
      else if (!line.trim()) { flushP(); flushL(); }
      else { flushL(); para.push(line); }
    }
    flushP(); flushL(); return out.join('');
  }
  /** Splits a reply into words, code blocks, and the two special blocks (change this, highlight this). */
  function parts(text) {
    const out = []; const re = /```([a-z-]*)[ \t]*\n([\s\S]*?)(```|$)/g; let at = 0, m;
    while ((m = re.exec(text))) {
      if (m.index > at) out.push({ k: 'text', s: text.slice(at, m.index) });
      const closed = m[3] === '```';
      if (m[1] === 'coe-edit' || m[1] === 'coe-highlight' || m[1] === 'coe-open' || m[1] === 'coe-search') { let j = null; if (closed) { try { j = JSON.parse(m[2]); } catch { /* not valid */ } } out.push({ k: m[1], j, closed }); }
      else out.push({ k: 'code', lang: m[1], s: m[2].replace(/\n$/, '') });
      at = m.index + m[0].length;
    }
    if (at < text.length) out.push({ k: 'text', s: text.slice(at) });
    return out;
  }
  function renderBot(m, host) {
    host.replaceChildren();
    if (!m.text) { host.appendChild(el('span', 'dots', '<i></i><i></i><i></i>')); if (S.phase && S.busy) host.appendChild(el('span', 'phase tx', esc(S.phase) + '…')); return; }
    let n = 0; const searching = /```coe-search/.test(m.text);   // a reply that goes off to search says nothing before it: the search is the message
    for (const p of parts(m.text)) {
      if (p.k === 'text') { if (searching) continue; const d = el('div', '', mdBlock(p.s)); while (d.firstChild) host.appendChild(d.firstChild); }
      else if (p.k === 'code') {
        const c = el('div', 'code', '<div class="ch"><span>' + esc(p.lang || 'code') + '</span></div><pre><code>' + esc(p.s) + '</code></pre>');
        const b = el('button', 'btn sm', 'Copy'); b.type = 'button'; b.onclick = async () => { try { await navigator.clipboard.writeText(p.s); b.textContent = 'Copied'; setTimeout(() => (b.textContent = 'Copy'), 1200); } catch { b.textContent = 'Could not copy'; } };
        c.querySelector('.ch').appendChild(b); host.appendChild(c);
      } else if (p.k === 'coe-edit') host.appendChild(p.j && p.closed ? editCard(m, n++, p.j) : el('span', 'dots', '<i></i><i></i><i></i>'));
      else if (p.k === 'coe-highlight') host.appendChild(p.j && p.closed ? lightCard(m, n++, p.j) : el('span', 'dots', '<i></i><i></i><i></i>'));
      else if (p.k === 'coe-open') { if (p.j && p.closed) host.appendChild(openCard(m, n++, p.j)); else host.appendChild(el('span', 'dots', '<i></i><i></i><i></i>')); }
      else if (p.k === 'coe-search') { if (m.search) host.appendChild(searchCard(m.search)); else host.appendChild(el('span', 'dots', '<i></i><i></i><i></i>')); }
    }
    if (m.cut && !m.stopped) host.appendChild(el('p', 'flag tx', 'This reply reached its length limit. Say “continue” to carry on.'));
    if (m.refunded > 0) host.appendChild(el('p', 'refund tx', '<b>' + m.refunded.toLocaleString() + '</b> tokens given back.'));
  }

  // ------------------------------------------------------------------ a reply that went wrong is paid back
  const unclosed = (t) => (String(t).match(/```/g) || []).length % 2 === 1;
  /** Gives back the tokens of one reply, once. The server only pays back what it charged. */
  async function refundMsg(m, why) {
    const rc = (m && (m.receipts && m.receipts.length ? m.receipts : m.receipt ? [m.receipt] : [])) || [];
    if (!m || !rc.length || m.refunded) return;
    m.refunded = -1;
    const r = await new Promise((ok) => chrome.runtime.sendMessage({ type: 'refund', receipts: rc }, (x) => ok(chrome.runtime.lastError ? null : x)));
    if (!r || !r.ok || !(r.refunded > 0)) { m.refunded = 0; if (r && r.ok) { m.receipt = ''; m.receipts = []; } return; }
    m.refunded = r.refunded; m.refundWhy = why;
    if (r.used != null && r.limit) setMeter({ used: r.used, limit: r.limit });
    const o = await store.get('refunds'), list = Array.isArray(o.refunds) ? o.refunds : [];
    list.unshift({ id: Math.random().toString(36).slice(2, 10), t: Date.now(), tokens: r.refunded, why: String(why).slice(0, 140), chat: 'Chrome sidebar' });
    await store.set({ refunds: list.slice(0, 50) });
    renderMsgs();
  }
  /** After a reply ends: code that was cut off in the middle, or nothing at all, did not do its job. */
  function checkReply(m) {
    if (m.stopped) return;
    if (!String(m.text || '').trim()) { S.msgs = S.msgs.filter((x) => x !== m); showErr('other', 'Coe did not write anything back. Try again.'); refundMsg(m, 'Coe sent nothing back'); return; }
    if (m.cut && unclosed(m.text)) refundMsg(m, 'the code was cut off before it finished');
  }
  const blocked = () => (S.tab && isSchool(S.tab.url)) ? 'Coe does not type into this site. It is set work or a quiz, so it explains and hints only.' : '';

  /** The card that asks first: what will change, before and after. Nothing happens until you press the button. */
  function editCard(m, n, j) {
    const st = (m.edits = m.edits || {})[n] = (m.edits && m.edits[n]) || { s: 'new' };
    const find = String(j.find || ''), text = String(j.text == null ? '' : j.text);
    const c = el('div', 'edit', '<div class="eh"><b class="d">Change this on the page?</b></div><div class="eb"></div>');
    const body = c.querySelector('.eb');
    const stop = blocked();
    if (find) body.appendChild(el('div', '', '<small>Now</small><pre class="old">' + esc(find) + '</pre>'));
    else body.appendChild(el('div', '', '<small>Now</small><pre class="old">What you have selected</pre>'));
    body.appendChild(el('div', '', '<small>New</small><pre class="new">' + esc(text) + '</pre>'));
    const acts = el('div', 'ea'); body.appendChild(acts);
    if (stop) acts.appendChild(el('span', 'no', esc(stop)));
    else if (st.s === 'new') {
      const y = el('button', 'btn sm gold', 'Change it'); y.type = 'button'; y.onclick = async () => { y.disabled = true; await applyEdit(st, { find, text }); renderMsgs(); if (st.s === 'fail' && !st.allow) refundMsg(m, 'the change could not be made on the page'); };
      const no = el('button', 'btn sm', 'Not now'); no.type = 'button'; no.onclick = () => { st.s = 'skip'; renderMsgs(); };
      acts.append(y, no);
    } else if (st.s === 'done') {
      acts.appendChild(el('span', 'ok', 'Done. Changed in ' + esc(st.where || 'the page') + '.'));
      if (st.before) { const u = el('button', 'btn sm', 'Undo'); u.type = 'button'; u.onclick = async () => { u.disabled = true; const r = await doApply({ find: text, text: st.before }); st.s = r.ok ? 'undone' : 'done'; if (!r.ok) st.why = r.why; renderMsgs(); }; acts.appendChild(u); }
    } else if (st.s === 'undone') acts.appendChild(el('span', 'ok', 'Put back the way it was.'));
    else if (st.s === 'skip') acts.appendChild(el('span', 'tx', 'Left as it was.'));
    else if (st.s === 'fail') acts.appendChild(el('span', 'no', esc(st.why || 'That did not work.')));
    if (st.why && st.s === 'done') acts.appendChild(el('span', 'no', esc(st.why)));
    return c;
  }
  async function doApply(p) {
    const t = S.tab; if (!t) return { ok: false, why: 'No page to change.' };
    try { const r = await chrome.scripting.executeScript({ target: { tabId: t.id }, world: 'MAIN', func: coeApply, args: [p] }); return (r && r[0] && r[0].result) || { ok: false, why: 'The page did not answer.' }; }
    catch { return { ok: false, why: 'Coe is not allowed to change this page yet.', allow: true }; }
  }
  async function applyEdit(st, p) {
    if (blocked()) { st.s = 'fail'; st.why = blocked(); return; }
    const r = await doApply(p);
    if (r.ok) { st.s = 'done'; st.where = r.where; st.before = r.before || ''; } else { st.s = 'fail'; st.why = r.why; st.allow = !!r.allow; }
  }
  function lightCard(m, n, j) {
    const st = (m.edits = m.edits || {})[n] = (m.edits && m.edits[n]) || { s: 'new' };
    const list = (Array.isArray(j.phrases) ? j.phrases : []).map(String).filter(Boolean).slice(0, 12);
    const c = el('div', 'edit', '<div class="eh"><b class="d">Highlight on the page?</b></div><div class="eb"></div>');
    const body = c.querySelector('.eb'); body.appendChild(el('pre', 'new', esc(list.join('\n')) || 'Nothing to mark.'));
    const acts = el('div', 'ea'); body.appendChild(acts);
    if (st.s === 'new' && list.length) {
      const y = el('button', 'btn sm gold', 'Highlight'); y.type = 'button';
      y.onclick = async () => { y.disabled = true; try { const r = await chrome.scripting.executeScript({ target: { tabId: S.tab.id }, func: coeHighlight, args: [list] }); const res = r && r[0] && r[0].result; st.s = res && res.ok ? 'done' : 'fail'; st.n = res ? res.n : 0; } catch { st.s = 'fail'; } renderMsgs(); if (st.s === 'fail') refundMsg(m, 'those words were not on the page'); };
      const no = el('button', 'btn sm', 'Not now'); no.type = 'button'; no.onclick = () => { st.s = 'skip'; renderMsgs(); }; acts.append(y, no);
    } else if (st.s === 'done') {
      acts.appendChild(el('span', 'ok', 'Marked ' + st.n + (st.n === 1 ? ' place.' : ' places.')));
      const u = el('button', 'btn sm', 'Clear'); u.type = 'button'; u.onclick = async () => { await clearMarks(); st.s = 'skip'; renderMsgs(); }; acts.appendChild(u);
    } else if (st.s === 'fail') acts.appendChild(el('span', 'no', 'Could not find those words on the page.'));
    else acts.appendChild(el('span', 'tx', 'Left as it was.'));
    return c;
  }
  async function clearMarks() { try { await chrome.scripting.executeScript({ target: { tabId: S.tab.id }, func: coeClearHighlight }); } catch { /* nothing to clear */ } }

  function addAllowCard(origin) {
    const c = el('div', 'edit', '<div class="eh"><b class="d">Let Coe read this site?</b></div><div class="eb"><p>Chrome needs your OK before Coe can read <b>' + esc(hostOf(origin.replace('*', ''))) + '</b>. You can take it back any time in Chrome’s extension settings.</p></div>');
    const acts = el('div', 'ea'), y = el('button', 'btn sm gold', 'Allow on this site'), n = el('button', 'btn sm', 'No');
    y.type = n.type = 'button';
    y.onclick = async () => { let ok = false; try { ok = await chrome.permissions.request({ origins: [origin] }); } catch { /* not allowed */ } c.remove(); if (ok && S.pending) { const f = S.pending; S.pending = null; f(); } else if (!ok) showErr('page'); };
    n.onclick = () => { S.pending = null; c.remove(); };
    acts.append(y, n); c.querySelector('.eb').appendChild(acts);
    const li = el('div', 'm bot'); li.appendChild(c); $('msgs').appendChild(li); $('msgs').scrollTop = 1e9;
  }

  function userBubble(m) {
    const d = el('div', 'm user');
    if (m.images && m.images.length) { const ph = el('div', 'pics'); m.images.forEach((u) => { const b = el('button', 'pic', '<img alt="Picture you added" src="' + u + '">'); b.type = 'button'; b.onclick = () => openImage(u); ph.appendChild(b); }); d.appendChild(ph); }
    if (m.atts) { const ph = el('div', 'pics'); m.atts.filter((a) => !a.img).forEach((a) => ph.appendChild(attCard(a))); if (ph.childNodes.length) d.appendChild(ph); }
    if (m.text) d.appendChild(document.createTextNode(m.text));
    return d;
  }
  function home() {
    const h = el('div', 'hello', '<h2 class="d">Coe Mini</h2><p class="tx">Pick one, or type below.</p>'), cards = el('div', 'cards'), off = S.busy || S.errKind === 'credits';
    for (const [t, d, k, f] of [
      ['Find the questions', 'Scan this page and help with each one', 'main', () => findQuestions()],
      ['Explain this page', 'In simple words', '', () => send('Explain this page in simple words.')],
      ['Summarise', 'Five short points', '', () => send('Summarise this page in five short points.')],
      ['Practice questions', 'Test yourself', '', () => send(QUICK[3][1], QUICK[3][2])],
      ['Look at the screen', 'Say what is in the picture', '', () => send(QUICK[6][1], QUICK[6][2])],
      ['Highlight key points', 'Mark them on the page', '', () => send(QUICK[5][1])],
      ['Explain my selection', 'Select words first', '', () => send(QUICK[4][1])],
    ]) { const b = el('button', 'hc' + (k ? ' ' + k : ''), '<b>' + esc(t) + '</b><span>' + esc(d) + '</span>'); b.type = 'button'; b.disabled = off || (k === 'main' && S.qBusy); b.onclick = f; cards.appendChild(b); }
    h.appendChild(cards); return h;
  }
  function renderMsgs(keep) {
    const box = $('msgs'), near = box.scrollHeight - box.scrollTop - box.clientHeight < 80;
    box.replaceChildren();
    if (!S.msgs.length && !S.busy && !S.qBusy) { box.appendChild(home()); return; }
    for (const m of S.msgs) {
      if (m.hidden) continue;
      if (m.kind === 'qs') { if (S.qs) box.appendChild(qsPanel()); continue; }
      if (m.role === 'user') box.appendChild(userBubble(m));
      else { const d = el('div', 'm bot'); renderBot(m, d); if (d.childNodes.length) box.appendChild(d); }
    }
    const lastShown = [...S.msgs].reverse().find((m) => !m.hidden && !m.kind);
    if (S.busy && lastShown && lastShown.role === 'user') { const d = el('div', 'm bot'); d.appendChild(el('span', 'dots', '<i></i><i></i><i></i>')); if (S.phase) d.appendChild(el('span', 'phase tx', esc(S.phase) + '…')); box.appendChild(d); }
    if (S.qBusy) { const d = el('div', 'm bot'); d.appendChild(el('span', 'dots', '<i></i><i></i><i></i>')); d.appendChild(el('span', 'phase tx', 'Looking for questions…')); box.appendChild(d); }
    if (near || keep) box.scrollTop = box.scrollHeight;
  }

  // ------------------------------------------------------------------ opening a tab, and a web search
  const safeUrl = (j) => { try { const u = j && j.url ? new URL(String(j.url)) : j && j.search ? new URL('https://www.google.com/search?q=' + encodeURIComponent(String(j.search).slice(0, 200))) : null; return u && /^https?:$/.test(u.protocol) ? u : null; } catch { return null; } };
  /** The card that asks first. With "Ask before opening a new tab" switched off in Settings, it opens in the background by itself. */
  function openCard(m, n, j) {
    const st = (m.edits = m.edits || {})[n] = (m.edits && m.edits[n]) || { s: 'new' };
    const u = safeUrl(j), c = el('div', 'edit', '<div class="eh"><b class="d">Open in a new tab?</b></div><div class="eb"></div>'), body = c.querySelector('.eb');
    if (!u) { c.querySelector('.eh b').textContent = 'Cannot open that'; body.appendChild(el('span', 'no', 'That is not a web link Coe can open.')); return c; }
    body.appendChild(el('pre', 'new', esc(j.search ? 'Search: ' + first(j.search, 90) : u.hostname + first(u.pathname === '/' ? '' : u.pathname, 50))));
    if (j.why) body.appendChild(el('p', 'tx', esc(first(j.why, 90))));
    const acts = el('div', 'ea'); body.appendChild(acts);
    const open = async (fg) => { try { await chrome.tabs.create({ url: u.href, active: fg }); st.s = 'done'; st.bg = !fg; } catch { st.s = 'fail'; } renderMsgs(); };
    if (st.s === 'new') {
      if (S.askTabs === 'allow' && !st.auto) { st.auto = true; setTimeout(() => open(false), 0); acts.appendChild(el('span', 'tx', 'Opening…')); }
      else { const y = el('button', 'btn sm gold', 'Open'); y.type = 'button'; y.onclick = () => { y.disabled = true; open(true); }; const no = el('button', 'btn sm', 'Not now'); no.type = 'button'; no.onclick = () => { st.s = 'skip'; renderMsgs(); }; acts.append(y, no); }
    } else if (st.s === 'done') acts.appendChild(el('span', 'ok', st.bg ? 'Opened in a new tab behind this one.' : 'Opened in a new tab.'));
    else if (st.s === 'skip') acts.appendChild(el('span', 'tx', 'Not opened.'));
    else if (st.s === 'fail') acts.appendChild(el('span', 'no', 'Chrome would not open it.'));
    return c;
  }
  /** A search that worked shows the sites. One that failed shows nothing here: the reply says so, once. */
  function searchCard(sr) {
    if (sr.state === 'bad') return document.createDocumentFragment();
    if (sr.state === 'run') return el('div', 'sc', 'Searching the web for “' + esc(first(sr.q, 60)) + '”…');
    const c = el('div', 'sc', 'Searched: “' + esc(first(sr.q, 50)) + '”');
    (sr.sources || []).slice(0, 4).forEach((x) => { const h = hostOf(x.url).replace(/^www\./, ''); if (h) { const a = el('a', '', esc(h)); a.href = x.url; a.target = '_blank'; a.rel = 'noopener noreferrer'; c.appendChild(a); } });
    return c;
  }

  // ------------------------------------------------------------------ waiting messages
  function paintQueue() {
    const host = $('queue'); if (!host) return; host.replaceChildren();
    S.queue.forEach((q, i) => {
      const d = el('div', 'queued', '<span>Next: ' + esc(first(q.text, 70)) + '</span>');
      if (i === 0 && S.busy) { const b = el('button', '', 'Send now'); b.type = 'button'; b.onclick = sendNow; d.appendChild(b); }
      const x = el('button', '', 'Remove'); x.type = 'button'; x.onclick = () => { S.queue.splice(i, 1); paintQueue(); }; d.appendChild(x); host.appendChild(d);
    });
  }

  // ------------------------------------------------------------------ everything done here is kept so the Coe website can show it
  let saveT = 0;
  function saveChat() {
    clearTimeout(saveT);
    saveT = setTimeout(async () => {
      try {
        if (!S.tx.length) return;
        const o = await store.get('chats'), list = Array.isArray(o.chats) ? o.chats : [];
        const us = S.tx.find((x) => x.r === 'u'), where = (() => { try { const u = new URL(S.tab.url); return u.origin + u.pathname; } catch { return ''; } })();
        const rec = { id: S.chatId, title: first((us || S.tx[0]).t, 48), host: hostOf(S.tab && S.tab.url), url: where, t: Date.now(), msgs: S.tx.slice(-60) };
        await store.set({ chats: [rec, ...list.filter((x) => x.id !== S.chatId)].slice(0, 30) });
      } catch { /* storage unavailable */ }
    }, 350);
  }

  // ------------------------------------------------------------------ the questions on a page
  const QKIND = { one: 'Pick one', many: 'Pick any', text: 'Short answer', long: 'Long answer', select: 'Pick from a list', open: 'Question' };
  async function findQuestions() {
    if (S.qBusy || S.busy) return;
    clearErr(); S.qBusy = true; paintQuick(); renderMsgs(true);
    let page, r = null;
    try { page = await readTab(S.scope); r = await runInTab(coeFindQuestions); }
    catch (e) {
      S.qBusy = false; paintQuick(); renderMsgs();
      if (e && e.code === 'allow') { S.pending = findQuestions; addAllowCard(e.origin); return; }
      showErr((e && e.code) || 'other'); return;
    }
    S.qBusy = false; paintQuick();
    if (!r) { renderMsgs(); showErr('other', 'Coe could not look through this page. Try again.'); return; }
    let items = r.items || [];
    if (!items.length && r.onScreen) items = [{ id: 's', text: r.onScreen, kind: 'open', options: [], fillable: false, screen: true }];
    if (!items.length) { renderMsgs(); showErr('noq'); return; }
    S.msgs = S.msgs.filter((m) => m.kind !== 'qs');
    S.qs = { url: page.url, title: r.title, school: isSchool(page.url), items: items.map((x) => ({ ...x, text: String(x.text || '').replace(/^\s*(?:Q(?:uestion)?\s*\d+\s*[.):\-]?|\d{1,2}\s*[.):])\s+(?=\S)/i, '') || x.text, res: null, busy: '', pick: [], fill: null, text0: '' })), shot: S.shot };
    S.msgs.push({ role: 'assistant', kind: 'qs' }); renderMsgs(true);
    tell('a', 'Found ' + items.length + ' question' + (items.length === 1 ? '' : 's') + ' on “' + first(r.title, 50) + '”.');
  }
  function callJson(system, user, images) {
    return new Promise((done) => {
      const port = connect(); let text = '', over = false;
      port.onMessage.addListener((m) => {
        if (over) return;
        if (m.t === 'd') text += m.s;
        else if (m.t === 'end') {
          over = true; try { port.disconnect(); } catch { /* done */ } if (m.credits) setMeter(m.credits);
          const a = text.indexOf('{'), z = text.lastIndexOf('}'); let data = null; if (a >= 0 && z > a) { try { data = JSON.parse(text.slice(a, z + 1)); } catch { /* not JSON */ } }
          done(data ? { ok: true, data, receipt: m.receipt || '' } : { ok: false, error: 'Coe’s answer came back in a form it could not use.', receipt: m.receipt || '', refundable: true });
        } else if (m.t === 'err') { over = true; try { port.disconnect(); } catch { /* done */ } done({ ok: false, code: m.code, error: m.error }); }
      });
      port.postMessage({ type: 'send', system, messages: [{ role: 'user', content: images && images.length ? [...images.map((u) => ({ type: 'image_url', image_url: { url: u } })), { type: 'text', text: user }] : user }] });
    });
  }
  const QBASE = 'You are Coe Mini, a study helper in a browser sidebar. Use plain, short words and British spelling. No greeting and no extra words. Reply with ONE JSON object and nothing else.';
  const QSHAPE = {
    answer: ['Give the answer.', '{"answer":"the answer in a few words","fill":"the exact option text copied from OPTIONS, or exactly what to type","why":"one short line, under 20 words"}'],
    explain: ['Explain how to think about it, in two to four short sentences.', '{"text":"the explanation"}'],
    hint: ['Give one nudge that helps without giving the answer.', '{"text":"the nudge"}'],
    check: ['Check what the student answered. If it is right, say so and why in one sentence. If not, give one nudge. Do not give the answer.', '{"verdict":"right or almost or not yet","text":"one or two short sentences"}'],
  };
  /** One question, one job: answer it, explain it, hint, or check what the student tried. */
  async function qAsk(it, mode, attempt) {
    if (it.busy || S.busy) return;
    const q = S.qs, school = q.school;
    if (school && mode === 'answer') return;   // set work and quizzes: explain, hint and check only
    it.busy = mode; it.res = null; if (mode === 'answer') it.fill = null; renderMsgs();
    const ex = (S.page && S.page.text ? String(S.page.text).slice(0, 3500) : '');
    const task = QSHAPE[mode][0] + (school && mode !== 'check' ? ' This is set work or a quiz, so never state the final answer.' : '');
    const user = 'PAGE: ' + q.title + ' (' + hostOf(q.url) + ')' + (ex && !it.screen ? '\nPAGE TEXT (for reading questions):\n' + ex : '') + '\n\nQUESTION: ' + it.text + (it.options.length ? '\nOPTIONS:\n- ' + it.options.join('\n- ') : '') + (attempt ? '\nTHE STUDENT ANSWERED: ' + attempt : '') + '\n\nTASK: ' + task + ' Reply with one JSON object like this: ' + QSHAPE[mode][1];
    const r = await callJson(QBASE, user, it.screen && q.shot ? [q.shot] : []);
    it.busy = '';
    if (!r.ok) {
      if (r.code) { it.res = null; renderMsgs(); showErr(r.code, r.error); return; }
      it.res = { kind: 'bad', text: 'Could not get an answer. Try again.' }; renderMsgs();
      if (r.refundable) refundMsg({ receipt: r.receipt }, 'the answer came back unreadable');
      return;
    }
    const d = r.data || {}; it.receipt = r.receipt;
    it.res = { kind: mode, answer: String(d.answer || '').slice(0, 400), fill: String(d.fill == null ? d.answer || '' : d.fill).slice(0, 600), why: String(d.why || '').slice(0, 300), text: String(d.text || '').slice(0, 900), verdict: /^(right|almost)/i.test(String(d.verdict || '')) ? (/^right/i.test(d.verdict) ? 'right' : 'almost') : 'not yet' };
    if (mode === 'answer' && !it.res.answer) { it.res = { kind: 'bad', text: 'Could not get an answer. Try again.' }; if (r.receipt) refundMsg({ receipt: r.receipt }, 'the answer came back empty'); }
    renderMsgs(); tell('u', (mode === 'check' ? 'Check my answer' : mode === 'answer' ? 'Answer' : mode === 'hint' ? 'Hint' : 'Explain') + ' (question ' + (Number(it.id) + 1 || '') + '): ' + first(it.text, 160) + (attempt ? ' / my answer: ' + attempt : ''));
    tell('a', it.res.kind === 'answer' ? it.res.answer + (it.res.why ? ' (' + it.res.why + ')' : '') : it.res.text);
  }
  /** Answers every question in one go (not on set work or quizzes). */
  async function qAll() {
    const q = S.qs; if (!q || q.school || S.busy) return;
    const list = q.items.filter((x) => !x.screen); if (!list.length) return;
    list.forEach((x) => { x.busy = 'answer'; x.res = null; x.fill = null; }); renderMsgs();
    const ex = (S.page && S.page.text ? String(S.page.text).slice(0, 3500) : '');
    const user = 'PAGE: ' + q.title + ' (' + hostOf(q.url) + ')' + (ex ? '\nPAGE TEXT (for reading questions):\n' + ex : '') + '\n\n' + list.map((x, i) => 'QUESTION ' + (i + 1) + ': ' + x.text + (x.options.length ? '\nOPTIONS:\n- ' + x.options.join('\n- ') : '')).join('\n\n') + '\n\nTASK: Answer every question. Reply with one JSON object like this: {"items":[{"n":1,"answer":"the answer in a few words","fill":"the exact option text copied from OPTIONS, or exactly what to type","why":"one short line, under 20 words"}]}. n is the question number.';
    const r = await callJson(QBASE, user, []);
    list.forEach((x) => { x.busy = ''; });
    if (!r.ok) { renderMsgs(); if (r.code) showErr(r.code, r.error); else { list.forEach((x) => { x.res = { kind: 'bad', text: 'Could not get an answer. Try again.' }; }); renderMsgs(); if (r.refundable) refundMsg({ receipt: r.receipt }, 'the answers came back unreadable'); } return; }
    const arr = Array.isArray(r.data.items) ? r.data.items : [];
    let got = 0;
    list.forEach((x, i) => { const d = arr.find((a) => Number(a.n) === i + 1) || arr[i]; if (d && (d.answer || d.fill)) { got++; x.receipt = r.receipt; x.res = { kind: 'answer', answer: String(d.answer || d.fill).slice(0, 400), fill: String(d.fill == null ? d.answer : d.fill).slice(0, 600), why: String(d.why || '').slice(0, 300) }; } else x.res = { kind: 'bad', text: 'No answer came back for this one.' }; });
    renderMsgs();
    if (!got && r.receipt) refundMsg({ receipt: r.receipt }, 'no usable answers came back');
    tell('u', 'Answer all ' + list.length + ' questions on “' + first(q.title, 40) + '”'); tell('a', list.map((x, i) => (i + 1) + '. ' + (x.res.kind === 'answer' ? x.res.answer : '(none)')).join('\n'));
    if (S.askChg === 'allow') for (const x of list) if (x.fillable && x.res.kind === 'answer') await qFill(x);
  }
  const noHash = (u) => String(u || '').split('#')[0];
  async function qFill(it) {
    if (S.qs && S.tab && noHash(S.tab.url) !== noHash(S.qs.url)) { it.fill = { s: 'fail', why: 'This is a different page now. Press Scan again.' }; renderMsgs(); return; }
    if (!S.qs || S.qs.school || isSchool(S.tab && S.tab.url)) { it.fill = { s: 'fail', why: blocked() || 'Coe does not type into this site.' }; renderMsgs(); return; }
    it.fill = { s: 'run' }; renderMsgs();
    let r;
    try { r = await runInTab(coeFillAnswer, [it.id, it.res.fill || it.res.answer]); } catch { r = { ok: false, why: 'Coe is not allowed to change this page yet.' }; }
    it.fill = r && r.ok ? { s: 'done', before: r.before || '' } : { s: 'fail', why: (r && r.why) || 'That did not work.' };
    renderMsgs();
    if (it.fill.s === 'fail' && it.receipt && !it.refundedFill && /match|gone|option/i.test(it.fill.why)) { it.refundedFill = true; refundMsg({ receipt: it.receipt }, 'the answer did not fit the page'); }
  }
  async function qUndo(it) {
    if (!it.fill || it.fill.s !== 'done') return;
    let r; try { r = await runInTab(coeFillAnswer, [it.id, it.fill.before, true]); } catch { r = null; }
    it.fill = r && r.ok ? { s: 'undone' } : { ...it.fill, why: 'Could not undo that.' }; renderMsgs();
  }
  function qCard(it, i) {
    const q = S.qs, school = q.school, c = el('div', 'qc');
    c.appendChild(el('div', 'qc-t', '<span class="qc-n d">' + (it.screen ? '•' : i + 1) + '</span><div class="qc-q">' + esc(first(it.text, 420)) + '</div>'));
    if (it.options.length) {
      const o = el('div', 'qc-o');
      it.options.forEach((t) => {
        const b = el(school && (it.kind === 'one' || it.kind === 'many') ? 'button' : 'span', 'qp' + (school ? ' pick' : '') + (it.pick.includes(t) ? ' on' : ''), esc(first(t, 70)));
        if (b.tagName === 'BUTTON') { b.type = 'button'; b.setAttribute('aria-pressed', String(it.pick.includes(t))); b.onclick = () => { it.pick = it.kind === 'many' ? (it.pick.includes(t) ? it.pick.filter((x) => x !== t) : [...it.pick, t]) : [t]; renderMsgs(); }; }
        o.appendChild(b);
      });
      c.appendChild(o);
    }
    const a = el('div', 'qc-a'), mk = (label, f, cls) => { const b = el('button', 'btn sm' + (cls ? ' ' + cls : ''), esc(label)); b.type = 'button'; b.disabled = !!it.busy || S.busy; b.onclick = f; a.appendChild(b); return b; };
    if (it.busy) a.appendChild(el('span', 'qc-w', '<span class="dots"><i></i><i></i><i></i></span>Working on it'));
    else if (school) { mk('Hint', () => qAsk(it, 'hint')); mk('Explain', () => qAsk(it, 'explain')); }
    else { mk('Answer', () => qAsk(it, 'answer'), 'gold'); mk('Explain', () => qAsk(it, 'explain')); }
    c.appendChild(a);
    if (school && !it.screen) {
      const choice = it.kind === 'one' || it.kind === 'many' || it.options.length;
      if (choice) { const b = el('button', 'btn sm', 'Check my pick'); b.type = 'button'; b.disabled = !it.pick.length || !!it.busy || S.busy; b.onclick = () => qAsk(it, 'check', it.pick.join('; ')); const w = el('div', 'qc-a'); w.appendChild(b); c.appendChild(w); }
      else { const w = el('div', 'qc-chk'), inp = el('input'); inp.type = 'text'; inp.placeholder = 'Your answer'; inp.value = it.text0 || ''; inp.setAttribute('aria-label', 'Your answer to question ' + (i + 1)); inp.oninput = () => { it.text0 = inp.value; }; const b = el('button', 'btn sm', 'Check'); b.type = 'button'; b.disabled = !!it.busy || S.busy; const go = () => { if (inp.value.trim()) qAsk(it, 'check', inp.value.trim()); }; b.onclick = go; inp.onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); go(); } }; w.append(inp, b); c.appendChild(w); }
    }
    const r = it.res;
    if (r) {
      if (r.kind === 'bad') c.appendChild(el('div', 'qc-r bad', esc(r.text)));
      else if (r.kind === 'answer') {
        const box = el('div', 'qc-r good', '<b>Answer</b><div>' + esc(r.answer) + '</div>' + (r.why ? '<div class="tx">' + esc(r.why) + '</div>' : '')); c.appendChild(box);
        if (it.fillable && !school) {
          const w = el('div', 'qc-a'); c.appendChild(w); const f = it.fill;
          if (!f || f.s === 'fail') { const b = el('button', 'btn sm gold', 'Put in page'); b.type = 'button'; b.onclick = () => qFill(it); w.appendChild(b); if (f) w.appendChild(el('span', 'no', esc(f.why))); }
          else if (f.s === 'run') w.appendChild(el('span', 'tx', 'Putting it in…'));
          else if (f.s === 'done') { w.appendChild(el('span', 'ok', 'Done. It is in the page.')); if (it.kind !== 'one') { const u = el('button', 'btn sm', 'Undo'); u.type = 'button'; u.onclick = () => qUndo(it); w.appendChild(u); } }
          else if (f.s === 'undone') w.appendChild(el('span', 'tx', 'Put back.'));
        }
      } else if (r.kind === 'check') c.appendChild(el('div', 'qc-r ' + (r.verdict === 'right' ? 'good' : r.verdict === 'almost' ? 'hmm' : 'bad'), '<b>' + (r.verdict === 'right' ? 'Right' : r.verdict === 'almost' ? 'Almost' : 'Not yet') + '</b><div>' + esc(r.text) + '</div>'));
      else c.appendChild(el('div', 'qc-r', '<b>' + (r.kind === 'hint' ? 'Hint' : 'Idea') + '</b><div>' + esc(r.text) + '</div>'));
    }
    return c;
  }
  function qsPanel() {
    const q = S.qs, box = el('div', 'qs'), h = el('div', 'qs-h', '<b class="d">' + (q.items[0] && q.items[0].screen ? 'This page' : 'Questions · ' + q.items.length) + '</b><span class="grow"></span>');
    const again = el('button', 'btn sm', 'Scan again'); again.type = 'button'; again.onclick = () => findQuestions(); h.appendChild(again);
    if (!q.school && !(q.items[0] && q.items[0].screen)) { const all = el('button', 'btn sm gold', 'Answer all'); all.type = 'button'; all.disabled = S.busy || q.items.some((x) => x.busy); all.onclick = qAll; h.appendChild(all); }
    box.appendChild(h);
    if (q.school) box.appendChild(el('div', 'qs-note', 'Set work or a quiz. Coe explains, hints and checks. It does not type for you.'));
    else if (q.items.some((x) => x.res && x.res.kind === 'answer' && x.fillable && (!x.fill || x.fill.s === 'fail'))) {
      const n = q.items.filter((x) => x.res && x.res.kind === 'answer' && x.fillable && (!x.fill || x.fill.s === 'fail')).length;
      const w = el('div', 'qs-note'); w.appendChild(document.createTextNode(q.confirmAll ? 'Put ' + n + ' answer' + (n === 1 ? '' : 's') + ' in the page? ' : ''));
      if (q.confirmAll) { const y = el('button', 'btn sm gold', 'Put them in'); y.type = 'button'; y.onclick = async () => { q.confirmAll = false; for (const x of q.items) if (x.res && x.res.kind === 'answer' && x.fillable && (!x.fill || x.fill.s === 'fail')) await qFill(x); }; const no = el('button', 'btn sm', 'Cancel'); no.type = 'button'; no.onclick = () => { q.confirmAll = false; renderMsgs(); }; w.append(y, document.createTextNode(' '), no); }
      else { const b = el('button', 'btn sm gold', 'Put all in page'); b.type = 'button'; b.onclick = () => { q.confirmAll = true; renderMsgs(); }; w.appendChild(b); }
      box.appendChild(w);
    }
    q.items.forEach((it, i) => box.appendChild(qCard(it, i)));
    return box;
  }

  // ------------------------------------------------------------------ files you add, with previews
  function attCard(a, remove) {
    const c = el('span', 'att-c'), b = el('button', 'att-b', '<span class="att-pg" aria-hidden="true"><b>' + esc((ext(a.name) || 'file').slice(0, 4)) + '</b><span>' + esc(first(a.text) || 'Nothing to read') + '</span></span><span class="att-n"><b>' + esc(a.name) + '</b><i>' + (a.cut ? 'cut short' : 'text file') + '</i></span>');
    b.type = 'button'; b.title = 'Preview'; b.setAttribute('aria-label', 'Preview ' + a.name); b.onclick = () => openDlg(a.name, [el('p', 'meta', (a.text.length).toLocaleString() + ' letters' + (a.cut ? '. The file was long, so Coe reads the first part.' : '')), el('pre', 'tx', esc(a.text.slice(0, 6000)))]);
    c.appendChild(b);
    if (remove) { const x = el('button', 'x', X); x.type = 'button'; x.setAttribute('aria-label', 'Remove ' + a.name); x.onclick = remove; c.appendChild(x); }
    return c;
  }
  function paintAtts() {
    const box = $('atts'); box.replaceChildren();
    S.atts.forEach((a, i) => {
      const rm = () => { S.atts.splice(i, 1); paintAtts(); paintSend(); };
      if (a.img) { const t = el('span', 'thumb'); const im = el('img'); im.src = a.img; im.alt = a.name; im.title = 'Look closer'; im.onclick = () => openImage(a.img); const x = el('button', 'x', X); x.type = 'button'; x.setAttribute('aria-label', 'Remove ' + a.name); x.onclick = rm; t.append(im, x); box.appendChild(t); }
      else box.appendChild(attCard(a, rm));
    });
  }
  async function addFiles(list) {
    for (const f of Array.from(list).slice(0, 4)) {
      if (S.atts.length >= 4) break;
      try {
        if (f.type.startsWith('image/')) {
          const url = await new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = no; r.readAsDataURL(f); });
          const img = await new Promise((ok, no) => { const i = new Image(); i.onload = () => ok(i); i.onerror = no; i.src = url; });
          const k = Math.min(1, 1280 / Math.max(img.width, img.height)), cv = document.createElement('canvas'); cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k);
          cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height); S.atts.push({ name: f.name, img: cv.toDataURL('image/jpeg', 0.82) });
        } else {
          const t = await f.text(); S.atts.push({ name: f.name, text: t.slice(0, 20000), cut: t.length > 20000 });
        }
      } catch { showErr('other', 'Coe could not open ' + f.name + '.'); }
    }
    paintAtts(); paintSend();
  }

  // ------------------------------------------------------------------ windows
  function openDlg(title, nodes) {
    $('dt').textContent = title; $('db').replaceChildren(...nodes); $('dlg').hidden = false; $('dlg').querySelector('.modal').focus();
  }
  const closeDlg = () => { $('dlg').hidden = true; $('db').replaceChildren(); };
  function openImage(u) { const i = el('img', 'big'); i.src = u; i.alt = ''; openDlg('Picture', [i]); }
  $('dx').onclick = closeDlg; $('dlg').addEventListener('pointerdown', (e) => { if (e.target === $('dlg')) closeDlg(); });
  addEventListener('keydown', (e) => { if (e.key === 'Escape') { if (!$('dlg').hidden) closeDlg(); else closeMenu(); } });

  $('page').onclick = () => {
    const read = S.page && S.tab && S.page.url === S.tab.url, nodes = [];
    if (read) {
      if (S.shot) { const i = el('img', 'big'); i.src = S.shot; i.alt = 'The page as Coe saw it'; nodes.push(i); }
      nodes.push(el('p', 'meta', esc(S.page.url)), el('p', 'meta', 'Coe read ' + S.page.text.length.toLocaleString() + ' letters' + (S.page.docKind ? ' from this Google file' : S.page.scope === 'screen' ? ' that are on screen' : ' from the whole page') + (S.page.cut ? ' (the page was long, so it was cut short)' : '') + '.'));
      if (S.page.selection) nodes.push(el('p', 'meta', 'You had selected: “' + esc(first(S.page.selection, 160)) + '”'));
      nodes.push(el('pre', 'tx', esc(S.page.text.slice(0, 6000))));
    } else {
      nodes.push(el('p', '', 'Coe has not read this page yet. It reads when you send a message or press a button below.'));
      const b = el('button', 'btn gold', 'Read it now'); b.type = 'button';
      b.onclick = async () => { b.disabled = true; try { await readTab(S.scope); closeDlg(); $('page').click(); } catch (e) { closeDlg(); if (e && e.code === 'allow') { S.pending = null; addAllowCard(e.origin); } else showErr((e && e.code) || 'other'); } };
      nodes.push(b);
    }
    openDlg(S.tab ? (S.tab.title || 'This page') : 'This page', nodes);
  };

  // ------------------------------------------------------------------ the message box
  function grow() { const t = $('ta'); t.style.height = 'auto'; t.style.height = Math.min(t.scrollHeight, 144) + 'px'; paintSend(); }
  function paintSend() {
    const b = $('send'), out = S.errKind === 'credits', has = !!($('ta').value.trim() || S.atts.length), stopMode = S.busy && !has;
    b.classList.toggle('stop', stopMode); b.setAttribute('aria-label', stopMode ? 'Stop' : S.busy ? 'Send next' : 'Send'); b.title = stopMode ? 'Stop' : S.busy ? 'Send next, after this reply' : 'Send';
    b.disabled = !S.busy && (out || !has);
    const t = S.tab, school = !!(t && /^https?:/.test(t.url || '') && isSchool(t.url));
    $('ta').disabled = out; $('ta').placeholder = out ? 'Tokens are back at midnight (UTC)' : S.busy ? 'Add more now, or press Stop' : school ? 'Ask for a hint, or check your answer' : 'Ask about this page';
  }
  function paintQuick() {
    const q = $('quick'); q.replaceChildren();
    q.hidden = !S.msgs.length && !S.busy && !S.qBusy;   // the home cards say the same, so show the chips only once a chat has started
    const school = S.tab && isSchool(S.tab.url);
    for (const [label, text, o] of QUICK) {
      const b = el('button', o && o.act ? 'go1' : '', esc(label)); b.type = 'button'; b.disabled = S.busy || S.errKind === 'credits' || (o && o.act === 'questions' && S.qBusy);
      b.onclick = () => (o && o.act === 'questions' ? findQuestions() : send(text, o || {})); q.appendChild(b);
    }
  }
  $('ta').addEventListener('input', grow);
  $('ta').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); send($('ta').value); } });
  $('ta').addEventListener('paste', (e) => { const fs = Array.from((e.clipboardData && e.clipboardData.files) || []); if (fs.length) { e.preventDefault(); addFiles(fs); } });
  $('send').onclick = () => { const has = !!($('ta').value.trim() || S.atts.length); if (S.busy && !has) stop(); else send($('ta').value); };
  $('attach').onclick = () => $('file').click();
  $('file').onchange = () => { addFiles($('file').files); $('file').value = ''; };
  $('scope').onclick = () => { S.scope = S.scope === 'page' ? 'screen' : 'page'; store.set({ scope: S.scope }); paintScope(); S.page = null; paintPage(); };
  const paintScope = () => { $('scope').textContent = S.scope === 'page' ? 'Whole page' : 'On screen'; $('scope').title = S.scope === 'page' ? 'Coe reads the whole page. Press to read only what is on screen.' : 'Coe reads only what is on screen. Press to read the whole page.'; };

  // ------------------------------------------------------------------ the menu
  const closeMenu = () => { $('menu').hidden = true; $('more').setAttribute('aria-expanded', 'false'); };
  $('more').onclick = (e) => { e.stopPropagation(); const o = $('menu').hidden; $('menu').hidden = !o; $('more').setAttribute('aria-expanded', String(o)); };
  document.addEventListener('click', (e) => { if (!$('menu').contains(e.target)) closeMenu(); });
  $('m-new').onclick = () => { closeMenu(); S.msgs = []; S.atts = []; S.tx = []; S.qs = null; S.queue = []; S.chatId = 'c' + Date.now().toString(36); paintAtts(); paintQueue(); clearErr(); renderMsgs(); paintQuick(); paintSend(); };
  $('m-setup').onclick = () => { closeMenu(); showSetup(); };
  $('m-coe').onclick = () => { closeMenu(); chrome.runtime.sendMessage({ type: 'open-coe' }); };
  $('m-hand').onclick = () => { closeMenu(); const t = S.msgs.filter((m) => m.text).map((m) => (m.role === 'user' ? 'Me: ' : 'Coe: ') + m.text).join('\n\n'); if (t) chrome.runtime.sendMessage({ type: 'handoff', text: 'We were talking about a page. Here is the chat so far:\n\n' + t.slice(0, 5000) + '\n\nContinue from here.' }); };
  $('m-clear').onclick = () => { closeMenu(); clearMarks(); };

  // ------------------------------------------------------------------ you and your tokens
  function setMeter(c) {
    const m = $('meter'); if (!c || !c.limit) { m.hidden = true; return; }
    const pct = Math.min(100, Math.round((c.used / c.limit) * 100)); m.hidden = pct < 80; m.firstElementChild.style.width = pct + '%';
    m.classList.toggle('hot', pct >= 90 && pct < 100); m.classList.toggle('out', pct >= 100);
    m.title = Math.max(0, Math.round((c.limit - c.used) / 1000)) + 'k of ' + Math.round(c.limit / 1000) + 'k tokens left today';
    if (pct >= 100) { if (S.errKind !== 'credits') showErr('credits'); } else if (S.errKind === 'credits') clearErr();
    paintSend(); paintQuick();
  }
  async function refreshStatus() {
    const r = await new Promise((ok) => chrome.runtime.sendMessage({ type: 'status' }, (x) => ok(chrome.runtime.lastError ? null : x)));
    S.status = r; if (r && r.ok && r.limit != null) setMeter({ used: r.used, limit: r.limit });
    const e = await store.get('site'); if (e.site) site = e.site;
    return r;
  }
  chrome.storage.onChanged.addListener((c) => { if (c.session || c.ext || c.serverUrl) refreshStatus().then(paintSetup); if (c.askTabs) { S.askTabs = c.askTabs.newValue === 'allow' ? 'allow' : 'ask'; paintSwitches(); } if (c.askChg) { S.askChg = c.askChg.newValue === 'allow' ? 'allow' : 'ask'; paintSwitches(); } if (c.me && !$('setup').hidden) loadProfile(); if (c.scope && c.scope.newValue && c.scope.newValue !== S.scope) { S.scope = c.scope.newValue; paintScope(); S.page = null; paintPage(); paintSetup(); } });

  // ------------------------------------------------------------------ the setup screen
  function showSetup() {
    $('chat').hidden = true; $('setup').hidden = false; $('ttl').textContent = 'Coe Mini';
    $('sh1').textContent = S.setupDone ? 'Settings' : 'Set up Coe Mini'; $('slead').textContent = S.setupDone ? 'Change anything. It saves as you go.' : 'Four small steps. About a minute.';
    $('done').textContent = S.setupDone ? 'Done' : 'Start'; $('skip').hidden = !!S.setupDone;
    loadProfile(); paintSwitches(); refreshStatus().then(paintSetup); paintSiteBtn();
  }
  function showChat() { $('setup').hidden = true; $('chat').hidden = false; refreshTab(); renderMsgs(); paintQuick(); paintSend(); paintQueue(); setTimeout(() => $('ta').focus(), 50); }
  function paintSetup() {
    const r = S.status, ok = r && r.ok && r.signedIn;
    $('s1').classList.toggle('ok', !!ok);
    const s = $('s1s'); s.className = 'state tx' + (ok ? '' : r && !r.ok && r.code === 'network' ? ' bad' : '');
    s.textContent = ok ? 'Signed in' + (r.email ? ' as ' + r.email : '') : !r ? 'Checking' : r.ok ? 'Not signed in yet.' : r.code === 'setup' ? 'Open Coe once and sign in.' : r.error || '';
    document.querySelectorAll('.opt').forEach((o) => o.setAttribute('aria-checked', String(o.dataset.scope === S.scope)));
  }
  /** Firefox only lets an add-on see a website after you say yes. Coe Mini needs to see the Coe site to find your sign-in. */
  async function paintSiteBtn() {
    const b = $('s1site'); if (!FF) { b.hidden = true; return; }
    let has = false; try { has = await chrome.permissions.contains({ origins: [siteBase() + '*'] }); } catch { /* unknown */ }
    b.hidden = has; b.onclick = async () => { let ok = false; try { ok = await chrome.permissions.request({ origins: [siteBase() + '*'] }); } catch { /* not allowed */ } if (ok) { b.hidden = true; chrome.runtime.sendMessage({ type: 'open-coe' }); } };
  }

  // ---- about you
  const PF = { name: 'pf-name', ageBand: 'pf-age', role: 'pf-role', yearOrJob: 'pf-level', subjects: 'pf-subj', length: 'pf-len' };
  const LVL = { student: ['Year or course', 'Year 10, A level'], teacher: ['What you teach', 'Maths, KS3 science'], parent: ['Your child’s year (if you like)', 'Year 7'], working: ['Your job', 'Nurse, builder'], other: ['What you do', 'Hobbies, a project'], '': ['Year, course or job', 'Year 10, A level, nurse'] };
  async function loadProfile() {
    const o = await store.get('me'); S.me = o.me || {};
    for (const [k, id] of Object.entries(PF)) { const e = $(id); if (e) e.value = S.me[k] != null && S.me[k] !== '' ? S.me[k] : (k === 'length' ? 'balanced' : ''); }
    $('pf-easy').setAttribute('aria-checked', String(!!S.me.easy)); paintLvl(); paintProfileState();
  }
  function paintLvl() { const l = LVL[$('pf-role').value] || LVL['']; $('pf-lvl-l').textContent = l[0]; $('pf-level').placeholder = l[1]; }
  function paintProfileState() { const any = ['name', 'ageBand', 'role', 'yearOrJob', 'subjects'].some((k) => S.me[k]); $('s2').classList.toggle('ok', any); $('s2s').textContent = any ? 'Saved. Coe will use this, and so will the Coe website.' : ''; $('s2s').className = 'state tx'; }
  let pfT = 0;
  function saveProfile() {
    const me = { ...S.me }; for (const [k, id] of Object.entries(PF)) me[k] = String($(id).value || '').trim().slice(0, k === 'subjects' ? 100 : 60);
    me.easy = $('pf-easy').getAttribute('aria-checked') === 'true'; me.at = Date.now(); S.me = me; paintLvl();
    clearTimeout(pfT); pfT = setTimeout(async () => { await store.set({ me }); paintProfileState(); }, 250);
  }
  for (const id of Object.values(PF)) { const e = $(id); e.addEventListener('input', saveProfile); e.addEventListener('change', saveProfile); }
  $('pf-easy').onclick = () => { const b = $('pf-easy'); b.setAttribute('aria-checked', String(b.getAttribute('aria-checked') !== 'true')); saveProfile(); };

  // ---- what Coe may do
  function paintSwitches() { $('ask-tabs').setAttribute('aria-checked', String(S.askTabs !== 'allow')); $('ask-chg').setAttribute('aria-checked', String(S.askChg !== 'allow')); }
  $('ask-tabs').onclick = () => { S.askTabs = S.askTabs === 'allow' ? 'ask' : 'allow'; store.set({ askTabs: S.askTabs }); paintSwitches(); };
  $('ask-chg').onclick = () => { S.askChg = S.askChg === 'allow' ? 'ask' : 'allow'; store.set({ askChg: S.askChg }); paintSwitches(); };
  document.querySelectorAll('.opt').forEach((o) => { o.onclick = () => { S.scope = o.dataset.scope; store.set({ scope: S.scope }); paintScope(); paintSetup(); $('s3').classList.add('ok'); }; });
  $('s2all').onclick = async () => {
    const st = $('s3s'); let ok = false;
    try { ok = await chrome.permissions.request({ origins: ['http://*/*', 'https://*/*'] }); } catch { /* not allowed */ }
    st.className = 'state tx' + (ok ? '' : ' bad'); st.textContent = ok ? 'Done. Coe will not ask for each site. It still reads only when you ask.' : 'The browser did not allow that. Coe will ask for each site instead.';
  };
  $('s1b').onclick = () => chrome.runtime.sendMessage({ type: 'open-coe' });
  $('s3b').onclick = async () => {
    const st = $('s4s'); st.className = 'state tx'; st.textContent = 'Reading';
    await refreshTab();
    try { const p = await readTab(S.scope); st.textContent = 'Read ' + p.text.length.toLocaleString() + ' letters from “' + first(p.title, 40) + '”.'; $('s4').classList.add('ok'); }
    catch (e) {
      if (e && e.code === 'allow') { st.textContent = 'Press the button again after you allow this site.'; try { const ok = await chrome.permissions.request({ origins: [e.origin] }); if (ok) { $('s3b').click(); } else { st.className = 'state tx bad'; st.textContent = 'The browser did not allow that site.'; } } catch { st.className = 'state tx bad'; st.textContent = 'Open a website first, then try again.'; } }
      else { st.className = 'state tx bad'; st.textContent = 'Open a website first, then try again.'; }
    }
  };
  const finish = () => { S.setupDone = true; store.set({ setupDone: true }); showChat(); };
  $('done').onclick = finish; $('skip').onclick = finish;
  setInterval(() => { if (!$('setup').hidden && !(S.status && S.status.ok && S.status.signedIn)) refreshStatus().then(paintSetup); }, 2500);

  // ------------------------------------------------------------------ start
  (async () => {
    const o = await store.get(['scope', 'setupDone', 'site', 'askTabs', 'askChg', 'me']);
    if (o.scope === 'screen') S.scope = 'screen'; if (o.site) site = o.site; paintScope();
    S.askTabs = o.askTabs === 'allow' ? 'allow' : 'ask'; S.askChg = o.askChg === 'allow' ? 'allow' : 'ask'; S.me = o.me || {};
    S.setupDone = !!o.setupDone; await refreshTab();
    if (S.setupDone) { showChat(); refreshStatus(); } else showSetup();
  })();
  window.__coe = { S, send, readTab };   // for testing
})();
